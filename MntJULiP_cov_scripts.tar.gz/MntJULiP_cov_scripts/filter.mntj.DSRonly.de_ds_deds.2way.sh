DSR_FILTERED=filter.noparam
DIR=~/data/polyester/SRR493366_table.exon_transcript.cp/de_ds_deds
python3 ~/data/MntJULiP/filter_DSR_introns.py --dir . > ./$DSR_FILTERED
python /data/scripts/isin.gene_name.de_ds_deds.DSR.py ./$DSR_FILTERED \
    $DIR/df_100_ds.flippedtop2 \
    $DIR/df_100_deds \
    $DIR/df_200_ds.flippedtop2 \
    $DIR/df_200_deds \
    /data/polyester/SRR493366_table.exon_transcript.cp/t_data.ctab.2000gene.protein_coding

