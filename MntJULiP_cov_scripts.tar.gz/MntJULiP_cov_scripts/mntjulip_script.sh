python3 run.py --splice-list $sim_splice_list  --num-threads 24 --anno-file $gencode_v41_annotation_gtf --out-dir $sim_splice_list.out
bash /data/MntJULiP/MntJULiP_scripts/13_brain_tissues/run_mntjulip_13_brain_tissues.sh
parallel "bash /data//MntJULiP/MntJULiP_scripts/13_brain_tissues/run_mntjulip_13_brain_tissues.cov.parallel.sh {}" ::: sex age age_sex
python /data/MntJULiP/MntJULiP_scripts/13_brain_tissues/heatmap_distance_DSR_matrix.current_dir.vmax.manuscript.py
