DSA_FILTERED=diff_introns.txt.005pval
DIR=~/data/polyester/SRR493366_table.exon_transcript.cp/de_ds_deds.multi_condition
less diff_introns.txt |awk '{if ($8<=0.05) print}' > $DSA_FILTERED
python /data/lscripts/isin.gene_name.de_ds_deds.multi_DSA.py $DSA_FILTERED \
    $DIR/df_100_de \
    $DIR/df_100_ds.flippedtop2 \
    $DIR/df_100_deds \
    $DIR/df_disease_100_de \
    $DIR/df_disease_100_ds.flippedtop2 \
    $DIR/df_disease_100_deds \
    $DIR/df_disease_100s2_de \
    $DIR/df_disease_100s2_ds.flippedtop2 \
    $DIR/df_disease_100s2_deds \
    $DIR/df_200s2_de \
    $DIR/df_200s2_ds.flippedtop2 \
    $DIR/df_200s2_deds \
/data/polyester/SRR493366_table.exon_transcript.cp/t_data.ctab.2000gene.protein_coding
