DSA_FILTERED=diff_introns.txt.005pval
DIR=~/data/polyester/SRR493366_table.exon_transcript.cp/de_ds_deds
less diff_introns.txt |awk '{if ($8<=0.05) print}' > $DSA_FILTERED
python /data/scripts/isin.gene_name.de_ds_deds.DSA.py $DSA_FILTERED \
    $DIR/df_100_de \
    $DIR/df_100_ds.flippedtop2 \
    $DIR/df_100_deds \
    $DIR/df_200_de \
    $DIR/df_200_ds.flippedtop2 \
    $DIR/df_200_deds \
/data//polyester/SRR493366_table.exon_transcript.cp/t_data.ctab.2000gene.protein_coding
