import pandas as pd 
import sys
import os
inp=sys.argv[1]
#filter_res=pd.read_csv(inp,header=None,sep='\t')
sim_100_ds=pd.read_csv(sys.argv[2],header=None,sep='\t')
sim_100_deds=pd.read_csv(sys.argv[3],header=None,sep='\t')
sim_200_ds=pd.read_csv(sys.argv[4],header=None,sep='\t')
sim_200_deds=pd.read_csv(sys.argv[5],header=None,sep='\t')
sim_2000=pd.read_csv(sys.argv[6],header=None,sep='\t')
if os.path.basename(inp)=='diff_introns.txt.005pval':
    col=4
else:
    col=5
filter_res=[]
with open(inp) as f:
    for line in f:
        filter_res.extend(line.split('\t')[col].split(','))
filter_res=set(filter_res)-set('.')
with open(f'{inp}.genelist','w') as fout:
    for entry in filter_res:
        fout.write(entry+'\n')
sum_n=0
for e in enumerate([sim_100_ds,sim_100_deds,sim_200_ds,sim_200_deds]):
    fn=os.path.basename(sys.argv[e[0]+2])
    print(fn)
    gene_uniq=e[1][9].drop_duplicates() 
    gene_uniq_in_res=gene_uniq.isin(filter_res)
    n=sum(gene_uniq_in_res)
    gene_uniq[gene_uniq_in_res].to_csv(f'{fn}_gene_uniq_in_res',header=None,index=False) 
    print(n)
    sum_n+=n
#print(sys.argv[3])
#sim_500_gene_uniq=sim_500[9].drop_duplicates()
#sim_500_gene_uniq_in_res=sim_500_gene_uniq.isin(filter_res)
#n_500=sum(sim_500_gene_uniq_in_res)
#sim_500_gene_uniq[sim_500_gene_uniq_in_res].to_csv('sim_500_gene_uniq_in_res',header=None,index=False)
#print(n_500)
print(sys.argv[6])
n_2000=sum(sim_2000[9].drop_duplicates().isin(filter_res))
print(n_2000-sum_n)
print('all gencode')
print(len(filter_res)-n_2000)
print('***')
