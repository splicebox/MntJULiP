import numpy as np
from collections import defaultdict
from pathlib import Path
import pandas as pd

import seaborn as sns
import scipy.spatial as sp
import scipy.cluster.hierarchy as hc
import matplotlib.pyplot as plt
import sys
import os

PATH='.'

folders =   [f for f in os.listdir(PATH) if os.path.isdir(f)]

result = defaultdict(dict)
l2fc_cutoff = 2.0
p_value_cutoff = 0.05


base_dir = Path(PATH)
for folder in folders:
    file = base_dir / folder / 'intron_data.txt'
    with open(file, 'r') as f:
        lines = f.readlines()

    okay_introns = set()
    for line in lines[1:]:
        items = line.strip().split('\t')
        _chr, start, end, strand, gene_name, status = items[:6]
        if status == 'OK':
            okay_introns.add((_chr, strand, start, end))

    file = base_dir / folder / 'diff_introns.txt'
    with open(file, 'r') as f:
        lines = f.readlines()

    genes = set()
    for line in lines[1:]:
        items = line.strip().split('\t')
        _chr, start, end, strand, gene_name, status, _, p_value, q_value, count1, count2 = items
        if (_chr, strand, start, end) in okay_introns:
            p_value, q_value = float(p_value), float(q_value)
            if p_value < p_value_cutoff:
                count1, count2 = float(count1), float(count2)
                if count1 == 0 or count2 == 0:
                    genes.add(gene_name)
                else:
                    l2fc = np.log2(count1 / count2)
                    if abs(l2fc) > l2fc_cutoff:
                        genes.add(gene_name)

    cond1, cond2 = lines[0].strip().split()[-2:]
    cond1, cond2 = cond1[16:-1], cond2[16:-1]
    result[cond1][cond2] = len(genes)
    result[cond2][cond1] = len(genes)

data_df = pd.DataFrame.from_dict(result)
conds = data_df.index.tolist()
data_df = data_df[conds]
data_df.to_csv(base_dir / f'DSA_distance_matrix_l2fc{l2fc_cutoff}.txt', sep='\t')
data_df = data_df.fillna(0)

sns.set(font="monospace")
linkage = hc.linkage(sp.distance.squareform(data_df), method='average')
figure = sns.clustermap(data_df, row_linkage=linkage, col_linkage=linkage, cmap=sns.cm.rocket_r)
figure.savefig(base_dir / f'DSA_distance_matrix_l2fc{l2fc_cutoff}_heatmap.png')
plt.close()
