JUTILS=/scratch4/lflorea1/shared/sw/src/Jutils-1.5/jutils.py
#  convert mntjulip results to jutils results
parallel "python $JUTILS convert-results --mntjulip-dir {} --out-dir {}.jutils" ::: $dir
#  plot pca from jutils results
parallel "python3 $JUTILS pca --meta-file ../*meta --tsv-file mntjulip_{}_results.tsv --out-dir {} --p-value 1.0 --dpsi 0" ::: DSR DSA

python3 $JUTILS pca --meta-file ../Frontal_cortex.splice_list.MvsF.age_cov.nonempty.jutils_meta --tsv-file mntjulip_DSR_results.tsv --out-dir mntjulip_DSR_results.tsv.pca.highlight --p-value 1.0 --dpsi 0 --color-shape-col 3,2 --highlight-idlist-file ../Frontal_cortex.splice_list.MvsF.age_cov.nonempty.jutils_meta.id

parallel "python3 $JUTILS pca --meta-file ../Frontal_cortex.splice_list.MvsF.age_cov.nonempty.jutils_meta --tsv-file {} --out-dir {}.PCA --p-value 1.0 --dpsi 0 --color-shape-col 3,2" ::: mntjulip_*_results.tsv

#  plot heatmap
bash filter_TSV_aggregate2.sh mntjulip_DSR_results.tsv ../Frontal_cortex.splice_list.MvsF.nonempty.jutils_meta
python3 $JUTILS heatmap --tsv-file mntjulip_DSA_results.tsv --meta-file Frontal_cortex.splice_list.MvsF.nonempty.ordered_jutils_meta --out-dir fc2 --fold-change 2.0
