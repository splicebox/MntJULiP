import sys
import os
import pandas as pd

filter_res=pd.read_csv(sys.argv[1],header=None,sep=' ',skiprows=1)
sim_100_ds=pd.read_csv(sys.argv[2],header=None,sep='\t')
sim_100_deds=pd.read_csv(sys.argv[3],header=None,sep='\t')
sim_disease_100_ds=pd.read_csv(sys.argv[4],header=None,sep='\t')
sim_disease_100_deds=pd.read_csv(sys.argv[5],header=None,sep='\t')
sim_disease_100s2_ds=pd.read_csv(sys.argv[6],header=None,sep='\t')
sim_disease_100s2_deds=pd.read_csv(sys.argv[7],header=None,sep='\t')
sim_200s2_ds=pd.read_csv(sys.argv[8],header=None,sep='\t')
sim_200s2_deds=pd.read_csv(sys.argv[9],header=None,sep='\t')
sim_2000=pd.read_csv(sys.argv[10],header=None,sep='\t')

gene_res=filter_res[1].drop_duplicates()

sum_n=0
for e in enumerate([sim_100_ds,sim_100_deds,sim_disease_100_ds,sim_disease_100_deds,sim_disease_100s2_ds,sim_disease_100s2_deds,sim_200s2_ds,sim_200s2_deds]):
    fn=os.path.basename(sys.argv[e[0]+2])
    print(fn)
    gene_uniq=e[1][0].drop_duplicates()
    gene_uniq_in_res=gene_uniq.isin(gene_res)
    n=sum(gene_uniq_in_res)
    gene_uniq[gene_uniq_in_res].to_csv(f'{fn}_gene_uniq_in_res',header=None,index=False)
    print(n)
    sum_n+=n
print(sys.argv[10])
n_2000=sum(sim_2000[8].drop_duplicates().isin(gene_res))
print(n_2000-sum_n)
print('all gencode')
print(len(gene_res)-n_2000)
print('***')

