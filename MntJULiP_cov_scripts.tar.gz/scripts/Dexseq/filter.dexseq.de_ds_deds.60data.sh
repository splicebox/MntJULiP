python3 isin.gene_name.de_ds_deds.DSR.dexseq.py $1 \
    df_100_ds.flippedtop2.100genes \
    df_100_deds.100genes \
    df_disease_100_ds.flippedtop2.100genes \
    df_disease_100_deds.100genes \
    df_disease_100s2_ds.flippedtop2.100genes \
    df_disease_100s2_deds.100genes \
    df_200s2_ds.flippedtop2.200genes \
    df_200s2_deds.200genes \
    t_data.ctab.2000gene.protein_coding
