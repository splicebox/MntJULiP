library(GenomicFeatures)  # for the exonicParts() function
library(txdbmaker)
txdb = makeTxDbFromGFF("gencode.v41.annotation.gtf.gz")
flattenedAnnotation = exonicParts( txdb, linked.to.single.gene.only=TRUE )
names(flattenedAnnotation) =
        sprintf("%s:E%0.3d", flattenedAnnotation$gene_id, flattenedAnnotation$exonic_part)
library(pasillaBamSubset)
library(Rsamtools)
library(GenomicAlignments)
bamFiles <- character()
for (i in c(1:8,19:22,33:40)) {
file_name <- paste0( sprintf("sample_%02d_1.fasta.STARAligned.sortedByCoord.out.bam", i))
bamFiles <- c(bamFiles, file_name)
}
bamFiles = BamFileList( bamFiles )
seqlevelsStyle(flattenedAnnotation) = "UCSC"
se = summarizeOverlaps(
                           flattenedAnnotation, BamFileList(bamFiles), singleEnd=FALSE,
                               fragments=TRUE, ignore.strand=TRUE )
library(DEXSeq)
colData(se)$condition = c( rep("c", 10), rep("d", 10) )
colData(se)$sex = c( rep("M", 8),rep("F",2),rep("M",2), rep("F", 8) )

# if without cov
dxd = DEXSeqDataSetFromSE( se, design= ~ sample + exon +  condition:exon )
# else if with cov
#dxd = DEXSeqDataSetFromSE( se, design= ~ sample + exon + sex:exon + condition:exon )

dxd = estimateSizeFactors( dxd )
dxd = estimateDispersions( dxd )

# if without cov
dxd = testForDEU( dxd )
# else if with cov
#dxd=testForDEU(dxd, reducedModel=~sample+exon+sex:exon)

dxr1 = DEXSeqResults( dxd )
library(dplyr)
write.table(dxr1|> as_tibble() |> select_if(~is.character(.x) | is.numeric(.x)),"dexseq.res")
