DSA_FILTERED=diff_introns.txt.005pval
less diff_introns.txt |awk '{if ($8<=0.05) print}' > $DSA_FILTERED
python isin.gene_name.de_ds_deds.multi_DSA.py $DSA_FILTERED \
    df_100_de \
    df_100_ds.flippedtop2 \
    df_100_deds \
    df_disease_100_de \
    df_disease_100_ds.flippedtop2 \
    df_disease_100_deds \
    df_disease_100s2_de \
    df_disease_100s2_ds.flippedtop2 \
    df_disease_100s2_deds \
    df_200s2_de \
    df_200s2_ds.flippedtop2 \
    df_200s2_deds \
    t_data.ctab.2000gene.protein_coding
