DSR_FILTERED=filter.noparam
python3 filter_DSR_introns.py --dir . > ./$DSR_FILTERED
python isin.gene_name.de_ds_deds.DSR.multi.py ./$DSR_FILTERED \
    df_100_ds.flippedtop2 \
    df_100_deds \
    df_disease_100_ds.flippedtop2 \
    df_disease_100_deds \
    df_disease_100s2_ds.flippedtop2 \
    df_disease_100s2_deds \
    df_200s2_ds.flippedtop2 \
    df_200s2_deds \
    t_data.ctab.2000gene.protein_coding

