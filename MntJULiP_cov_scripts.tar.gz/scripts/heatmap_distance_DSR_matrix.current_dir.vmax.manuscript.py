import numpy as np
from collections import defaultdict
from pathlib import Path
import pandas as pd
import sys
import os
import seaborn as sns
import scipy.spatial as sp
import scipy.cluster.hierarchy as hc
import matplotlib.pyplot as plt

PATH='.'
folders = files = [f for f in os.listdir(PATH) if os.path.isdir(f)]

result = defaultdict(dict)
dpsi_cutoff = 0.2
p_value_cutoff = 0.05


base_dir = Path(PATH)
for folder in folders:
    file = base_dir / folder / 'diff_spliced_groups.txt'
    with open(file, 'r') as f:
        lines = f.readlines()

    significant_groups = set()
    for line in lines[1:]:
        group_id, _chr, _, strand, gene_names_str, _, _, p_value, q_value = line.strip().split('\t')

        p_value, q_value = float(p_value), float(q_value)
        if p_value <= p_value_cutoff :
            significant_groups.add(group_id) 

    file = base_dir / folder / 'diff_spliced_introns.txt'
    with open(file, 'r') as f:
        lines = f.readlines()

    genes = set()
    for line in lines[1:]:
        items = line.strip().split('\t')
        group_id, _chr, start, end, strand, gene_name, _, _, dpsi = items
        start, end, dpsi = int(start), int(end), float(dpsi)
        if abs(dpsi) > dpsi_cutoff and group_id in significant_groups:
            genes.add(gene_name)

    cond1, cond2 = lines[0].strip().split()[-3:-1]
    cond1, cond2 = cond1[4:-1], cond2[4:-1]
    result[cond1][cond2] = len(genes)
    result[cond2][cond1] = len(genes)

data_df = pd.DataFrame.from_dict(result)
conds = data_df.index.tolist()
data_df = data_df[conds]
data_df.sort_index(axis=0, inplace=True)
data_df.sort_index(axis=1, inplace=True)
data_df.to_csv(base_dir / f'DSR_distance_matrix_dpsi{dpsi_cutoff}.txt', sep='\t')
data_df=pd.read_csv(base_dir / f'DSR_distance_matrix_dpsi{dpsi_cutoff}.txt', sep='\t', index_col=[0])
data_df = data_df.fillna(0)

sns.set(font="monospace")
linkage = hc.linkage(sp.distance.squareform(data_df), method='average')
VMAX=700
FONT=1.5
sns.set(font_scale=FONT)
figure = sns.clustermap(data_df, row_linkage=linkage, col_linkage=linkage, cmap=sns.cm.rocket_r,vmax=VMAX, cbar_kws={"ticks":[0,200,400,600]})
figure.savefig(base_dir / f'DSR_distance_matrix_dpsi{dpsi_cutoff}_heatmap.vmax{VMAX}.font{FONT}.png')
plt.close()
