parallel \
    "samtools index {};\
    regtools junctions extract -a 8 -m 50 -M 500000 {} -s 0 -o {}.junc;\
    echo {}.junc >> leafcutter_juncfiles.txt" ::: *bam
python /data/lflorea1/wlui3/tools/leafcutter/clustering/leafcutter_cluster_regtools.py -j leafcutter_juncfiles.txt -m 50 -o lc -l 500000
leafcutter_ds.R --num_threads 4 ../lc_perind_numers.counts.gz leafcutter.groups-file

