#!/usr/bin/perl
use strict;

my $P_CUTOFF = 1.0;
my $Q_CUTOFF = 1.0;
my $DPSI_CUTOFF = 0.0;

my $Usage = "Usage: $0 metadata_file tsv_file -p pval_cutoff -q qval_cutoff -dpsi dpsi_cutoff\n";
($#ARGV==7) or die $Usage;
my $metadataFile = shift;
my $tsvFile = shift;
   $P_CUTOFF = shift; ($P_CUTOFF eq "-p") or die $Usage;
   $P_CUTOFF = shift; ($P_CUTOFF>=0.0 && $P_CUTOFF<=1.0) or die "Error: pval_cutoff should be between [0,1].\n";
   $Q_CUTOFF = shift; ($Q_CUTOFF eq "-q") or die $Usage;
   $Q_CUTOFF = shift; ($Q_CUTOFF>=0.0 && $Q_CUTOFF<=1.0) or die "Error: qval_cutoff should be between [0,1].\n";
   $DPSI_CUTOFF = shift; ($DPSI_CUTOFF eq "-dpsi") or die $Usage;
   $DPSI_CUTOFF = shift; ($DPSI_CUTOFF>=0.0 && $DPSI_CUTOFF<=1.0) or die "Error: dpsi_cutoff should be between [0,1].\n";

my %sampleCond;
my @SAMPLES = ();
my $CTRL;

# turns out this is not really needed, because decisions can be done using psiCtrl and psiTest
my $numSamples = 0;
open(M, "<$metadataFile")  or die "could not open medatada file. $metadataFile\n";
while (<M>) {
   chomp;
   /^(\S+)\t(\S+)$/ or die "died (1). $_";
   my ($set,$cond) = ($1,$2);
   $sampleCond{$set} = $cond;
   push @SAMPLES, $set;
   if (++$numSamples==1) { $CTRL = $cond; }
}
close(M);

#print STDERR "numSamples: ", $numSamples, " numCond: ", scalar(keys %sampleCond), " controlCond: ", $CTRL, "\n";

#test that the TSV file is sorted by group
my ($g,$prevg);
my %Seen;
open(F, "<$tsvFile") or die "could not open TSV file. $tsvFile\n";
while (<F>) {
   next if (/^#/ || /^GeneName/);

   /^\S+\t(\S+)\t/ or die "died (2). $_";
   my $g = $1;
   !defined($prevg) or ($prevg eq $g) or (!defined($Seen{$g})) or die "Error: File is not sorted by group ID. $_";
   $prevg = $g;
   $Seen{$g} = 1;
}
undef %Seen;
undef $g; undef $prevg;


seek F, 0, 0;

my $groupLines = "";
while (<F>) {
   if (/^#/ || /^GeneName/) { print $_, "\n"; next; }

   /^\S+\t(\S+)\t/ or die "died (3). $_";
   my $g = $1;

   if (defined($prevg) && ($g ne $prevg)) {
      my $st = &process_group($groupLines);
      if ($st ne "") {
	 print $st;
      }
      $groupLines = "";
   }
   $prevg = $g;
   $groupLines .= $_;
}
if (defined($prevg)) {
   my $st = &process_group($groupLines);
   if ($st ne "") {
      print $st;
   }
}
close(F);

      
#WASH7P  g000001 i002    intron  chr1:16765-16854        -       0.786025        1       -0.03232        0,0,1,1,27,0,144,17,0,87,2,42,42,22,72,70,22,0,44,1,205,2,69,146,0,2,1,0,50,31,81,104,94,0,245,0,0,97,0,0,0,1,1,136,0,404,0,0,89,477,0,0,89,1,0,85,61,168,1,3,7,0,0,18,0,12,7,0,0,0,54,105,0,152,0,0,2,0,9,4,13,0,1,276,0,0,0,0,11,0,128,258,0,695,24,41,1,1,34,0,33,0,19,644,3,173     .       nan,nan,0.00505051,0.002331,0.247706,0,0.108189,0.0748899,0,0.196833,0.00502513,0.2,0.0556291,0.0604396,0.0466019,0.319635,0.0187075,0,0.0817844,0.0243902,1,1,0.177378,0.348449,0,1,0.000926784,nan,0.045208,0.246032,0.228814,0.245863,0.264789,0,0.206056,0,0,0.316993,0,0,0,0.0116279,0.000906618,0.362667,0,0.451902,0,0,0.173489,0.583843,0,0,0.171815,0.0133333,0,0.467033,1,0.168844,0.333333,0.00940439,0.03125,nan,0,0.0807175,nan,0.196721,0.0736842,0,0,0,0.0888158,0.243056,0,0.125,nan,0,1,0,0.0108696,0.0122324,0.0828025,0,1,0.528736,0,nan,0,nan,0.0138889,0,0.263918,0.289238,0,0.177432,0.0769231,0.097852,0.00662252,0.00255754,0.196532,0,0.0755149,0,0.088785,1,0.00471698,0.401392       0.219497        0.187177

sub process_group { #
   my $ll = shift;
   my @Lines = split '\n', $ll;

   my $numI = scalar(@Lines);

   my $st;

   # read from the data
   my ($groupGene,$groupId,$groupFeature,$groupOri,$groupPval,$groupQval);
   my @iIdx = (); my @iLabel = (); my @idPSI = (); my @iR1 = (); my @iR2 = (); my @iPSI = (); my @iPsiCtrl = (); my @iPsiTest = (); my @iPass = ();

   for (my $i=0; $i<$numI; $i++) {
      if (!$i) {
         $Lines[$i] =~ /^(\S+)\t(\S+)\t\S+\t(\S+)\t\S+\t(\S)\t(\S+)\t(\S+)\t/ or die "died (4). $_";
	 ($groupGene,$groupId,$groupFeature,$groupOri,$groupPval,$groupQval) = ($1,$2,$3,$4,$5,$6);
      }

      #EPB41	g000378	i001	intron	chr1:29053312-29058589	+	0.000429802	0.0569585	0.323593	0,0,0,15,0,45,42,0,49,97	.	nan,nan,nan,0.319149,0,1,0.875,nan,1,0.97		0.414369	0.737962
      $Lines[$i] =~ /^\S+\t\S+\t(\S+)\t\S+\t(\S+)\t\S\t\S+\t\S+\t(\S+)\t(\S+)\t(\S+)\t(\S+)\t(\S+)\t(\S+)$/ or die "died (5). $_";
      my ($iidx,$ilabel,$idpsi,$ir1,$ir2,$ipsi,$ipsi0,$ipsi1) = ($1,$2,$3,$4,$5,$6,$7,$8);
      $iIdx[$i] = $iidx;
      $iLabel[$i] = $ilabel;
      $idPSI[$i] = $idpsi;
      $iR1[$i] = $ir1;
      $iR2[$i] = $ir2;
      $iPSI[$i] = $ipsi;
      $iPsiCtrl[$i] = $ipsi0;
      $iPsiTest[$i] = $ipsi1;
      if (($groupPval<=$P_CUTOFF) && ($groupQval<=$Q_CUTOFF) && (abs($idpsi)>=$DPSI_CUTOFF)) { 
         $iPass[$i] = 1;
      } else {
	 $iPass[$i] = 0; 
      }
   }
   my $numPass = 0;
   my $i0;
   for (my $i=0; $i<$numI; $i++) {
      $numPass += $iPass[$i];
      if ($iPass[$i]) { $i0 = $i; }
   }
   if ($numPass==0) { # no line passed filtering
      return "";
   }
   #  elsif ($numPass==1) { # report that line
   #    # IMPORTANT: If only one record, then only the info (delta) for that record will be reported, not for all records going in that direction
#       # It may need to be changed, in which case simply go through the code below
   #    $st  = "$groupGene\t$groupId\t" . $iIdx[$i0] . "\t$groupFeature\t";
   #    $st .= $iLabel[$i0] . "\t$groupOri\t$groupPval\t$groupQval\t";
   #    $st .= $idPSI[$i0] . "\t" . $iR1[$i0] . "\t" . $iR2[$i0] . "\t";
   #    $st .= $iPSI[$i0] . "\t" . $iPsiCtrl[$i0] . "\t" . $iPsiTest[$i0] . "\n";
   #
   #    return $st;
   #}

   #
   # find argmax @iPsiCtrl 
   for (my $i=0; $i<$numI; $i++) {
      if ($iPass[$i] && (!defined($i0) || ($iPsiCtrl[$i]>$iPsiCtrl[$i0]))) { $i0 = $i; }
   }
   # i0 = representative for the group
   # calculate from the data:
   my ($groupRepIdx,$groupRepLabel,$groupRepdPSI,$groupRepR1,$groupRepR2,$groupRepPSI,$groupRepPsiCtrl,$groupRepPsiTest);
   $groupRepIdx = $iIdx[$i0];
   $groupRepLabel = $iLabel[$i0];

   $groupRepR1 = ""; $groupRepR2 = ""; $groupRepPSI = "";
   my $direction = ($iPsiTest[$i0]-$iPsiCtrl[$i0]);
   for (my $i=0; $i<$numI; $i++) {
     if ($direction*($iPsiTest[$i]-$iPsiCtrl[$i])>=0) { # same direction
        $groupRepdPSI += $idPSI[$i];
	$groupRepR1 = &add_vectors($numSamples,$groupRepR1,$iR1[$i]);  # what if groupRepR1 is undef? Nope, it is ""
	$groupRepR2 = &add_vectors($numSamples,$groupRepR2,$iR2[$i]);
	$groupRepPSI = &add_vectors($numSamples,$groupRepPSI,$iPSI[$i]);
	$groupRepPsiCtrl += $iPsiCtrl[$i];
	$groupRepPsiTest += $iPsiTest[$i];
     } else { # opposite direction of variation
         ;
     }
   }  

   # no longer needed
#  my $maxdpsi;
#  for (my $i=0,$maxdpsi=abs($idPSI[0]); $i<$numI; $i++) {
#    if (abs($idPSI[$i])>$maxdpsi) { $maxdpsi = abs($idPSI[$i]); }
#  }

   # GeneName        GroupID FeatureID       FeatureType     FeatureLabel    strand  p-value q-value dPSI    ReadCount1      ReadCount2      PSI     psi(0_hneg)     psi(1_hpos)
   # $groupFeature,$groupOri,$groupPval,$groupQval
   $st = "$groupGene\t$groupId\tA.$groupRepIdx\t$groupFeature\t$groupRepLabel\t$groupOri\t$groupPval\t$groupQval\t";
   $st .= "$groupRepdPSI\t$groupRepR1\t$groupRepR2\t$groupRepPSI\t$groupRepPsiCtrl\t$groupRepPsiTest\n";

   return $st;
}

# add two vectors
sub add_vectors { #numSamples gR1 R1, returns the sum
   my ($ns,$gr1,$r1) = @_;
   my @GR1 = split ',', $gr1;
   my @R1 = split ',', $r1;
   my @OUTR = ();

   if ($gr1 eq "") { return $r1; }
   if ($r1 eq ".") { return (($gr1 eq ".") ? "." : $gr1); } 

   for (my $i=0; $i<$ns; $i++) {
      if (($GR1[$i] eq "nan") || ($R1[$i] eq "nan")) { $OUTR[$i] = "nan"; }
      else { $OUTR[$i] = $GR1[$i]+$R1[$i]; }
   }

   return join ',', @OUTR;
}
 
exit(0);
