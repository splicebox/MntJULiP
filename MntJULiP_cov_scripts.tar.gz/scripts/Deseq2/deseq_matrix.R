library( "DESeq2" )
# read in the read count data

cts <- as.matrix(read.csv("mntj.60.introns.df",sep=",",row.names=1))

# read in the column name data; MUST match the rows of the column data
coldata<- read.csv("deseq_coldata.8M2F8F2M",sep="\t", row.names=1)

dds <-DESeqDataSetFromMatrix(countData = cts[, c(1:8, 19:22, 33:40)],colData=coldata,design=~sex+condition)
dds <-DESeq(dds)

res_dds<-results(dds)
res_pval0.05 <-res_dds[ which(res_dds$pvalue <= 0.05 ), ]

write.csv( round(counts(dds, normalized=TRUE),digits=2), file="splice.csv" )
write.csv( as.data.frame(res_dds), file="splice.res" )
write.csv( as.data.frame(res_pval0.05), file="splice.p005" )
