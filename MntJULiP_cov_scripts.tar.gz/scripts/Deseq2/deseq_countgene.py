from utils import process_annotation
from utils import get_gene_names
import sys
import pandas as pd
fn=sys.argv[1]
anno_file='gencode.v41.annotation.gtf'
anno_intron_dict, start_site_genes_dict, end_site_genes_dict = process_annotation(anno_file)
anno_info = (anno_intron_dict, start_site_genes_dict, end_site_genes_dict)
df=pd.read_csv(fn)
df.columns=['index','baseMean', 'log2FoldChange', 'lfcSE', 'stat', 'pvalue', 'padj']
gene_list=[get_gene_names(anno_info,eval(gene)) for gene in df['index']]
df['gene']=gene_list
df.to_csv(f'{fn}.deseq_genes',index=False,sep='\t')
