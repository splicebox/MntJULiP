cat $1 | grep -v GeneName | grep -v "^#" | sort -k2 > $1.sorted.tsv
perl filter_TSV_aggregate2.pl $2 $1.sorted.tsv -p 0.05 -q 1.0 -dpsi 0.05 > $1.p05.dpsi05.aggregate.tsv
cat mntjulip_DSR_results.tsv.header $1.p05.dpsi05.aggregate.tsv > $1.p05.dpsi05.aggregate.header.tsv; rm -f $1.p05.dpsi05.aggregate.tsv
