python isin.gene_name.de_ds_deds.multi_DSR.py $1 \
    df_100_ds.flippedtop2 \
    df_100_deds \
    df_disease_100_ds.flippedtop2 \
    df_disease_100_deds \
    df_disease_100s2_ds.flippedtop2 \
    df_disease_100s2_deds \
    df_200s2_ds.flippedtop2 \
    df_200s2_deds \
    t_data.ctab.2000gene.protein_coding
