from utils import process_annotation
from utils import get_gene_names
import sys
import pandas as pd
counts_fn=sys.argv[1]
anno_file='gencode.v41.annotation.gtf'
anno_intron_dict, start_site_genes_dict, end_site_genes_dict = process_annotation(anno_file)
anno_info = (anno_intron_dict, start_site_genes_dict, end_site_genes_dict)
df=pd.read_csv(counts_fn,sep='\t',header=None)
df[0]=df[0].apply(lambda x: x.split('_')[0])
gene_list=[get_gene_names(anno_info,eval(gene)) for gene in df[0]]
df['gene']=gene_list
df.to_csv(f'{counts_fn}.genetable',index=False,sep='\t')
res=pd.read_csv(f'{counts_fn}.res.q005',sep=' ')
m=res.merge(df,left_on=['gene_id'],right_on=[1])
m['gene'].drop_duplicates().to_csv(f'{counts_fn}.final_genelist',header=None,index=False,sep='\t')
