library(DRIMSeq)
metadata <- read.table("splice.8M2Fv8F2M.cov",
                       header = TRUE, as.is = TRUE)
counts <- read.table("drimseq.counts.8M2F",
                     header = FALSE, as.is = TRUE, sep="\t")
colnames(counts)=c("feature_id","gene_id",paste0(1:20))
samples <- data.frame(sample_id = paste0(1:20), group = metadata$condition, sex=metadata$sex)

d <- dmDSdata(counts = counts, samples = samples)
design_full <- model.matrix(~ group+sex, data = samples(d))

set.seed(123)
d <- dmPrecision(d, design = design_full)
d <- dmFit(d, design = design_full, verbose = 1)
d <- dmTest(d, coef = "group", verbose = 1)
write.table(results(d),'drimseq.res')
