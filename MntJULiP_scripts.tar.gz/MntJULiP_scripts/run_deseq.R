# R CMD BATCH run_deseq.R
library( "DESeq2" )
library( "GenomicFeatures" )
library( "Rsamtools" )
library( "GenomicAlignments" )

fls_subset <- list.files( "/ccb/salz3/gyang/hpvop/BAMs/", pattern="bam$", full=TRUE )  ##

hse <- makeTxDbFromGFF( "/ccb/salz3/gyang/simulation3/gencode.v22.annotation.gtf", format="gtf" ) ##
exonsByGene <- exonsBy( hse, by="gene" ) ##

bamLst <- BamFileList( fls_subset, yieldSize=100000 )

se <- summarizeOverlaps(features=exonsByGene, reads=bamLst, mode="Union", singleEnd=FALSE, ignore.strand=TRUE, fragments=TRUE)

sampleInfo <- read.csv( "pheno_hpvop.csv" ) ##

seIdx <- match(colnames(se), sampleInfo$sample)
head( cbind( colData(se), sampleInfo[ seIdx, ] ) )
colData(se) <- cbind( colData(se), sampleInfo[ seIdx, ] )

dds <- DESeqDataSet( se, design = ~ condition)
dds$condition <- relevel( dds$condition, "normal" )
dds <- DESeq(dds)
res <- results(dds)

res_pval0.05 <-res[ which(res$pvalue <= 0.05 ), ]
res_qval0.05 <-res[ which(res$padj <= 0.05 ), ]

write.csv( as.data.frame(res), file="results.csv" ) ##
write.csv( as.data.frame(res_pval0.05), file="results.pval05.csv" ) ##
write.csv( as.data.frame(res_qval0.05), file="results.qval05.csv" ) ##
