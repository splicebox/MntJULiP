BASE_DIR="/home-2/gyang22@jhu.edu/work/projects/HPVOP/"
DATA_DIR="${BASE_DIR}/Star/"
WORK_DIR="${BASE_DIR}/Mnt_JULiP"
mkdir -p ${WORK_DIR}


# rm -rf ${WORK_DIR}/hpvop.bam.txt
# echo -e "sample\tcondition" > ${WORK_DIR}/hpvop.bam.txt

# for name in DGay20-25475 DGay19-25350 DGay19-25341 DGay18-25305 DGay17-25343 DGay16-25081 DGay15-28675 DGay13-27929 DGay12-27911 DGay9-28661 DGay1-28639 DGay4-28668 DGay7-30948 DGay10-30987 DGay11-30975 DGay2-30942 DGay6-30961 DGay9-30972 DGay8-30977 DGay7-30911 DGay5-30951 DGay11-30944 DGay10-30973 DGay14-31844 DGay3-37091
# do
#     echo -e "${DATA_DIR}/${name}/Aligned.sortedByCoord.out.bam\tnormal" >> ${WORK_DIR}/hpvop.bam.txt
# done

# for name in DGay4-37924 DGay3-37963 DGay25-41792 DGay15-39125 DGay15-37916 DGay1-35691 DGay22-25031 DGay23-32806 DGay5-35671 DGay26-41507 DGay10-26144 DGay6-24648 DGay23-41797 DGay8-22934 DGay17-40991 DGay24-41800 DGay6-35696 DGay22-41517 DGay2-39164 DGay5-39184 DGay1-39149 DGay8-30811 DGay24-27879 DGay24-41672 DGay14-28000 DGay26-41780 DGay25-27432 DGay19-40965 DGay16-25742 DGay16-39136 DGay18-39128 DGay3-37792 DGay2-30686 DGay20-40655 DGay23-41777 DGay13-39133 DGay14-39174 DGay17-39152 DGay9-39200 DGay12-25770 DGay11-25769 DGay13-39141 DGay21-40932 DGay4-39113 DGay21-22906 DGay20-40663
# do
#     echo -e "${DATA_DIR}/${name}/Aligned.sortedByCoord.out.bam\ttumor" >> ${WORK_DIR}/hpvop.bam.txt
# done

# 71 samples, Tumor 46, Normal 25

cd ~/MntJULiP/
module load gcc/6.4.0.lua

/software/apps/python/3.7/bin/python3 run.py --out-dir ${WORK_DIR} \
               --bam-list ${WORK_DIR}/hpvop.bam.txt \
               --num-threads 23 \
               --min-count 5 \
               --batch-size 2000 \
               --anno-file ${BASE_DIR}/gencode.v22.annotation.gtf


########################
# BASE_DIR="/home-2/gyang22@jhu.edu/work/projects/HPVOP/"
WORK_DIR="${BASE_DIR}/Mnt_JULiP_with_variances"
mkdir -p ${WORK_DIR}

cd ~/MntJULiP/
module load gcc/6.4.0.lua

/software/apps/python/3.7/bin/python3 run.py --out-dir ${WORK_DIR} \
               --bam-list ${WORK_DIR}/hpvop.bam.txt \
               --num-threads 23 \
               --min-count 5 \
               --batch-size 2000 \
               --debug \
               --anno-file ${BASE_DIR}/gencode.v22.annotation.gtf

## run mntjulip on salz machine
SOFTWARE_DIR='/ccb/salz3/gyang/softwares/'
BASE_DIR="/ccb/salz3/gyang/hpvop"
WORK_DIR="${BASE_DIR}/Mnt_JULiP_with_variances"

cd ${SOFTWARE_DIR}/MntJULiP

python3 run.py --out-dir ${WORK_DIR} \
               --bam-list ${WORK_DIR}/hpvop.bam.txt \
               --num-threads 23 \
               --min-count 5 \
               --batch-size 2000 \
               --debug \
               --anno-file /ccb/salz3/gyang/simulation3/gencode.v22.annotation.gtf
