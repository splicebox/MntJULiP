
gtf_file = '/ccb/salz3/gyang/simulation3/gencode.v22.annotation'
out_file = '/ccb/salz3/gyang/simulation3/meta_info/gencode_exons.txt'
gene_chr_strand_dict = {}
strings = []
with open(gtf_file, 'r') as f:
    for line in f:
        if line.startswith('#'):
            continue
        if line is not '\n':
            items = line.strip().split('\t')
            if items[2] == 'exon':
                _chr, strand = items[0], items[6]
                start, end = items[3: 5]
                _items = items[8].split('"')
                gene_name = _items[9]
                strings.append(f"{_chr}\t{start}\t{end}\t{strand}\t{gene_name}\n")


with open(out_file, 'w') as f:
    f.write("chr\tstart\tend\tstrand\tgene_name\n")
    for _str in strings:
        f.write(_str)
