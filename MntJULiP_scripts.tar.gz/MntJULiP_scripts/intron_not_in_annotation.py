# dict tran and fpkm
from collections import defaultdict

import numpy as np


def get_introns(exons):
    if len(exons) <= 1:
        return []
    else:
        introns = []
        _list = sorted(exons)
        start = _list[0][1]
        for i in range(1, len(_list)):
            end = _list[i][0]
            introns.append((start, end))
            start = _list[i][1]
        return introns


# read exon info from the file.
tran_exons_dict = defaultdict(list)
gtf_file = '/Users/gyang/test/annotation.gtf'

gene_id_name_dict = {}
gene_name_id_dict = defaultdict(set)
tran_exons_dict = defaultdict(list)
with open(gtf_file, 'r') as f:
    for line in f:
        if line is not '\n':
            items = line.strip().split('\t')
            if items[2] == 'exon':
                _chr, strand = items[0], items[6]
                start, end = items[3: 5]
                _items = items[8].split('"')
                tran_id, gene_id = _items[3], _items[1]
                gene_id, gene_name = _items[1], _items[9]
                tran_exons_dict[(_chr, strand, tran_id)].append((int(start), int(end)))
                gene_id_name_dict[gene_id] = gene_name
                gene_name_id_dict[gene_name].add(gene_id)

# get intron info
tran_introns_dict = defaultdict(list)
intron_trans_dict = defaultdict(list)
ref_intron_dict = {}
tran_info_dict = {}
for (_chr, strand, tran_id), exons in tran_exons_dict.items():
    tran_info_dict[tran_id] = (_chr, strand, tran_id)
    introns = get_introns(exons)
    for intron in introns:
        tran_introns_dict[(_chr, strand, tran_id)].append((_chr, strand, *intron))
        intron_trans_dict[(_chr, strand, *intron)].append(tran_id)
        ref_intron_dict[(_chr, strand, *intron)] = 1

out_dir = '/Users/gyang/OneDrive/1-Florea Lab/New_JULiP_Paper/results'

##################

with open('/Users/gyang/test/simulation_3_out/intron_data.txt', 'r') as f:
    lines = f.readlines()

real_intron_dict = {}
_intron_avg_dpsi_dict = {}
for line in lines[1:]:
    _chr, start, end, strand, gene_name, status, read_counts1, read_counts2 = line.strip().split('\t')
    real_intron_dict[(_chr, strand, int(start), int(end))] = 1
    c1 = np.mean([float(v) for v in read_counts1.split(',')])
    c2 = np.mean([float(v) for v in read_counts2.split(',')])
    _intron_avg_dpsi_dict[(_chr, strand, int(start), int(end))] = c2 - c1

intron_avg_dpsi_dict = {}
with open(out_dir + '/' + 'intron_data.txt', 'w') as f:
    f.write(lines[0])
    for line in lines[1:]:
        _chr, start, end, strand, *others = line.strip().split('\t')
        if (_chr, strand, int(start), int(end)) not in ref_intron_dict:
            f.write(line)
            intron_avg_dpsi_dict[(_chr, strand, int(start), int(end))] = _intron_avg_dpsi_dict[(_chr, strand, int(start), int(end))]

# len(intron_avg_dpsi_dict): 781


###################
with open('/Users/gyang/test/simulation_3_out/diff_introns.txt', 'r') as f:
    lines = f.readlines()

test_intron_dict = {}
count = 0
outlier_gene_dict = {}
with open(out_dir + '/' + 'diff_introns.txt', 'w') as f:
    f.write(lines[0])
    for line in lines[1:]:
        _chr, start, end, strand, gene_name, status, _, p_value, q_value, _, _ = line.strip().split('\t')
        if (_chr, strand, int(start), int(end)) not in ref_intron_dict:
            f.write(line)
            if status == 'TEST' and float(p_value) < 0.1:
                count += 1
                outlier_gene_dict[gene_name] = 1
                test_intron_dict[(_chr, strand, int(start), int(end))] = p_value


# count: 133

###################
with open('/Users/gyang/test/simulation_3_out/diff_spliced_groups.txt', 'r') as f:
    lines = f.readlines()

group_id_p_value_dict = {}

with open('/Users/gyang/test/simulation_3_out/diff_spliced_introns.txt', 'r') as f:
    lines = f.readlines()

test_intron_dict = {}
count = 0
outlier_gene_dict = {}
with open(out_dir + '/' + 'diff_spliced_introns.txt', 'w') as f:
    f.write(lines[0])
    for line in lines[1:]:
        group_id, _chr, start, end, strand, gene_name, psi_cond1, psi_cond2, delta_psi = line.strip().split('\t')
        test_intron_dict[(_chr, strand, int(start), int(end))] = 1
        if (_chr, strand, int(start), int(end)) not in ref_intron_dict:
            f.write(line)
            count += 1
            outlier_gene_dict[gene_name] = 1
            if abs(float(delta_psi)) > 0.05:
                print(line)

# count: 78
