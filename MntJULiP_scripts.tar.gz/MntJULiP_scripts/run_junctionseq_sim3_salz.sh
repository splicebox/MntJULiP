# commands work on bash, in salz machine

QORTS=/ccb/salz3/gyang/QoRTs.jar
BASE_DIR="/ccb/salz3/gyang/simulation3"
WORK_DIR="${BASE_DIR}/JunctionSeq"
DATA_DIR="${BASE_DIR}/Tophat"
GTF="${BASE_DIR}/meta_info/annotation.gtf"

# rm -rf ${WORK_DIR}
mkdir -p ${WORK_DIR}/inputData/annoFiles/
mkdir -p ${WORK_DIR}/outputData/qortsData/
cd ${WORK_DIR}

#################### in Python， get chromesome length ##############################
# import pysam
# chrs = ['chr{}'.format(i) for i in range(1, 23)]
# chrs.extend(['chrX', 'chrY', 'chrM'])
# fasta_file = '/ccb/salz3/gyang/simulation3/meta_info/hg38.fa'
# fasta_obj = pysam.FastaFile(fasta_file)
# _dir="/ccb/salz3/gyang/simulation3/JunctionSeq/inputData/annoFiles/"
# chrom_size_file = _dir + 'chrom.sizes'
# with open(chrom_size_file,'w') as f:
#     for chr in chrs:
#         seq_chr = fasta_obj.fetch(chr)
#         f.write('{}\t{}\n'.format(chr, len(seq_chr)))
###########################################

for t in case control
do
    for i in {01..25}
    do
        java -Xmx18G -jar $QORTS QC \
             --minMAPQ 50 \ # set to 50 for tophat2
             --runFunctions writeKnownSplices,writeNovelSplices,writeSpliceExon \
             --chromSizes inputData/annoFiles/chrom.sizes \
             ${DATA_DIR}/${t}/sample_${i}/accepted_hits.bam \
             ${GTF} \
             outputData/qortsData/${t}_sample_${i}
    done
done

###########################################.  build decoder.byUID.txt  #####################################
uid_file="${WORK_DIR}/inputData/annoFiles/decoder.byUID.txt"
rm -rf ${uid_file}

echo -e "sample.ID\tlane.ID\tunique.ID\tqc.data.dir\tgroup.ID\tinput.read.pair.count" >> ${uid_file}
for t in case control
do
    for i in {01..25}
    do
        count=`samtools view -c ${DATA_DIR}/case/sample_${i}/accepted_hits.bam`
        echo -e "${t}_sample_${i}\tRG1\t${t}_sample_${i}_RG1\t${t}_sample_${i}\t${t}\t${count}" >> ${uid_file}
    done
done
##############################################################################

mkdir -p ${{WORK_DIR}/outputData/countTables/
java -jar $QORTS \
            mergeAllCounts \
            outputData/qortsData/ \
            inputData/annoFiles/decoder.byUID.txt \
            outputData/countTables/

###########################################.  build decoder.bySample.txt  #####################################
sample_file="${WORK_DIR}/inputData/annoFiles/decoder.bySample.txt"
rm -rf ${sample_file}

echo -e "sample.ID\tgroup.ID" >> ${sample_file}
for t in case control
do
    for i in {01..25}
    do
        echo -e "${t}_sample_${i}\t${t}" >> ${sample_file}
    done
done
##############################################################################

java -Xmx14G -jar $QORTS \
                mergeNovelSplices \
                --minCount 6 \
                outputData/countTables/ \
                inputData/annoFiles/decoder.bySample.txt \
                ${GTF} \
                outputData/countTables/

mkdir -p ${WORK_DIR}/outputData/analyses/JunctionSeq/results/

######################################### In R, run JunctionSeq ##########################
# suppressPackageStartupMessages(library("JunctionSeq"));
# #The sample decoder:
# decoder <- read.table("inputData/annoFiles/decoder.bySample.txt",
#                     header=T,stringsAsFactors=F);
# countFiles <- paste0("outputData/countTables/",
#                     decoder$sample.ID,
#                     "/QC.spliceJunctionAndExonCounts.withNovel.forJunctionSeq.txt.gz"
# );

# jscs <- runJunctionSeqAnalyses(sample.files = countFiles,
#                             sample.names = decoder$sample.ID,
#                             condition = factor(decoder$group.ID),
#                             flat.gff.file = "outputData/countTables/withNovel.forJunctionSeq.gff.gz",
#                             nCores = 20,
#                             verbose = TRUE,
#                             analysis.type = "junctionsAndExons",
# );

# writeCompleteResults(jscs,
#                     outfile.prefix = "outputData/analyses/JunctionSeq/",
#                     save.jscs = TRUE
# );
