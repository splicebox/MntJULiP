BASE_DIR="/ccb/salz3/gyang/simulation3"
DATA_DIR="${BASE_DIR}/Star/"
WORK_DIR="${BASE_DIR}/MAJIQ_gencode"
CNTRL_DIR="${BASE_DIR}/Star/control"
CASE_DIR="${BASE_DIR}/Star/case"
LOCAL_DATA_DIR="${WORK_DIR}/data"
SOFTWARE_DIR="/ccb/salz3/gyang/softwares"

unset PYTHONPATH
export PATH=/home/dyang/.local/bin:$PATH

mkdir -p ${LOCAL_DATA_DIR}
cd ${WORK_DIR}

cp -r ../MAJIQ/data .

cp -r ../MAJIQ/config.txt .


gff3="/ccb/salz3/gyang/simulation3/gencode.v22.annotation.gff3"

export PATH=${SOFTWARE_DIR}/python-3.6.8/bin:$PATH
export PYTHONPATH=${SOFTWARE_DIR}/python-3.6.8

threads=20
majiq build ${gff3} -c config.txt -j ${threads}  -o build_out

control_majiqs="build_out/control_01.majiq"
case_majiqs="build_out/case_01.majiq"
for i in {02..25}
do
    control_majiqs="${control_majiqs} build_out/control_${i}.majiq"
    case_majiqs="${case_majiqs} build_out/case_${i}.majiq"
done

threads=20
majiq deltapsi -grp1 `echo ${control_majiqs}` \
                              -grp2 `echo ${case_majiqs}` \
                              -j $threads \
                              -o dpsi_out \
                              -n control case


voila deltapsi dpsi_out/control_case.deltapsi.voila \
                     --splice-graph build_out/splicegraph.sql \
                     -j $threads \
                     --show-all \
                     -o voila_out
