import gzip
file = '/ccb/salz3/gyang/simulation3/meta_info/stmerged_exons.txt.gz'

with gzip.open(file, 'rb') as f:
    lines = f.readlines()

out_buffer = ''
for line in lines:
    items = line.decode('utf-8').strip().split('\t')
    if len(items) < 5:
        out_buffer += '\t'.join(items+['.\n'])
    else:
        out_buffer += line.decode('utf-8')

file = '/ccb/salz3/gyang/simulation3/LeafCutter/STMerged/stmerged_exons.txt.gz'
with open(file, 'w') as f:
    f.write(out_buffer)
