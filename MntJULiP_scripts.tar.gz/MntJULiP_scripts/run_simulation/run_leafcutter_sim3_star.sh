#!/bin/bash -l

BASE_DIR="/ccb/salz3/gyang/simulation3"
DATA_DIR="${BASE_DIR}/Star/"
WORK_DIR="${BASE_DIR}/LeafCutter"
LOCAL_DATA_DIR="${WORK_DIR}/data"

mkdir -p ${LOCAL_DATA_DIR}
cd ${WORK_DIR}

rm -rf test_juncfiles.txt test_diff_introns.txt

SOFTWARE_BASE_DIR="/ccb/salz3/gyang/softwares/leafcutter"
bam2junc="${SOFTWARE_BASE_DIR}/scripts/bam2junc.sh"
leafcutter_cluster="${SOFTWARE_BASE_DIR}/clustering/leafcutter_cluster.py"
leafcutter_ds="${SOFTWARE_BASE_DIR}/scripts/leafcutter_ds.R"
gtf_to_exons="${SOFTWARE_BASE_DIR}/scripts/gtf_to_exons.R"

PATH=$PATH:${SOFTWARE_BASE_DIR}/scripts

n=20
i=0
for t in 'case' 'control'
do
    for d in {01..25}
    do
        ln -s ${DATA_DIR}/${t}/sample_${d}/Aligned.sortedByCoord.out.bam ${LOCAL_DATA_DIR}/${t}_${d}.bam
        sh ${bam2junc} ${LOCAL_DATA_DIR}/${t}_${d}.bam ${LOCAL_DATA_DIR}/${t}_${d}.bam.junc &
        echo ${LOCAL_DATA_DIR}/${t}_${d}.bam.junc >> test_juncfiles.txt
        i=$(($i+1))
        if [ $i -eq $n ]; then
            wait
            i=0
        fi
    done
    wait
done
wait


# Rscript ${SOFTWARE_BASE_DIR}/scripts_to_exons.R


python ${leafcutter_cluster} -j test_juncfiles.txt -o results

for d in 'case' 'control'
do
    for i in {01..25}
    do
        echo "${d}_${i}.bam ${d}" >> test_diff_introns.txt
    done
done

threads=24
${leafcutter_ds} -p ${threads} -e "${BASE_DIR}/meta_info/exons.txt.gz" \
                 results_perind_numers.counts.gz \
                 test_diff_introns.txt

# http://davidaknowles.github.io/leafcutter/articles/Usage.html




############### with gencode annotation ########################################
mkdir gencode
cd genecode


threads=24
${leafcutter_ds} -p ${threads} -e "${BASE_DIR}/meta_info/gencode_exons.txt.gz" \
                 ${WORK_DIR}/results_perind_numers.counts.gz \
                 ${WORK_DIR}/test_diff_introns.txt



############### with reduced gencode 500 annotation ########################################
mkdir reduced_gencode_500
cd reduced_gencode_500

Rscript ${gtf_to_exons} ${BASE_DIR}/meta_info/reduced_gencode.v22.annotation_500_ds_genes.gtf.gz ${BASE_DIR}/meta_info/reduced_gencode_500_exons.txt.gz


threads=24
${leafcutter_ds} -p ${threads} -e "${BASE_DIR}/meta_info/reduced_gencode_500_exons.txt.gz" \
                 ${WORK_DIR}/results_perind_numers.counts.gz \
                 ${WORK_DIR}/test_diff_introns.txt


############### with reduced gencode 1000 annotation ########################################
mkdir reduced_gencode_1000
cd reduced_gencode_1000

Rscript ${gtf_to_exons} ${BASE_DIR}/meta_info/reduced_gencode.v22.annotation_1000_ds_genes.gtf.gz ${BASE_DIR}/meta_info/reduced_gencode_1000_exons.txt.gz

threads=24
${leafcutter_ds} -p ${threads} -e "${BASE_DIR}/meta_info/reduced_gencode_1000_exons.txt.gz" \
                 ${WORK_DIR}/results_perind_numers.counts.gz \
                 ${WORK_DIR}/test_diff_introns.txt


############### with stmerged annotation ########################################
mkdir STMerged
cd STMerged

Rscript ${gtf_to_exons} ${BASE_DIR}/stringtie/sim.stmerged.modified.gtf.gz ${BASE_DIR}/meta_info/stmerged_exons.txt.gz

threads=24
${leafcutter_ds} -p ${threads} -e '/ccb/salz3/gyang/simulation3/LeafCutter/STMerged/stmerged_exons.txt.gz' \
                 ${WORK_DIR}/results_perind_numers.counts.gz \
                 ${WORK_DIR}/test_diff_introns.txt
