BASE_DIR="/ccb/salz3/gyang/simulation3"
CNTRL_DIR="${BASE_DIR}/Star/control"
CASE_DIR="${BASE_DIR}/Star/case"
SOFTWARE_DIR="/ccb/salz3/gyang/softwares"
RMATS="/ccb/salz3/gyang/softwares/rMATS.3.2.5/RNASeq-MATS.py"
GTF="${BASE_DIR}/meta_info/annotation.gtf"


WORK_DIR="${BASE_DIR}/rMATS.3.2.5"
mkdir -p ${WORK_DIR}
cd ${WORK_DIR}

control_bams="${CNTRL_DIR}/sample_01/Aligned.sortedByCoord.out.bam"
case_bams="${CASE_DIR}/sample_01/Aligned.sortedByCoord.out.bam"
for i in {02..25}
do
    control_bams="${control_bams},${CNTRL_DIR}/sample_${i}/Aligned.sortedByCoord.out.bam"
    case_bams="${case_bams},${CASE_DIR}/sample_${i}/Aligned.sortedByCoord.out.bam"
done

python ${RMATS} \
       -b1 ${control_bams} \
       -b2 ${case_bams} \
       -gtf ${GTF} \
       -o out -t paired -len 101

wait
