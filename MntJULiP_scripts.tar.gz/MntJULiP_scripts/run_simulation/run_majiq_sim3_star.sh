BASE_DIR="/ccb/salz3/gyang/simulation3"
DATA_DIR="${BASE_DIR}/Star/"
WORK_DIR="${BASE_DIR}/MAJIQ"
CNTRL_DIR="${BASE_DIR}/Star/control"
CASE_DIR="${BASE_DIR}/Star/case"
LOCAL_DATA_DIR="${WORK_DIR}/data"
SOFTWARE_DIR="/ccb/salz3/gyang/softwares"

unset PYTHONPATH
export PATH=/home/dyang/.local/bin:$PATH

mkdir -p ${LOCAL_DATA_DIR}
cd ${WORK_DIR}

n=20
i=0
for t in case control
do
  for d in {01..25}
  do
      ln -s ${DATA_DIR}/${t}/sample_${d}/Aligned.sortedByCoord.out.bam ${LOCAL_DATA_DIR}/${t}_${d}.bam
      samtools index ${LOCAL_DATA_DIR}/${t}_${d}.bam &
      i=$(($i+1))
      if [ $i -eq $n ]; then
          wait
          i=0
      fi
  done
done
wait

rm -rf config.txt
echo "[info]" >> config.txt
echo "readlen=101" >> config.txt
echo "samdir=${LOCAL_DATA_DIR}" >> config.txt
echo "genome=hg38" >> config.txt
echo "" >> config.txt
echo "[experiments]" >> config.txt


control_bams="control_01"
case_bams="case_01"
for i in {02..25}
do
    control_bams="${control_bams},control_${i}"
    case_bams="${case_bams},case_${i}"
done

echo "CONTROL=${control_bams}" >> config.txt
echo "CASE=${case_bams}" >> config.txt


## convert to gff
# gencode_file='/home-2/gyang22@jhu.edu/scratch/gencode.v22.annotation'
# cp /scratch/groups/lflorea1/Guangyu/SRR493366/simulation2/meta_info2gff3.pl .
# perl2gff3.pl ${gencode_file} > gencode.v22.annotation.gff3
# gffread -E ${gencode_file} -o- > gencode.v22.annotation.gff3

# gff3="/ccb/salz3/gyang/simulation3/gencode.v22.annotation.gff3"
gff3="/ccb/salz3/gyang/simulation3/meta_info/annotation.gff3"

export PATH=${SOFTWARE_DIR}/python-3.6.8/bin:$PATH
export PYTHONPATH=${SOFTWARE_DIR}/python-3.6.8

threads=20
majiq build ${gff3} -c config.txt -j ${threads}  -o build_out

control_majiqs="build_out/control_01.majiq"
case_majiqs="build_out/case_01.majiq"
for i in {02..25}
do
    control_majiqs="${control_majiqs} build_out/control_${i}.majiq"
    case_majiqs="${case_majiqs} build_out/case_${i}.majiq"
done

threads=20
majiq deltapsi -grp1 `echo ${control_majiqs}` \
               -grp2 `echo ${case_majiqs}` \
               -j $threads \
               -o dpsi_out \
               -n control case


voila deltapsi dpsi_out/control_case.deltapsi.voila \
                     --splice-graph build_out/splicegraph.sql \
                     -j $threads \
                     --show-all \
                     -o voila_out
