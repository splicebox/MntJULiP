import random


gene_file = '/ccb/salz3/gyang/simulation3/meta_info/genes_info.txt'

gene_isoforms = []
with open(gene_file, 'r') as f:
    for line in f:
        items = line.strip().split('\t')
        gene_id = items[0]
        bool1, bool2, bool3 = [b == 'True' for b in items[3: 6]]
        if bool1:
            pairs = [v.split(':') for v in items[-2].split(', ')]
            isoforms = [pair[0] for pair in pairs]
            values = [float(pair[1]) for pair in pairs]
            if values[0] > values[1]:
                gene_isoforms.append((gene_id, isoforms[1:]))
            else:
                gene_isoforms.append((gene_id, isoforms[:1] + isoforms[2:]))

dropped_isoforms = set()
for gene, isoforms in gene_isoforms:
    dropped_isoforms.update(isoforms)

out_buffer = ''
gtf_file = '/ccb/salz3/gyang/simulation3/gencode.v22.annotation.gtf'
with open(gtf_file, 'r') as f:
    for line in f:
        if line.startswith('#'):
            out_buffer += line
            continue

        items = line.strip().split('\t')
        if items[2] in {'transcript', 'exon'}:
            tran_id = items[8].split('; ')[1].split(' ')[1][1:-1]
            if tran_id in dropped_isoforms:
                continue

        if items[2] in {'transcript', 'exon', 'gene'}:
            out_buffer += line


new_gtf_file = '/ccb/salz3/gyang/simulation3/meta_info/reduced_gencode.v22.annotation_1000_ds_genes.gtf'
with open(new_gtf_file, 'w') as f:
    f.write(out_buffer)


random.shuffle(gene_isoforms)
gene_isoforms500 = gene_isoforms[:500]
dropped_isoforms500 = set()
for gene, isoforms in gene_isoforms500:
    dropped_isoforms500.update(isoforms)

out_buffer = ''
gtf_file = '/ccb/salz3/gyang/simulation3/gencode.v22.annotation.gtf'
with open(gtf_file, 'r') as f:
    for line in f:
        if line.startswith('#'):
            out_buffer += line
            continue

        items = line.strip().split('\t')
        if items[2] in {'transcript', 'exon'}:
            tran_id = items[8].split('; ')[1].split(' ')[1][1:-1]
            if tran_id in dropped_isoforms500:
                continue

        if items[2] in {'transcript', 'exon', 'gene'}:
            out_buffer += line


new_gtf_file = '/ccb/salz3/gyang/simulation3/meta_info/reduced_gencode.v22.annotation_500_ds_genes.gtf'
with open(new_gtf_file, 'w') as f:
    f.write(out_buffer)


file = '/ccb/salz3/gyang/simulation3/meta_info/reduced_500_genes_isoforms_list.txt'
with open(file, 'w') as f:
    for gene, isoforms in gene_isoforms500:
        f.write(f"{gene}\t{isoforms}\n")
