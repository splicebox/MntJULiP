
## in python
# import sys
# print sys.maxunicode

BASE_DIR="/ccb/salz3/gyang/simulation3"
CNTRL_DIR="${BASE_DIR}/Star/control"
CASE_DIR="${BASE_DIR}/Star/case"
SOFTWARE_DIR="/ccb/salz3/gyang/softwares"
RMATS="/ccb/salz3/gyang/softwares/rMATS.4.0.2/rMATS-turbo-Linux-UCS4/rmats.py"
GTF="${BASE_DIR}/meta_info/annotation"
BINDEX="/ccb/salz3/gyang/IDX_HG38/STAR-2.7.0a/"

# export LD_LIBRARY_PATH=$LD_LIBRARY_PATH:${SOFTWARE_DIR}/gfortran/lib64:${SOFTWARE_DIR}/atlas/lib:${SOFTWARE_DIR}/BLAS-3.8.0

WORK_DIR="${BASE_DIR}/rMATS.4.0.2"
mkdir -p ${WORK_DIR}
cd ${WORK_DIR}

rm -rf ${WORK_DIR}/b1.txt ${WORK_DIR}/b2.txt
control_bams="${CNTRL_DIR}/sample_01/Aligned.sortedByCoord.out.bam"
case_bams="${CASE_DIR}/sample_01/Aligned.sortedByCoord.out.bam"
for i in {02..25}
do
    control_bams="${control_bams},${CNTRL_DIR}/sample_${i}/Aligned.sortedByCoord.out.bam"
    case_bams="${case_bams},${CASE_DIR}/sample_${i}/Aligned.sortedByCoord.out.bam"
done

echo ${control_bams} >> ${WORK_DIR}/b1.txt
echo ${case_bams} >> ${WORK_DIR}/b2.txt

n=20
python ${RMATS} \
        --b1 ${WORK_DIR}/b1.txt \
        --b2 ${WORK_DIR}/b2.txt \
        -  \
        --od out -t paired \
        --nthread ${n} --tstat ${n} \
        --cstat 1 \
        --readLength 101

wait
