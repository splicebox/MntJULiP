BASE_DIR="/scratch/groups/lflorea1/Guangyu/SRR493366/simulation3"
CNTRL_DIR="${BASE_DIR}/Star/control"
CASE_DIR="${BASE_DIR}/Star/case"
SOFTWARE_DIR="/scratch/groups/lflorea1/Guangyu/softwares"
RMATS="/scratch/groups/lflorea1/Guangyu/softwares/rMATS.4.0.2/rMATS-turbo-Linux-UCS4/rmats.py"
GTF="${BASE_DIR}/meta_info/annotation"
BINDEX="/home-2/gyang22@jhu.edu/work/data/IDX_HG38/STAR-2.7.0a/"

module load python/2.7
module load gcc/5.5.0
module load samtools
module load gsl/2.5
module load lapack/3.8.0
module load star
# echo $LIBPATH
# echo $LD_LIBRARY_PATH

export LD_LIBRARY_PATH=$LD_LIBRARY_PATH:${SOFTWARE_DIR}/gfortran/lib64:${SOFTWARE_DIR}/atlas/lib:${SOFTWARE_DIR}/BLAS-3.8.0

WORK_DIR="${BASE_DIR}/rMATS.4.0.2"
mkdir -p ${WORK_DIR}
cd ${WORK_DIR}

rm -rf ${WORK_DIR}/b1.txt ${WORK_DIR}/b2.txt
control_bams="${CNTRL_DIR}/sample_01/Aligned.sortedByCoord.out.bam"
case_bams="${CASE_DIR}/sample_01/Aligned.sortedByCoord.out.bam"
for i in {02..25}
do
    control_bams="${control_bams},${CNTRL_DIR}/sample_${i}/Aligned.sortedByCoord.out.bam"
    case_bams="${case_bams},${CASE_DIR}/sample_${i}/Aligned.sortedByCoord.out.bam"
done

echo ${control_bams} >> ${WORK_DIR}/b1.txt
echo ${case_bams} >> ${WORK_DIR}/b2.txt

n=23
python ${RMATS} \
        --b1 ${WORK_DIR}/b1.txt \
        --b2 ${WORK_DIR}/b2.txt \
        -  \
        --od out -t paired \
        --nthread ${n} --tstat ${n} \
        --cstat 1 \
        --readLength 101

wait
