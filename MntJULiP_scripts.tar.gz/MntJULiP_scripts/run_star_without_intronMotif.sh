BASE_DIR="/scratch/groups/lflorea1/Guangyu/SRR493366/simulation3/"
DATA_DIR="${BASE_DIR}/Polyester/"
WORK_DIR="${BASE_DIR}/Star_without_intronMotif"
STARIDX_DIR="${BASE_DIR}/Star/STAR_IDX"

STAR="/scratch/groups/lflorea1/Guangyu/softwares/STAR-2.6.0a/source/STAR"

# mkdir -p ${STARIDX_DIR}

# $STAR --runMode genomeGenerate \
#       --runThreadN 20 \
#       --genomeDir ${STARIDX_DIR} \
#       --genomeFastaFiles /home-2/gyang22@jhu.edu/work/shared/genomes/hg38/hg38.fa

for t in 'case' 'control'
do
    for i in {01..25}
    do
        mkdir -p ${WORK_DIR}/${t}/sample_${i}/
        $STAR --runThreadN 25 \
              --genomeDir ${STARIDX_DIR} \
              --readFilesIn ${DATA_DIR}/${t}/sample_${i}_1.fasta ${DATA_DIR}/${t}/sample_${i}_2.fasta \
              --outSAMtype BAM SortedByCoordinate \
              --outFileNamePrefix ${WORK_DIR}/${t}/sample_${i}/
    done
done
