
gtf_file = ''
out_data = []
with open(gtf_file, 'r') as f:
    for line in f:
        items = line.strip().split('\t')
        _chr = items[0]
        _type = items[2]
        start = items[3]
        end = items[4]
        strand = items[6]
        if _type == 'exon':
            gene_name = items[8].strip().split('"')[9]
            out_data.append(f"{_chr} {start} {end} {strand} {gene_name}\n")

with open('exons.txt', 'w') as f:
    f.write('chr start end strand gene_name\n')

