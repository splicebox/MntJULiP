# try to run on parallel machines, avoid lrgmem machines

BASE_DIR="/scratch/groups/lflorea1/Guangyu/dataset/methylation-splicing-project"
DATA_DIR="${BASE_DIR}/RNA-seq"
WORK_DIR="${BASE_DIR}/Star"
STARIDX_DIR="/scratch/groups/lflorea1/Guangyu/dataset/genomes/hg38/STAR_IDX_HG38"

module load star

# mkdir -p ${STARIDX_DIR}

# $STAR --runMode genomeGenerate \
#       --runThreadN 20 \
#       --genomeDir ${STARIDX_DIR} \
#       --genomeFastaFiles /home-2/gyang22@jhu.edu/work/shared/genomes/hg38/hg38.fa


name='SRR596102'

mkdir -p ${WORK_DIR}/${name}

STAR --runThreadN 30 \
      --genomeDir ${STARIDX_DIR} \
      --outSAMstrandField intronMotif \
      --readFilesIn ${DATA_DIR}/${name}_1.fastq ${DATA_DIR}/${name}_2.fastq \
      --outSAMtype BAM SortedByCoordinate \
      --outFileNamePrefix ${WORK_DIR}/${name}/
