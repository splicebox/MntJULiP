
# module remove git
module load python/3.6-anaconda
source activate myenv_3_6

# pip3 install —user  cython pysam numpy
# pip3 install —user git+https://bitbucket.org/biociphers/majiq_stable.git#egg=majiq


BASE_DIR="/scratch/groups/lflorea1/Guangyu/SRR493366/simulation3"
DATA_DIR="${BASE_DIR}/Star/"
WORK_DIR="${BASE_DIR}/MAJIQ"
LOCAL_DATA_DIR="${WORK_DIR}/data"

mkdir -p ${LOCAL_DATA_DIR}
cd ${WORK_DIR}

n=25
i=0
for t in case control
do
    for d in {01..${n}}
    do
        ln -s ${DATA_DIR}/${t}/sample_${d}/Aligned.sortedByCoord.out.bam ${LOCAL_DATA_DIR}/${t}_sample_${d}.bam
        samtools index ${LOCAL_DATA_DIR}/${t}_sample_${d}.bam &
        i=$(($i+1))
        if [ $i -eq $n ]; then
            wait
            i=0
        fi
    done
done
wait

rm -rf config.txt
echo "[info]" >> config.txt
echo "readlen=101" >> config.txt
echo "samdir=${LOCAL_DATA_DIR}" >> config.txt
echo "genome=hg38" >> config.txt
echo "" >> config.txt
echo "[experiments]" >> config.txt


t='case'
case_bams="${t}_sample_01"
for i in {02..${n}}
do
    case_bams="${case_bams},${t}_sample_${i}"
done

t='control'
control_bams="${t}_sample_01"
for i in {02..${n}}
do
    control_bams="${control_bams},${t}_sample_${i}"
done

echo "CASE=${case_bams}" >> config.txt
echo "CONTROL=${control_bams}" >> config.txt


## convert to gff
# gencode_file='/home-2/gyang22@jhu.edu/scratch/gencode.v22.annotation'
# cp /scratch/groups/lflorea1/Guangyu/SRR493366/simulation2/meta_info2gff3.pl .
# perl2gff3.pl ${gencode_file} > gencode.v22.annotation.gff3
# gffread -E ${gencode_file} -o- > gencode.v22.annotation.gff3

gff3="/scratch/groups/lflorea1/Guangyu/SRR493366/simulation3/meta_info/annotation.gff3"

threads=23
majiq build ${gff3} -c config.txt -j $threads  -o build_out


t='case'
case_majiqs="build_out/${t}_sample_01.majiq"
for i in {02..${n}}
do
    case_majiqs="${case_majiqs} build_out/${t}_sample_${i}.majiq"
done

t='control'
control_majiqs="build_out/${t}_sample_01.majiq"
for i in {02..${n}}
do
    control_majiqs="${control_majiqs} build_out/${t}_sample_${i}.majiq"
done

threads=23
majiq deltapsi -grp1 `echo ${case_majiqs}` \
               -grp2 `echo ${control_majiqs}` \
               -j $threads \
               -o dpsi_out \
               -n case control


voila deltapsi dpsi_out/case_control.deltapsi.voila \
               --splice-graph build_out/splicegraph.sql \
               -j $threads \
               --show-all \
               -o voila_out
