base_dir='/ccb/salz3/gyang/simulation3'
data_df="${base_dir}/Star"
work_dir='/ccb/salz3/gyang/simulation3/Cuffdiff/BAMs'
out_dir='/ccb/salz3/gyang/simulation3/Cuffdiff/gencode'

cd ${work_dir}

ln -s "${data_df}/control/sample_01/Aligned.sortedByCoord.out.bam" ctrl_01.bam
ln -s "${data_df}/case/sample_01/Aligned.sortedByCoord.out.bam" case_01.bam
ctrl_samples='ctrl_01.bam'
case_samples='case_01.bam'

for i in {02..25}
do
    ln -s "${data_df}/control/sample_${i}/Aligned.sortedByCoord.out.bam" ctrl_${i}.bam
    ln -s "${data_df}/case/sample_${i}/Aligned.sortedByCoord.out.bam" case_${i}.bam
    ctrl_samples="${ctrl_samples},ctrl_${i}.bam"
    case_samples="${case_samples},case_${i}.bam"
done


cuffdiff -o ${out_dir} -p 15 \
        ${base_dir}/gencode.v22.annotation.gtf \
        ${ctrl_samples} \
        ${case_samples}
# https://cole-trapnell-lab.github.io/cufflinks/cuffdiff/

##  with our annotation  #################################################
base_dir='/ccb/salz3/gyang/simulation3'
data_df="${base_dir}/Star"
work_dir='/ccb/salz3/gyang/simulation3/Cuffdiff/BAMs'

out_dir='/ccb/salz3/gyang/simulation3/Cuffdiff/annotation'
cd ${work_dir}

ctrl_samples='ctrl_01.bam'
case_samples='case_01.bam'
for i in {02..25}
do
    ctrl_samples="${ctrl_samples},ctrl_${i}.bam"
    case_samples="${case_samples},case_${i}.bam"
done

cuffdiff -o ${out_dir} -p 15 \
        ${base_dir}/meta_info/annotation.gtf \
        ${ctrl_samples} \
        ${case_samples}


##  with reduced annotation 500 genes #################################################
base_dir='/ccb/salz3/gyang/simulation3'
data_df="${base_dir}/Star"
work_dir='/ccb/salz3/gyang/simulation3/Cuffdiff/BAMs'

out_dir='/ccb/salz3/gyang/simulation3/Cuffdiff/reduced_annotation_500_ds_genes'
cd ${work_dir}

ctrl_samples='ctrl_01.bam'
case_samples='case_01.bam'
for i in {02..25}
do
    ctrl_samples="${ctrl_samples},ctrl_${i}.bam"
    case_samples="${case_samples},case_${i}.bam"
done

cuffdiff -o ${out_dir} -p 30 \
        ${base_dir}/meta_info/reduced_gencode.v22.annotation_500_ds_genes.gtf \
        ${ctrl_samples} \
        ${case_samples}



##  with reduced annotation 1000 genes  #################################################
base_dir='/ccb/salz3/gyang/simulation3'
data_df="${base_dir}/Star"
work_dir='/ccb/salz3/gyang/simulation3/Cuffdiff/BAMs'

out_dir='/ccb/salz3/gyang/simulation3/Cuffdiff/reduced_annotation_1000_ds_genes'
cd ${work_dir}

ctrl_samples='ctrl_01.bam'
case_samples='case_01.bam'
for i in {02..25}
do
    ctrl_samples="${ctrl_samples},ctrl_${i}.bam"
    case_samples="${case_samples},case_${i}.bam"
done

cuffdiff -o ${out_dir} -p 30 \
        ${base_dir}/meta_info/reduced_gencode.v22.annotation_1000_ds_genes.gtf \
        ${ctrl_samples} \
        ${case_samples}


##  12 ctrl samples vs 12 ctrl samples  #################################################
base_dir='/ccb/salz3/gyang/simulation3'
data_df="${base_dir}/Star"
work_dir='/ccb/salz3/gyang/simulation3/Cuffdiff/BAMs'

out_dir='/ccb/salz3/gyang/simulation3/Cuffdiff/gencode_control_12vs12'
cd ${work_dir}

ctrl1_samples='ctrl_01.bam'
for i in {02..12}
do
    ctrl1_samples="${ctrl1_samples},ctrl_${i}.bam"
done

ctrl2_samples='ctrl_13.bam'
for i in {14..24}
do
    ctrl2_samples="${ctrl2_samples},ctrl_${i}.bam"
done


cuffdiff -o ${out_dir} -p 30 \
        ${base_dir}/meta_info/reduced_gencode.v22.annotation_1000_ds_genes.gtf \
        ${ctrl1_samples} \
        ${ctrl2_samples}


##  12 ctrl samples vs 12 ctrl samples  #################################################
base_dir='/ccb/salz3/gyang/simulation3'
data_df="${base_dir}/Star"
work_dir='/ccb/salz3/gyang/simulation3/Cuffdiff/BAMs'

out_dir='/ccb/salz3/gyang/simulation3/Cuffdiff/stmerged_5x5'
cd ${work_dir}

ctrl_samples='ctrl_01.bam,ctrl_02.bam,ctrl_03.bam,ctrl_04.bam,ctrl_05.bam,'
case_samples='case_01.bam,case_02.bam,case_03.bam,case_04.bam,case_05.bam,'

cuffdiff -o ${out_dir} -p 35 \
        /ccb/salz3/florea/Sim/sim.stmerged.gtf \
        ${ctrl_samples} \
        ${case_samples}




##  stmerged  #################################################
base_dir='/ccb/salz3/gyang/simulation3'
data_df="${base_dir}/Star"
work_dir='/ccb/salz3/gyang/simulation3/Cuffdiff/BAMs'

out_dir='/ccb/salz3/gyang/simulation3/Cuffdiff/stmerged_'
cd ${work_dir}

ctrl_samples='ctrl_01.bam'
case_samples='case_01.bam'
for i in {02..25}
do
    ctrl_samples="${ctrl_samples},ctrl_${i}.bam"
    case_samples="${case_samples},case_${i}.bam"
done

cuffdiff -o ${out_dir} -p 35 \
        /ccb/salz3/gyang/simulation3/stringtie/sim.stmerged.modified.gtf \
        ${ctrl_samples} \
        ${case_samples}

