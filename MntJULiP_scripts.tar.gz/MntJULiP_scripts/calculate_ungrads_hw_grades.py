import math
from collections import defaultdict

import pandas as pd
import numpy as np

########################################  read student info from the roster file  ########################################
roster_file = '/Users/gyang/Documents/EN.601.633/rosters/roster.xlsx'

ungrads_df = pd.read_excel(roster_file, sheetname='ungrads')
ungrad_emails = ungrads_df['Email'].tolist()
ungrad_names = ungrads_df['Full Name'].tolist()

emails = set(ungrad_emails)

email_name_dict = {}
df = ungrads_df[['Full Name', 'Email']]
for i, row in df.iterrows():
    email_name_dict[row['Email']] = row['Full Name']

## scores
email_score_dict = defaultdict(list)
email_optional_score_dict = defaultdict(list)

########################################  extract and calculate scores for hw1  ########################################
scores_file = '/Users/gyang/Documents/EN.601.633/hw1/Homework_1_scores.xlsx'
score_df = pd.read_excel(scores_file, sheetname='Assignment Grades')
score_df = score_df[['Email', 'Total Score']]
score_df = score_df.fillna(0)

for i, row in score_df.iterrows():
    if row['Email'] in emails:
        email_score_dict[row['Email']].append(row['Total Score'] / 63. * 100)

########################################  extract and calculate scores for hw2  ########################################
scores_file = '/Users/gyang/Documents/EN.601.633/hw2/Homework_2_scores.xlsx'
score_df = pd.read_excel(scores_file, sheetname='Assignment Grades')
score_df = score_df[['Email', 'Total Score']]
score_df = score_df.fillna(0)

for i, row in score_df.iterrows():
    if row['Email'] in emails:
        email_score_dict[row['Email']].append(row['Total Score'] / 60. * 100)

########################################  extract and calculate scores for hw3  ########################################
scores_file = '/Users/gyang/Documents/EN.601.633/hw3/Homework_3_scores.xlsx'
score_df = pd.read_excel(scores_file, sheetname='Assignment Grades')
score_df = score_df[['Email', 'Total Score', '4: 4 (0.0 pts)']]
score_df = score_df.fillna(0)

for i, row in score_df.iterrows():
    if row['Email'] in emails:
        email_score_dict[row['Email']].append((row['Total Score'] - row['4: 4 (0.0 pts)']) / 60. * 100)
        email_optional_score_dict[row['Email']].append(row['4: 4 (0.0 pts)'])


########################################  extract and calculate scores for hw4  ########################################
scores_file = '/Users/gyang/Documents/EN.601.633/hw4/Homework_4_scores.xlsx'
score_df = pd.read_excel(scores_file, sheetname='Assignment Grades')
score_df = score_df[['Email', 'Total Score']]
score_df = score_df.fillna(0)

for i, row in score_df.iterrows():
    if row['Email'] in emails:
        email_score_dict[row['Email']].append(row['Total Score'] / 100. * 100)


########################################  extract and calculate scores for hw5  ########################################
scores_file = '/Users/gyang/Documents/EN.601.633/hw5/Homework_5_scores.xlsx'
score_df = pd.read_excel(scores_file, sheetname='Assignment Grades')
score_df = score_df[['Email', 'Total Score', '2: 2 (0.0 pts)']]
score_df = score_df.fillna(0)

for i, row in score_df.iterrows():
    if row['Email'] in emails:
        email_score_dict[row['Email']].append((row['Total Score'] - row['2: 2 (0.0 pts)']) / 60. * 100)
        email_optional_score_dict[row['Email']].append(row['2: 2 (0.0 pts)'])

########################################  extract and calculate scores for hw6  ########################################
scores_file = '/Users/gyang/Documents/EN.601.633/hw6/Homework_6_scores.xlsx'
score_df = pd.read_excel(scores_file, sheetname='Assignment Grades')
score_df = score_df[['Email', 'Total Score']]
score_df = score_df.fillna(0)

for i, row in score_df.iterrows():
    if row['Email'] in emails:
        email_score_dict[row['Email']].append(row['Total Score'] / 120. * 100)

########################################  extract and calculate scores for hw7  ########################################
scores_file = '/Users/gyang/Documents/EN.601.633/hw7/Homework_7_scores.xlsx'
score_df = pd.read_excel(scores_file, sheetname='Assignment Grades')
score_df = score_df[['Email', 'Total Score', '3: 3 (0.0 pts)']]
score_df = score_df.fillna(0)

for i, row in score_df.iterrows():
    if row['Email'] in emails:
        email_score_dict[row['Email']].append((row['Total Score'] - row['3: 3 (0.0 pts)']) / 60. * 100)
        email_optional_score_dict[row['Email']].append(row['3: 3 (0.0 pts)'])

########################################  extract and calculate scores for hw8  ########################################
scores_file = '/Users/gyang/Documents/EN.601.633/hw8/Homework_8_scores.xlsx'
score_df = pd.read_excel(scores_file, sheetname='Assignment Grades')
score_df = score_df[['Email', 'Total Score']]
score_df = score_df.fillna(0)

for i, row in score_df.iterrows():
    if row['Email'] in emails:
        email_score_dict[row['Email']].append(row['Total Score'] / 120. * 100)

########################################  extract and calculate scores for hw9  ########################################
scores_file = '/Users/gyang/Documents/EN.601.633/hw9/Homework_9_scores.xlsx'
score_df = pd.read_excel(scores_file, sheetname='Assignment Grades')
score_df = score_df[['Email', 'Total Score']]
score_df = score_df.fillna(0)

for i, row in score_df.iterrows():
    if row['Email'] in emails:
        email_score_dict[row['Email']].append(row['Total Score'] / 120. * 100)


with open('/Users/gyang/Documents/EN.601.633/hw_ungrads_grades.txt', 'w') as f:
    _str = "\t".join([f"HW{i}" for i in range(1, 10)])
    f.write(f"Email\tName\t{_str}\n")
    for email, name in email_name_dict.items():
        scores = email_score_dict[email]
        _str = "\t".join([f"{s:.2f}" for s in scores])
        f.write(f'{name}\t{email}\t{_str}\n')
        # print(f'{name}\t{email}\t{_str}')

