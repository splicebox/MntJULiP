# from scipy import stats
from collections import defaultdict
import pickle
import gzip


file = '/ccb/salz3/gyang/brain_GTEx_13_tissues/intron_samples_dict.pkl'
intron_samples_dict = pickle.load(open(file, 'rb'))

intron_matrix_dict = {}
for intron, result in intron_samples_dict.items():
    intron_matrix_dict[intron] = defaultdict(list)
    for key, counts in result.items():
        for count in counts:
            val = 1 if count >= 1 else 0
            intron_matrix_dict[intron][key].append(val)

###################
file = '/ccb/salz3/gyang/brain_GTEx_13_tissues/samples.groups.tsv'
with open(file, 'r') as f:
    lines = f.readlines()


sample_tissue_dict = {}
for line in lines[1:]:
    tissue, _, _, samples = line.strip().split('\t')
    tissue = tissue.lower()
    for sample in samples.split(','):
        sample_tissue_dict[sample] = tissue

###################
file = '/ccb/salz3/gyang/brain_GTEx_13_tissues/junctions.bgz'
intron_counts_dict = defaultdict(dict)
with gzip.open(file, 'rb') as f:
    for line in f:
        items = line.decode("utf-8").strip().split('\t')
        _chr, start, end, length, strand = items[1: 6]
        start, end = int(start) - 1, int(end) + 1
        intron = (_chr, strand, start, end)
        if intron in intron_matrix_dict:
            pairs = items[11].split(',')[1:]
            for pair in pairs:
                sample, count = pair.split(':')
                tissue = sample_tissue_dict[sample]
                count = int(count)
                presence = 1 if count >= 1 else 0
                if tissue in intron_counts_dict[intron]:
                    intron_counts_dict[intron][tissue] += presence
                else:
                    intron_counts_dict[intron][tissue] = presence


file = '/ccb/salz3/gyang/brain_GTEx_13_tissues/intron_presence_counts_dict.pkl'
pickle.dump(intron_counts_dict, open(file, 'wb'))

# import pandas as pd
# df = pd.DataFrame.from_dict(intron_counts_dict)
