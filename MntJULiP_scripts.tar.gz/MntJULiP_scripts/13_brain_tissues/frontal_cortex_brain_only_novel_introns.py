from collections import defaultdict
import pickle
from scipy import stats


file = '/ccb/salz3/gyang/frontal_cortex_results/intron_presence_counts_dict.pkl'
intron_presence_counts_dict = pickle.load(open(file, 'rb'))
# data_df = pd.DataFrame.from_dict(intron_presence_counts_dict, orient='index')
# data_df = data_df.fillna(0).astype(int)
# data_df.to_csv('/ccb/salz3/gyang/brain_GTEx_13_tissues/intron_presence_counts_matrix.txt', index_label='intron', sep='\t')


tissue_sample_count_dict = {'adipose_tissue': 1293, 'adrenal_gland': 274, 'bladder': 21, 'blood': 1048, 'blood_vessel': 1398, 'bone_marrow': 204, 'brain': 2931, 'breast': 482, 'cervix_uteri': 19, 'colon': 822, 'esophagus': 1577, 'fallopian_tube': 9, 'heart': 942, 'kidney': 98, 'liver': 251, 'lung': 655, 'muscle': 881, 'nerve': 659, 'ovary': 195, 'pancreas': 360, 'pituitary': 301, 'prostate': 263, 'salivary_gland': 178, 'skin': 1940, 'small_intestine': 193, 'spleen': 255, 'stomach': 384, 'testis': 410, 'thyroid': 706, 'uterus': 159, 'vagina': 173}

modified_intron_presence_counts_dict = defaultdict(dict)
for intron in intron_presence_counts_dict:
    for tissue, sample_count in tissue_sample_count_dict.items():
        if tissue in intron_presence_counts_dict[intron]:
            presence_count = intron_presence_counts_dict[intron][tissue]
            if presence_count >= sample_count * 0.15:
                modified_intron_presence_counts_dict[intron][tissue] = presence_count

selected_introns = []
for intron, tissue_dict in modified_intron_presence_counts_dict.items():
    if len(tissue_dict) == 1 and 'brain' in tissue_dict:
        selected_introns.append(intron)

file = '/ccb/salz3/gyang/frontal_cortex_results/selected_novel_introns.txt'
with open(file, 'w') as f:
    for intron in selected_introns:
        f.write(f'{intron}\n')


intron_pvalue_dict = {}
for intron, tissue_dict in intron_presence_counts_dict.items():
    statistic = count = 0
    present_in_brain = False
    for tissue, presence_count in tissue_dict.items():
        if tissue == 'study_na':
            continue

        sample_count = tissue_sample_count_dict[tissue]
        if tissue == 'brain' and presence_count >= sample_count * 0.15:
            present_in_brain = True

        exp = sample_count * 0.85
        obs = sample_count - presence_count
        if obs >= exp: # and (obs - exp) >= v:
            count += 1
            statistic += (obs - exp) ** 2 / exp

    if not present_in_brain or statistic == 0 or count == 0:
        continue
    df = 1 if count == 1 else count - 1
    pvalue = 1 - stats.chi2.cdf(statistic, df)
    if pvalue < 0.001:
        intron_pvalue_dict[intron] = pvalue

file = '/ccb/salz3/gyang/frontal_cortex_results/significant_novel_introns.txt'
with open(file, 'w') as f:
    for intron, pvalue in intron_pvalue_dict.items():
        f.write(f'{intron}\t{pvalue}\n')


# print(len(set(selected_introns) & set(intron_pvalue_dict.keys())))
