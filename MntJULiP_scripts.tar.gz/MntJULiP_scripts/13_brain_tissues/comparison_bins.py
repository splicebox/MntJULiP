from pathlib import Path
from collections import defaultdict
import os
import pickle

import numpy as np
import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt


base_dir = Path('/home-2/gyang22@jhu.edu/work/projects/MntJULiP_brain_GTEx/MntJULiP_clean_splice_out')

type_names = ['Amygdala_Cortex', 'Amygdala_Cerebellum', 'Amygdala_Cerebellar_hemisphere', 'Amygdala_Caudate_basal_ganglia', 'Amygdala_Anterior_cingulate_cortex_BA24', 'Spinal_cord_cervical_c1_Substantia_nigra', 'Putamen_basal_ganglia_Substantia_nigra', 'Putamen_basal_ganglia_Spinal_cord_cervical_c1', 'Nucleus_accumbens_basal_ganglia_Substantia_nigra', 'Nucleus_accumbens_basal_ganglia_Spinal_cord_cervical_c1', 'Nucleus_accumbens_basal_ganglia_Putamen_basal_ganglia', 'Hypothalamus_Substantia_nigra', 'Hypothalamus_Spinal_cord_cervical_c1', 'Hypothalamus_Putamen_basal_ganglia', 'Hypothalamus_Nucleus_accumbens_basal_ganglia', 'Hippocampus_Substantia_nigra', 'Hippocampus_Spinal_cord_cervical_c1', 'Hippocampus_Putamen_basal_ganglia', 'Hippocampus_Nucleus_accumbens_basal_ganglia', 'Hippocampus_Hypothalamus', 'Cortex_Substantia_nigra', 'Cortex_Spinal_cord_cervical_c1', 'Cortex_Putamen_basal_ganglia', 'Cortex_Nucleus_accumbens_basal_ganglia', 'Cortex_Hypothalamus', 'Cortex_Hippocampus', 'Cerebellum_Substantia_nigra', 'Cerebellum_Spinal_cord_cervical_c1', 'Cerebellum_Putamen_basal_ganglia', 'Cerebellum_Hippocampus', 'Cerebellar_hemisphere_Substantia_nigra', 'Cerebellar_hemisphere_Spinal_cord_cervical_c1', 'Cerebellar_hemisphere_Putamen_basal_ganglia', 'Cerebellar_hemisphere_Hypothalamus', 'Cerebellar_hemisphere_Hippocampus', 'Caudate_basal_ganglia_Substantia_nigra', 'Caudate_basal_ganglia_Spinal_cord_cervical_c1', 'Caudate_basal_ganglia_Putamen_basal_ganglia', 'Caudate_basal_ganglia_Nucleus_accumbens_basal_ganglia', 'Caudate_basal_ganglia_Hypothalamus', 'Caudate_basal_ganglia_Hippocampus', 'Caudate_basal_ganglia_Cortex', 'Anterior_cingulate_cortex_BA24_Substantia_nigra', 'Anterior_cingulate_cortex_BA24_Spinal_cord_cervical_c1', 'Anterior_cingulate_cortex_BA24_Putamen_basal_ganglia', 'Anterior_cingulate_cortex_BA24_Nucleus_accumbens_basal_ganglia', 'Anterior_cingulate_cortex_BA24_Hypothalamus', 'Anterior_cingulate_cortex_BA24_Hippocampus', 'Anterior_cingulate_cortex_BA24_Cortex', 'Anterior_cingulate_cortex_BA24_Cerebellar_hemisphere', 'Anterior_cingulate_cortex_BA24_Caudate_basal_ganglia', 'Amygdala_Substantia_nigra', 'Amygdala_Spinal_cord_cervical_c1', 'Amygdala_Putamen_basal_ganglia', 'Amygdala_Nucleus_accumbens_basal_ganglia', 'Amygdala_Hypothalamus', 'Amygdala_Hippocampus', 'Amygdala_Frontal_cortex', 'Anterior_cingulate_cortex_BA24_Frontal_cortex', 'Caudate_basal_ganglia_Frontal_cortex', 'Cortex_Frontal_cortex', 'Frontal_cortex_Hippocampus', 'Frontal_cortex_Hypothalamus', 'Frontal_cortex_Nucleus_accumbens_basal_ganglia', 'Frontal_cortex_Putamen_basal_ganglia', 'Frontal_cortex_Spinal_cord_cervical_c1', 'Frontal_cortex_Substantia_nigra', 'Anterior_cingulate_cortex_BA24_Cerebellum', 'Caudate_basal_ganglia_Cerebellar_hemisphere', 'Cerebellar_hemisphere_Frontal_cortex', 'Cerebellum_Frontal_cortex', 'Cerebellar_hemisphere_Cortex', 'Cerebellar_hemisphere_Nucleus_accumbens_basal_ganglia', 'Cerebellum_Cortex', 'Cerebellum_Hypothalamus', 'Caudate_basal_ganglia_Cerebellum', 'Cerebellar_hemisphere_Cerebellum', 'Cerebellum_Nucleus_accumbens_basal_ganglia']
chr_names = ['chr{}'.format(i) for i in range(1, 23)] + ['chrX', 'chrY']

comparison_intron_dpsis = {}
for type_name in type_names:
    file = f'{base_dir}/{type_name}/diff_spliced_introns.txt'
    with open(file, 'r') as f:
        lines = f.readlines()

    intron_dpsi_dict = {}
    for line in lines[1:]:
        group_id, _chr, start, end, strand, gene_names_str, psi1, psi2, dpsi = line.strip().split('\t')
        intron = (_chr, strand, int(start), int(end))
        if intron not in intron_dpsi_dict:
            intron_dpsi_dict[intron] = abs(float(dpsi))
        else:
            intron_dpsi_dict[intron] = max(intron_dpsi_dict[intron], abs(float(dpsi)))
    comparison_intron_dpsis[type_name] = intron_dpsi_dict

# df = pd.DataFrame.from_dict(comparison_intron_dpsis)
file = base_dir / 'comparison_intron_dpsis.pkl'
pickle.dump(comparison_intron_dpsis, open(file, 'wb'))


comparison_intron_dpsis = pickle.load(open(file, 'rb'))

comparison_bins_dict = {}
for comparison, intron_dpsi_dict in comparison_intron_dpsis.items():
    # [<0.05], [0.05, 0.5], [0.5, 1], [not expressed]
    bins = [0] * 4
    for intron, dpsi in intron_dpsi_dict.items():
        if 0 < dpsi <= 0.05:
            bins[0] += 1
        elif 0.05 < dpsi <= 0.5:
            bins[2] += 1
        else:
            bins[3] += 1
    # 49186 introns intotal
    bins[1] = 49186 - sum(bins)
    comparison_bins_dict[comparison] = bins

data_df = pd.DataFrame.from_dict(comparison_bins_dict).T
data_df.columns = ['[<0.05]', '[not expressed]', '[0.05, 0.5]', '[0.5, 1]']

file = base_dir / 'comparison_bins.txt'
data_df.to_csv(file, sep='\t')
