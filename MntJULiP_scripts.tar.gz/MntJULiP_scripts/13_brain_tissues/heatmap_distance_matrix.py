import pandas as pd
import seaborn as sns
import scipy.spatial as sp
import scipy.cluster.hierarchy as hc
import numpy as np
import matplotlib.pyplot as plt
from pathlib import Path

data_dir = Path('/ccb/salz3/gyang/brain_GTEx/MntJULiP_clean_splice_out')
out_dir = Path('/ccb/salz3/gyang/brain_GTEx/')
for name in ['Matrix.dpsi0.1', 'Matrix.dpsi0.2', 'Matrix.dpsi0.3', 'Matrix.dpsi0.05']:
    sns.set(font="monospace")
    file = data_dir / f'{name}.txt'
    data_df = pd.read_csv(file, sep='\t', index_col=0)
    data_df = data_df.fillna(0)
    linkage = hc.linkage(sp.distance.squareform(data_df), method='average')
    figure = sns.clustermap(data_df, row_linkage=linkage, col_linkage=linkage, cmap=sns.cm.rocket_r)
    figure.savefig(out_dir / f'{name}.png')
    plt.close()
