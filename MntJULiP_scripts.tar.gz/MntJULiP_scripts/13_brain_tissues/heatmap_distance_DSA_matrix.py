import numpy as np
from collections import defaultdict
from pathlib import Path
import pandas as pd

import seaborn as sns
import scipy.spatial as sp
import scipy.cluster.hierarchy as hc
import matplotlib.pyplot as plt


folders = ['Amygdala_Cortex', 'Amygdala_Cerebellum', 'Amygdala_Cerebellar_hemisphere', 'Amygdala_Caudate_basal_ganglia', 'Amygdala_Anterior_cingulate_cortex_BA24', 'Spinal_cord_cervical_c1_Substantia_nigra', 'Putamen_basal_ganglia_Substantia_nigra', 'Putamen_basal_ganglia_Spinal_cord_cervical_c1', 'Nucleus_accumbens_basal_ganglia_Substantia_nigra', 'Nucleus_accumbens_basal_ganglia_Spinal_cord_cervical_c1', 'Nucleus_accumbens_basal_ganglia_Putamen_basal_ganglia', 'Hypothalamus_Substantia_nigra', 'Hypothalamus_Spinal_cord_cervical_c1', 'Hypothalamus_Putamen_basal_ganglia', 'Hypothalamus_Nucleus_accumbens_basal_ganglia', 'Hippocampus_Substantia_nigra', 'Hippocampus_Spinal_cord_cervical_c1', 'Hippocampus_Putamen_basal_ganglia', 'Hippocampus_Nucleus_accumbens_basal_ganglia', 'Hippocampus_Hypothalamus', 'Cortex_Substantia_nigra', 'Cortex_Spinal_cord_cervical_c1', 'Cortex_Putamen_basal_ganglia', 'Cortex_Nucleus_accumbens_basal_ganglia', 'Cortex_Hypothalamus', 'Cortex_Hippocampus', 'Cerebellum_Substantia_nigra', 'Cerebellum_Spinal_cord_cervical_c1', 'Cerebellum_Putamen_basal_ganglia', 'Cerebellum_Hippocampus', 'Cerebellar_hemisphere_Substantia_nigra', 'Cerebellar_hemisphere_Spinal_cord_cervical_c1', 'Cerebellar_hemisphere_Putamen_basal_ganglia', 'Cerebellar_hemisphere_Hypothalamus', 'Cerebellar_hemisphere_Hippocampus', 'Caudate_basal_ganglia_Substantia_nigra', 'Caudate_basal_ganglia_Spinal_cord_cervical_c1', 'Caudate_basal_ganglia_Putamen_basal_ganglia', 'Caudate_basal_ganglia_Nucleus_accumbens_basal_ganglia', 'Caudate_basal_ganglia_Hypothalamus', 'Caudate_basal_ganglia_Hippocampus', 'Caudate_basal_ganglia_Cortex', 'Anterior_cingulate_cortex_BA24_Substantia_nigra', 'Anterior_cingulate_cortex_BA24_Spinal_cord_cervical_c1', 'Anterior_cingulate_cortex_BA24_Putamen_basal_ganglia', 'Anterior_cingulate_cortex_BA24_Nucleus_accumbens_basal_ganglia', 'Anterior_cingulate_cortex_BA24_Hypothalamus', 'Anterior_cingulate_cortex_BA24_Hippocampus', 'Anterior_cingulate_cortex_BA24_Cortex', 'Anterior_cingulate_cortex_BA24_Cerebellar_hemisphere', 'Anterior_cingulate_cortex_BA24_Caudate_basal_ganglia', 'Amygdala_Substantia_nigra', 'Amygdala_Spinal_cord_cervical_c1', 'Amygdala_Putamen_basal_ganglia', 'Amygdala_Nucleus_accumbens_basal_ganglia', 'Amygdala_Hypothalamus', 'Amygdala_Hippocampus', 'Amygdala_Frontal_cortex', 'Anterior_cingulate_cortex_BA24_Frontal_cortex', 'Caudate_basal_ganglia_Frontal_cortex', 'Cortex_Frontal_cortex', 'Frontal_cortex_Hippocampus', 'Frontal_cortex_Hypothalamus', 'Frontal_cortex_Nucleus_accumbens_basal_ganglia', 'Frontal_cortex_Putamen_basal_ganglia', 'Frontal_cortex_Spinal_cord_cervical_c1', 'Frontal_cortex_Substantia_nigra', 'Anterior_cingulate_cortex_BA24_Cerebellum', 'Caudate_basal_ganglia_Cerebellar_hemisphere', 'Cerebellar_hemisphere_Frontal_cortex', 'Cerebellum_Frontal_cortex', 'Cerebellar_hemisphere_Cortex', 'Cerebellar_hemisphere_Nucleus_accumbens_basal_ganglia', 'Cerebellum_Cortex', 'Cerebellum_Hypothalamus', 'Caudate_basal_ganglia_Cerebellum', 'Cerebellar_hemisphere_Cerebellum', 'Cerebellum_Nucleus_accumbens_basal_ganglia']

result = defaultdict(dict)
l2fc_cutoff = 2.0
p_value_cutoff = 0.05


base_dir = Path('/home-2/gyang22@jhu.edu/work/projects/MntJULiP_brain_GTEx/MntJULiP_clean_splice_out')
for folder in folders:
    file = base_dir / folder / 'intron_data.txt'
    with open(file, 'r') as f:
        lines = f.readlines()

    okay_introns = set()
    for line in lines[1:]:
        items = line.strip().split('\t')
        _chr, start, end, strand, gene_name, status = items[:6]
        if status == 'OK':
            okay_introns.add((_chr, strand, start, end))

    file = base_dir / folder / 'diff_introns.txt'
    with open(file, 'r') as f:
        lines = f.readlines()

    genes = set()
    for line in lines[1:]:
        items = line.strip().split('\t')
        _chr, start, end, strand, gene_name, status, _, p_value, q_value, count1, count2 = items
        if (_chr, strand, start, end) in okay_introns:
            p_value, q_value = float(p_value), float(q_value)
            if p_value < p_value_cutoff:
                count1, count2 = float(count1), float(count2)
                if count1 == 0 or count2 == 0:
                    genes.add(gene_name)
                else:
                    l2fc = np.log2(count1 / count2)
                    if abs(l2fc) > l2fc_cutoff:
                        genes.add(gene_name)

    cond1, cond2 = lines[0].strip().split()[-2:]
    cond1, cond2 = cond1[16:-1], cond2[16:-1]
    result[cond1][cond2] = len(genes)
    result[cond2][cond1] = len(genes)

data_df = pd.DataFrame.from_dict(result)
conds = data_df.index.tolist()
data_df = data_df[conds]
data_df.to_csv(base_dir / f'DSA_distance_matrix_l2fc{l2fc_cutoff}.txt', sep='\t')
data_df = data_df.fillna(0)

sns.set(font="monospace")
linkage = hc.linkage(sp.distance.squareform(data_df), method='average')
figure = sns.clustermap(data_df, row_linkage=linkage, col_linkage=linkage, cmap=sns.cm.rocket_r)
figure.savefig(base_dir / f'DSA_distance_matrix_l2fc{l2fc_cutoff}_heatmap.png')
plt.close()
