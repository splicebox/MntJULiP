import argparse, sys
from pathlib import Path
from scipy.stats import chi2_contingency
from collections import defaultdict
import numpy as np


def get_arguments():
    parser = argparse.ArgumentParser(formatter_class=argparse.RawTextHelpFormatter, add_help=False)
    parser.add_argument('--file', type=str, help='Provide the diff_introns.txt')
    parser.add_argument('--out-dir', type=str, default='.', help='Provide the output folder')

    if len(sys.argv) < 2:
        parser.print_help(sys.stderr)
        sys.exit(1)

    return parser.parse_args()


def test_gene(counts):
    x, y = [], []
    for m1, m2 in counts:
        x.append(m1)
        y.append(m2)

    x = np.array(x)
    y = np.array(y)
    obs = np.array([x, y]).T
    statistics, p_value, _, _ = chi2_contingency(obs)
    return p_value


def main():
    args = get_arguments()
    with open(args.file, 'r') as f:
        lines = f.readlines()

    eps = 0.001
    gene_counts_dict = defaultdict(list)
    for line in lines[1:]:
        _chr, start, end, strand, gene_names_str, status, _, p_value, q_value, m1, m2 = line.strip().split('\t')
        if status == 'TEST' and gene_names_str != '.':
            start, end, p_value, q_value = int(start), int(end), float(p_value), float(q_value)
            m1, m2 = float(m1), float(m2)
            for gene_name in gene_names_str.split(','):
                gene_counts_dict[gene_name].append((m1+eps, m2+eps))

    out_dir = Path(args.out_dir)
    file = out_dir / 'genes_chisquare_test.txt'
    with open(file, 'w') as f:
        f.write('gene_name\t#introns\tp-value\n')
        for gene_name, counts in gene_counts_dict.items():
            p_value = test_gene(counts)
            if not np.isnan(p_value):
                f.write(f'{gene_name}\t{len(counts)}\t{p_value:.6g}\n')


if __name__ == "__main__":
    main()
