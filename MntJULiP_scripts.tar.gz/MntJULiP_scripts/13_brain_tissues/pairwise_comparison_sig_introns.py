from pathlib import Path
from collections import defaultdict
import os

import numpy as np
import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt


base_dir = Path('/home-2/gyang22@jhu.edu/work/projects/MntJULiP_brain_GTEx/MntJULiP_clean_splice_out')

type_names = ['Amygdala_Cortex', 'Amygdala_Cerebellum', 'Amygdala_Cerebellar_hemisphere', 'Amygdala_Caudate_basal_ganglia', 'Amygdala_Anterior_cingulate_cortex_BA24', 'Spinal_cord_cervical_c1_Substantia_nigra', 'Putamen_basal_ganglia_Substantia_nigra', 'Putamen_basal_ganglia_Spinal_cord_cervical_c1', 'Nucleus_accumbens_basal_ganglia_Substantia_nigra', 'Nucleus_accumbens_basal_ganglia_Spinal_cord_cervical_c1', 'Nucleus_accumbens_basal_ganglia_Putamen_basal_ganglia', 'Hypothalamus_Substantia_nigra', 'Hypothalamus_Spinal_cord_cervical_c1', 'Hypothalamus_Putamen_basal_ganglia', 'Hypothalamus_Nucleus_accumbens_basal_ganglia', 'Hippocampus_Substantia_nigra', 'Hippocampus_Spinal_cord_cervical_c1', 'Hippocampus_Putamen_basal_ganglia', 'Hippocampus_Nucleus_accumbens_basal_ganglia', 'Hippocampus_Hypothalamus', 'Cortex_Substantia_nigra', 'Cortex_Spinal_cord_cervical_c1', 'Cortex_Putamen_basal_ganglia', 'Cortex_Nucleus_accumbens_basal_ganglia', 'Cortex_Hypothalamus', 'Cortex_Hippocampus', 'Cerebellum_Substantia_nigra', 'Cerebellum_Spinal_cord_cervical_c1', 'Cerebellum_Putamen_basal_ganglia', 'Cerebellum_Hippocampus', 'Cerebellar_hemisphere_Substantia_nigra', 'Cerebellar_hemisphere_Spinal_cord_cervical_c1', 'Cerebellar_hemisphere_Putamen_basal_ganglia', 'Cerebellar_hemisphere_Hypothalamus', 'Cerebellar_hemisphere_Hippocampus', 'Caudate_basal_ganglia_Substantia_nigra', 'Caudate_basal_ganglia_Spinal_cord_cervical_c1', 'Caudate_basal_ganglia_Putamen_basal_ganglia', 'Caudate_basal_ganglia_Nucleus_accumbens_basal_ganglia', 'Caudate_basal_ganglia_Hypothalamus', 'Caudate_basal_ganglia_Hippocampus', 'Caudate_basal_ganglia_Cortex', 'Anterior_cingulate_cortex_BA24_Substantia_nigra', 'Anterior_cingulate_cortex_BA24_Spinal_cord_cervical_c1', 'Anterior_cingulate_cortex_BA24_Putamen_basal_ganglia', 'Anterior_cingulate_cortex_BA24_Nucleus_accumbens_basal_ganglia', 'Anterior_cingulate_cortex_BA24_Hypothalamus', 'Anterior_cingulate_cortex_BA24_Hippocampus', 'Anterior_cingulate_cortex_BA24_Cortex', 'Anterior_cingulate_cortex_BA24_Cerebellar_hemisphere', 'Anterior_cingulate_cortex_BA24_Caudate_basal_ganglia', 'Amygdala_Substantia_nigra', 'Amygdala_Spinal_cord_cervical_c1', 'Amygdala_Putamen_basal_ganglia', 'Amygdala_Nucleus_accumbens_basal_ganglia', 'Amygdala_Hypothalamus', 'Amygdala_Hippocampus', 'Amygdala_Frontal_cortex', 'Anterior_cingulate_cortex_BA24_Frontal_cortex', 'Caudate_basal_ganglia_Frontal_cortex', 'Cortex_Frontal_cortex', 'Frontal_cortex_Hippocampus', 'Frontal_cortex_Hypothalamus', 'Frontal_cortex_Nucleus_accumbens_basal_ganglia', 'Frontal_cortex_Putamen_basal_ganglia', 'Frontal_cortex_Spinal_cord_cervical_c1', 'Frontal_cortex_Substantia_nigra', 'Anterior_cingulate_cortex_BA24_Cerebellum', 'Caudate_basal_ganglia_Cerebellar_hemisphere', 'Cerebellar_hemisphere_Frontal_cortex', 'Cerebellum_Frontal_cortex', 'Cerebellar_hemisphere_Cortex', 'Cerebellar_hemisphere_Nucleus_accumbens_basal_ganglia', 'Cerebellum_Cortex', 'Cerebellum_Hypothalamus', 'Caudate_basal_ganglia_Cerebellum', 'Cerebellar_hemisphere_Cerebellum', 'Cerebellum_Nucleus_accumbens_basal_ganglia']
chr_names = ['chr{}'.format(i) for i in range(1, 23)] + ['chrX', 'chrY']

comparison_sig_introns = {}
for type_name in type_names:
    file = f'{base_dir}/{type_name}/splice_list.txt'
    with open(file, 'r') as f:
        lines = f.readlines()

    sample_names = []
    for line in lines[1:]:
        sample_name = line.strip().split('\t')[0].split('/')[-1].split('.')[1]
        sample_names.append(sample_name)

    file = f'{base_dir}/{type_name}/diff_introns.txt'
    with open(file, 'r') as f:
        lines = f.readlines()

    gene_dict = defaultdict(lambda: (0, 0))
    for line in lines[1:]:
        _chr, start, end, strand, gene_names_str, status, _, p_value, q_value, m1, m2 = line.strip().split('\t')
        if status == 'TEST' and gene_names_str != '.':
            start, end, p_value, q_value = int(start), int(end), float(p_value), float(q_value)
            m1, m2 = float(m1), float(m2)
            for name in gene_names_str.split(','):
                _m1, _m2 = gene_dict[name]
                gene_dict[name] = (_m1 + m1, _m2 + m2)

    sig_introns = set()
    for line in lines[1:]:
        _chr, start, end, strand, gene_names_str, status, _, p_value, q_value, m1, m2 = line.strip().split('\t')
        if status == 'TEST' and gene_names_str != '.':
            start, end, p_value, q_value = int(start), int(end), float(p_value), float(q_value)
            if end - start > 10000:
                continue

            m1, m2 = float(m1), float(m2)
            if m1 < 100 or m2 < 100:
                continue

            r = m1 / m2 if m2 != 0 else float('inf')
            for name in gene_names_str.split(','):
                gm1, gm2 = gene_dict[name]
                gr = gm1 / gm2
                if gr > 1 and r > 1 and r / gr > 2:
                    sig_introns.add(f"{_chr}:{start}-{end}")
                elif gr < 1 and r < 1 and r / gr < 1/2.:
                    sig_introns.add(f"{_chr}:{start}-{end}")
                elif gr > 1 and r < 1/2.:
                    sig_introns.add(f"{_chr}:{start}-{end}")
                elif gr < 1 and r > 2.:
                    sig_introns.add(f"{_chr}:{start}-{end}")

    comparison_sig_introns[type_name] = sig_introns


file = base_dir / 'pairwise_comparison_sig_introns.txt'
with open(file, 'w') as f:
    for type_name, introns in comparison_sig_introns.items():
        f.write(f'{type_name}: {introns}\n')
