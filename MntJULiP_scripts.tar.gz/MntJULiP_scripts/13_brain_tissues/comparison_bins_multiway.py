from pathlib import Path
import numpy as np
from collections import defaultdict
import seaborn
import pandas as pd


data_dir = Path('/ccb/salz3/gyang/brain_GTEx/MntJULiP_clean_splice_out/13_brain_tissues')
group_introns_dict = defaultdict(set)
intron_groups_dict = defaultdict(set)

file = data_dir / 'diff_spliced_introns.txt'
with open(file, 'r') as f:
    lines = f.readlines()

for line in lines[1:]:
    items = line.strip().split('\t')
    group_id, _chr, start, end, strand = items[:5]
    intron = (_chr, strand, int(start), int(end))
    group_introns_dict[group_id].add(intron)
    intron_groups_dict[intron].add(group_id)

file = data_dir / 'intron_data.txt'
with open(file, 'r') as f:
    lines = f.readlines()

intron_counts_dict = defaultdict(list)
for line in lines[1:]:
    items = line.strip().split('\t')
    _chr, start, end, strand = items[:4]
    intron = (_chr, strand, int(start), int(end))
    if intron in intron_groups_dict:
        for counts in items[6:]:
            intron_counts_dict[intron].append(np.mean([int(v) for v in counts.split(',')]))

# all_counts = []
# for counts in intron_counts_dict.values():
#     all_counts += counts

# plot = seaborn.histplot(all_counts, binwidth=1, binrange=(0, 100))
# plt.savefig("/ccb/salz3/gyang/histgram.png")

group_counts_dict = {}
for group_id, introns in group_introns_dict.items():
    for intron in introns:
        counts = intron_counts_dict[intron]
        if group_id not in group_counts_dict:
            group_counts_dict[group_id] = [0] * len(counts)
        for i, count in enumerate(counts):
            if count > 3:
                group_counts_dict[group_id][i] += count


tissues = ['Amygdala', 'Anterior_cingulate_cortex_BA24', 'Caudate_basal_ganglia', 'Cerebellar_hemisphere', 'Cerebellum', 'Cortex', 'Frontal_cortex', 'Hippocampus', 'Hypothalamus', 'Nucleus_accumbens_basal_ganglia', 'Putamen_basal_ganglia', 'Spinal_cord_cervical_c1', 'Substantia_nigra']


file = data_dir / 'diff_spliced_introns.txt'
with open(file, 'r') as f:
    lines = f.readlines()

comparison_bins_dict = {}
for line in lines[1:]:
    items = line.strip().split('\t')
    group_id, _chr, start, end, strand = items[:5]
    intron = (_chr, strand, int(start), int(end))
    PSIs = [float(v) for v in items[6:]]
    n = len(PSIs)
    for i in range(n-1):
        for j in range(i+1, n):
            comparison = f'{tissues[i]}_{tissues[j]}'
            if comparison not in comparison_bins_dict:
                comparison_bins_dict[comparison] = [0] * 4

            if group_counts_dict[group_id][i] == 0 or group_counts_dict[group_id][j] == 0:
                comparison_bins_dict[comparison][1] += 1
                continue

            dpsi = abs(PSIs[i] - PSIs[j])
            if 0 < dpsi <= 0.05:
                comparison_bins_dict[comparison][0] += 1
            elif 0.05 < dpsi <= 0.5:
                comparison_bins_dict[comparison][2] += 1
            else:
                comparison_bins_dict[comparison][3] += 1

data_df = pd.DataFrame.from_dict(comparison_bins_dict).T
data_df.columns = ['[<0.05]', '[not expressed]', '[0.05, 0.5]', '[0.5, 1]']

file = data_dir / 'comparison_bins.txt'
data_df.to_csv(file, sep='\t')
