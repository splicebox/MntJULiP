import pandas as pd
import numpy as np
import argparse, sys
from sklearn import datasets, linear_model
from sklearn.linear_model import LinearRegression
import statsmodels.api as sm
from scipy import stats

from pathlib import Path
from collections import defaultdict


def get_arguments():
    parser = argparse.ArgumentParser(formatter_class=argparse.RawTextHelpFormatter, add_help=False)
    parser.add_argument('--file', type=str, help='Provide the diff_introns.txt')
    parser.add_argument('--out-dir', type=str, default='.', help='Provide the output folder')

    if len(sys.argv) < 2:
        parser.print_help(sys.stderr)
        sys.exit(1)

    return parser.parse_args()


def test_gene(counts):
    x, y = [], []
    for m1, m2 in counts:
        x.append(m1)
        y.append(m2)

    X = np.array(x).reshape(-1, 1)
    y = np.array(y)
    X2 = sm.add_constant(X)
    est = sm.OLS(y, X2)
    est2 = est.fit()
    # print(est2.summary())
    return est2.pvalues


def main():
    args = get_arguments()
    with open(args.file, 'r') as f:
        lines = f.readlines()

    eps = 0.001
    gene_counts_dict = defaultdict(list)
    for line in lines[1:]:
        _chr, start, end, strand, gene_names_str, status, _, p_value, q_value, m1, m2 = line.strip().split('\t')
        if status == 'TEST' and gene_names_str != '.':
            start, end, p_value, q_value = int(start), int(end), float(p_value), float(q_value)
            m1, m2 = float(m1), float(m2)
            for gene_name in gene_names_str.split(','):
                gene_counts_dict[gene_name].append((m1, m2))

    out_dir = Path(args.out_dir)
    file = out_dir / 'genes_linear_regression_test.txt'
    with open(file, 'w') as f:
        f.write('gene_name\t#introns\tp-value(beta0)\tp-value(beta1)\n')
        for gene_name, counts in gene_counts_dict.items():
            if len(counts) == 1:
                continue
            p_value0, p_value1 = test_gene(counts)
            if not(np.isnan(p_value0)) or not(np.isnan(p_value1)):
                f.write(f'{gene_name}\t{len(counts)}\t{p_value0:.6g}\t{p_value1:.6g}\n')


if __name__ == "__main__":
    main()
