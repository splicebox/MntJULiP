import matplotlib.pyplot as plt
from collections import defaultdict
import numpy as np

base_dir = '/ccb/salz3/florea/Hippocampus/'
##################################################. MAJIQ  #########################################################
file = base_dir + 'MAJIQ/dataset_A/voila_out/control_epileptic.deltapsi.tsv'
with open(file, 'r') as f:
    lines = f.readlines()

intron_dpsi_dict = {}
for line in lines[1:]:
    items = line.strip().split('\t')
    _chr, strand = items[15: 17]
    gene_id = items[1]
    gene_name = items[0]
    lsv_id = items[2]
    dpsis = [float(v) for v in items[3].split(';')]
    intron_coords = [v for v in items[17].split(';')]
    for dpsi, intron_coord in zip(dpsis, intron_coords):
        start, end = intron_coord.split('-')
        if abs(dpsi) > 0.05:
            if (_chr, strand, start, end) in intron_dpsi_dict and intron_dpsi_dict[(_chr, strand, start, end)] < abs(dpsi):
                intron_dpsi_dict[(_chr, strand, start, end)] = abs(dpsi)
            else:
                intron_dpsi_dict[(_chr, strand, start, end)] = abs(dpsi)

intron_dpsi_list = []
for key, value in intron_dpsi_dict.items():
    intron_dpsi_list.append((key, value))

intron_dpsi_sorted = sorted(intron_dpsi_list, key=lambda x: x[1], reverse=True)

##
introns_database_A = []
for (intron_coord, dpsi) in intron_dpsi_sorted:
    introns_database_A.append(intron_coord)

########
file = base_dir + 'MAJIQ/dataset_D/voila_out/control_epileptic.deltapsi.tsv'
with open(file, 'r') as f:
    lines = f.readlines()

intron_dpsi_dict = {}
for line in lines[1:]:
    items = line.strip().split('\t')
    _chr, strand = items[15: 17]
    gene_id = items[1]
    gene_name = items[0]
    lsv_id = items[2]
    dpsis = [float(v) for v in items[3].split(';')]
    intron_coords = [v for v in items[17].split(';')]
    for dpsi, intron_coord in zip(dpsis, intron_coords):
        start, end = intron_coord.split('-')
        if abs(dpsi) > 0.05:
            if (_chr, strand, start, end) in intron_dpsi_dict and intron_dpsi_dict[(_chr, strand, start, end)] < abs(dpsi):
                intron_dpsi_dict[(_chr, strand, start, end)] = abs(dpsi)
            else:
                intron_dpsi_dict[(_chr, strand, start, end)] = abs(dpsi)

intron_dpsi_list = []
for key, value in intron_dpsi_dict.items():
    intron_dpsi_list.append((key, value))

intron_dpsi_sorted = sorted(intron_dpsi_list, key=lambda x: x[1], reverse=True)

##
introns_database_D = []
for (intron_coord, dpsi) in intron_dpsi_sorted:
    introns_database_D.append(intron_coord)

majiq_x = []
majiq_y = []
for i in range(2, len(introns_database_A)):
    set_A = set(introns_database_A[:i])
    set_D = set(introns_database_D[:i])
    num = len(set_A.intersection(set_D))
    den = len(set_A)
    majiq_x.append(i)
    majiq_y.append(num / den)


##################################################. Mnt JULiP  #########################################################
file = base_dir + 'Mnt_JULiP/dataset_A/diff_spliced_groups.txt'
with open(file, 'r') as f:
    lines = f.readlines()

group_p_values = {}
for line in lines[1:]:
    group_id, _chr, _, strand, gene_names_str, _, _, p_value, q_value = line.strip().split('\t')
    group_p_values[group_id] = float(p_value)

file = base_dir + 'Mnt_JULiP/dataset_A/diff_spliced_introns.txt'
with open(file, 'r') as f:
    lines = f.readlines()

intron_dpsi_dict = defaultdict(list)
for line in lines[1:]:
    group_id, _chr, start, end, strand, _, _, _, dpsi = line.strip().split('\t')
    start, end, dpsi = int(start), int(end), float(dpsi)
    p_value = group_p_values[group_id]
    if p_value < 0.05 and abs(dpsi) > 0.05:
        intron_dpsi_dict[(_chr, strand, start, end)].append(abs(dpsi))

intron_dpsi_list = []
for key, _list in intron_dpsi_dict.items():
    intron_dpsi_list.append((key, max(_list)))
    # if len(_list) == 1:
    #     intron_dpsi_list.append((key, _list[0]))

intron_dpsi_sorted = sorted(intron_dpsi_list, key=lambda x: x[1], reverse=True)

##
introns_database_A = []
for (intron_coord, dpsi) in intron_dpsi_sorted:
    introns_database_A.append(intron_coord)


################################
file = base_dir + 'Mnt_JULiP/dataset_D/diff_spliced_groups.txt'
with open(file, 'r') as f:
    lines = f.readlines()

group_p_values = {}
for line in lines[1:]:
    group_id, _chr, _, strand, gene_names_str, _, _, p_value, q_value = line.strip().split('\t')
    group_p_values[group_id] = float(p_value)

file = base_dir + f'Mnt_JULiP/dataset_D/diff_spliced_introns.txt'
with open(file, 'r') as f:
    lines = f.readlines()

intron_dpsi_dict = defaultdict(list)
for line in lines[1:]:
    group_id, _chr, start, end, strand, _, _, _, dpsi = line.strip().split('\t')
    start, end, dpsi = int(start), int(end), float(dpsi)
    p_value = group_p_values[group_id]
    if p_value < 0.05 and abs(dpsi) > 0.05:
        intron_dpsi_dict[(_chr, strand, start, end)].append(abs(dpsi))

intron_dpsi_list = []
for key, _list in intron_dpsi_dict.items():
    intron_dpsi_list.append((key, max(_list)))
    # if len(_list) == 1:
    #     intron_dpsi_list.append((key, _list[0]))

intron_dpsi_sorted = sorted(intron_dpsi_list, key=lambda x: x[1], reverse=True)

##
introns_database_D = []
for (intron_coord, dpsi) in intron_dpsi_sorted:
    introns_database_D.append(intron_coord)

#########################
julip_x = []
julip_y = []
for i in range(2, len(introns_database_A)):
    set_A = set(introns_database_A[:i])
    set_D = set(introns_database_D[:i])
    num = len(set_A.intersection(set_D))
    den = len(set_A)
    julip_x.append(i)
    julip_y.append(num / den)


##################################################. LeafCutter  #########################################################
import matplotlib.pyplot as plt

file = base_dir + 'LeafCutter/results_dataset_A/leafcutter_ds_cluster_significance.txt'
with open(file, 'r') as f:
    lines = f.readlines()

cluster_pvalue_dict = {}
cluster_qvalue_dict = {}
for line in lines[1:]:
    cluster, status, _, _, p_value, q_value, gene_name = line.strip().split('\t')
    if status == 'Success':
        _chr, cluster_id = cluster.split(':')
        p_value, q_value = float(p_value), float(q_value)
        cluster_pvalue_dict[cluster_id] = p_value
        cluster_qvalue_dict[cluster_id] = q_value

######### diff genes
file = base_dir + 'LeafCutter/results_dataset_A/leafcutter_ds_effect_sizes.txt'
with open(file, 'r') as f:
    lines = f.readlines()

intron_dpsi_list = []
for line in lines[1:]:
    # intron  logef   case    control deltapsi
    intron_info, _, _, _, dpsi = line.strip().split('\t')
    dpsi = float(dpsi)
    _chr, start, end, cluster_id = intron_info.split(':')
    # p_value = cluster_pvalue_dict[cluster_id]
    p_value = cluster_pvalue_dict[cluster_id]
    if p_value < 0.05 and abs(dpsi) > 0.05:
        intron_dpsi_list.append(((_chr, start, end), abs(dpsi)))

intron_dpsi_sorted = sorted(intron_dpsi_list, key=lambda x: x[1], reverse=True)

##
introns_database_A = []
for (intron_coord, dpsi) in intron_dpsi_sorted:
    introns_database_A.append(intron_coord)

###################
file = base_dir + 'LeafCutter/results_dataset_D/leafcutter_ds_cluster_significance.txt'
with open(file, 'r') as f:
    lines = f.readlines()

cluster_pvalue_dict = {}
cluster_qvalue_dict = {}
for line in lines[1:]:
    cluster, status, _, _, p_value, q_value, gene_name = line.strip().split('\t')
    if status == 'Success':
        _chr, cluster_id = cluster.split(':')
        p_value, q_value = float(p_value), float(q_value)
        cluster_pvalue_dict[cluster_id] = p_value
        cluster_qvalue_dict[cluster_id] = q_value

######### diff genes
file = base_dir + 'LeafCutter/results_dataset_D/leafcutter_ds_effect_sizes.txt'
with open(file, 'r') as f:
    lines = f.readlines()

intron_dpsi_list = []
for line in lines[1:]:
    # intron  logef   case    control deltapsi
    intron_info, _, _, _, dpsi = line.strip().split('\t')
    dpsi = float(dpsi)
    _chr, start, end, cluster_id = intron_info.split(':')
    # p_value = cluster_pvalue_dict[cluster_id]
    p_value = cluster_pvalue_dict[cluster_id]
    if p_value < 0.05 and abs(dpsi) > 0.05:
        intron_dpsi_list.append(((_chr, start, end), abs(dpsi)))

intron_dpsi_sorted = sorted(intron_dpsi_list, key=lambda x: x[1], reverse=True)

##
introns_database_D = []
for (intron_coord, dpsi) in intron_dpsi_sorted:
    introns_database_D.append(intron_coord)


leafcutter_x = []
leafcutter_y = []
for i in range(2, len(introns_database_A)):
    set_A = set(introns_database_A[:i])
    set_D = set(introns_database_D[:i])
    num = len(set_A.intersection(set_D))
    den = len(set_A)
    leafcutter_x.append(i)
    leafcutter_y.append(num / den)


##################################################################################################################
plt.plot(leafcutter_x, leafcutter_y, color='blue', label='LeafCutter')
plt.plot(majiq_x, majiq_y, color='orange', label='MAJIQ')
plt.plot(julip_x, julip_y, color='red', label='Mnt JULiP')
legend = plt.legend(loc='lower right')
legend.legendHandles[0]._sizes = [10]
legend.legendHandles[1]._sizes = [10]
legend.legendHandles[2]._sizes = [10]
plt.ylabel("Percentage")
plt.xlabel("Number of events")
plt.title("Reproducibility Plot")
plt.savefig('lineplot_all.png')
