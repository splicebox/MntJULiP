# scp -r gyang22@jhu.edu@gateway2.marcc.jhu.edu:/scratch/groups/lflorea1/Guangyu/new_julip/


unset PYTHONPATH
SOFTWARE_DIR='/ccb/salz3/gyang/softwares/'
BASE_DIR='/ccb/salz3/florea/Hippocampus/'
DATA_DIR="${BASE_DIR}/Star"

export PATH=/home/dyang/.local/bin:$PATH
export PATH=${SOFTWARE_DIR}/python-3.6.8/bin:$PATH
export PYTHONPATH=${SOFTWARE_DIR}/python-3.6.8

cd ${SOFTWARE_DIR}/MntJULiP

############################################################ all ##############################################################
WORK_DIR="${BASE_DIR}/Mnt_JULiP/all"
mkdir -p ${WORK_DIR}

rm -rf ${WORK_DIR}/hippocampus.bam.txt
echo -e "sample\tcondition" > ${WORK_DIR}/hippocampus.bam.txt
for name in ERR1779355 ERR1779332 ERR1779372 ERR1779317 ERR1779333 ERR1779382 ERR1779363 ERR1779327 ERR1779353 ERR1779300 ERR1779349 ERR1779367 ERR1779344 ERR1779346 ERR1779350 ERR1779334 ERR1779379 ERR1779320 ERR1779309 ERR1779321 ERR1779370 ERR1779351 ERR1779301 ERR1779343
do
    echo -e "${DATA_DIR}/${name}/Aligned.sortedByCoord.out.bam\tcontrol" >> ${WORK_DIR}/hippocampus.bam.txt
done

for name in ERR1779449 ERR1779513 ERR1779451 ERR1779414 ERR1779444 ERR1779452 ERR1779491 ERR1779420 ERR1779435 ERR1779430 ERR1779502 ERR1779500 ERR1779457 ERR1779432 ERR1779487 ERR1779489 ERR1779417 ERR1779443 ERR1779503 ERR1779422
do
    echo -e "${DATA_DIR}/${name}/Aligned.sortedByCoord.out.bam\tepileptic" >> ${WORK_DIR}/hippocampus.bam.txt
done

python3 run.py --out-dir ${WORK_DIR} \
               --bam-list ${WORK_DIR}/hippocampus.bam.txt \
               --num-threads 10 \
               --min-count 5 \
               --batch-size 2000 \
               --anno-file ${BASE_DIR}/gencode.vM17.annotation.gtf


############################################################ run on dataset A ##############################################################
WORK_DIR="${BASE_DIR}/Mnt_JULiP/dataset_A"
mkdir -p ${WORK_DIR}

rm -rf ${WORK_DIR}/hippocampus.bam.txt
echo -e "sample\tcondition" > ${WORK_DIR}/hippocampus.bam.txt

for name in ERR1779355 ERR1779332 ERR1779372 ERR1779317 ERR1779333 ERR1779382 ERR1779363 ERR1779327 ERR1779353 ERR1779300 ERR1779349 ERR1779367
do
    echo -e "${DATA_DIR}/${name}/Aligned.sortedByCoord.out.bam\tcontrol" >> ${WORK_DIR}/hippocampus.bam.txt
done

for name in ERR1779449 ERR1779513 ERR1779451 ERR1779414 ERR1779444 ERR1779452 ERR1779491 ERR1779420 ERR1779435 ERR1779430
do
    echo -e "${DATA_DIR}/${name}/Aligned.sortedByCoord.out.bam\tepileptic" >> ${WORK_DIR}/hippocampus.bam.txt
done


python3 run.py --out-dir ${WORK_DIR} \
               --bam-list ${WORK_DIR}/hippocampus.bam.txt \
               --num-threads 10 \
               --min-count 5 \
               --batch-size 2000 \
               --anno-file ${BASE_DIR}/gencode.vM17.annotation.gtf

############################################################ run on dataset D ##############################################################
WORK_DIR="${BASE_DIR}/Mnt_JULiP/dataset_D"
mkdir -p ${WORK_DIR}

rm -rf ${WORK_DIR}/hippocampus.bam.txt
echo -e "sample\tcondition" > ${WORK_DIR}/hippocampus.bam.txt

for name in ERR1779344 ERR1779346 ERR1779350 ERR1779334 ERR1779379 ERR1779320 ERR1779309 ERR1779321 ERR1779370 ERR1779351 ERR1779301 ERR1779343
do
    echo -e "${DATA_DIR}/${name}/Aligned.sortedByCoord.out.bam\tcontrol" >> ${WORK_DIR}/hippocampus.bam.txt
done

for name in ERR1779502 ERR1779500 ERR1779457 ERR1779432 ERR1779487 ERR1779489 ERR1779417 ERR1779443 ERR1779503 ERR1779422
do
    echo -e "${DATA_DIR}/${name}/Aligned.sortedByCoord.out.bam\tepileptic" >> ${WORK_DIR}/hippocampus.bam.txt
done

python3 run.py --out-dir ${WORK_DIR} \
               --bam-list ${WORK_DIR}/hippocampus.bam.txt \
               --num-threads 15 \
               --min-count 5 \
               --batch-size 2000 \
               --anno-file ${BASE_DIR}/gencode.vM17.annotation.gtf
