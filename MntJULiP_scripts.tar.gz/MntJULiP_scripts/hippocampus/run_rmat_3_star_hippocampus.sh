BASE_DIR="/ccb/salz3/florea/Hippocampus"
DATA_DIR="${BASE_DIR}/Star/"

SOFTWARE_DIR="/ccb/salz3/gyang/softwares"
RMATS="/ccb/salz3/gyang/softwares/rMATS.3.2.5/RNASeq-MATS.py"

GTF="/ccb/salz3/florea/Hippocampus/gencode.vM17.annotation"

WORK_DIR="${BASE_DIR}/rMATS.3.2.5"
mkdir -p ${WORK_DIR}
cd ${WORK_DIR}


control_bams="${DATA_DIR}/ERR1779355/Aligned.sortedByCoord.out.bam"
for d in ERR1779332 ERR1779372 ERR1779317 ERR1779333 ERR1779382 ERR1779363 ERR1779327 ERR1779353 ERR1779300 ERR1779349 ERR1779367 ERR1779344 ERR1779346 ERR1779350 ERR1779334 ERR1779379 ERR1779320 ERR1779309 ERR1779321 ERR1779370 ERR1779351 ERR1779301 ERR1779343
do
    control_bams="${control_bams},${DATA_DIR}/${d}/Aligned.sortedByCoord.out.bam"
done

epileptic_bams="${DATA_DIR}/ERR1779449/Aligned.sortedByCoord.out.bam"
for d in ERR1779513 ERR1779451 ERR1779414 ERR1779444 ERR1779452 ERR1779491 ERR1779420 ERR1779435 ERR1779430 ERR1779502 ERR1779500 ERR1779457 ERR1779432 ERR1779487 ERR1779489 ERR1779417 ERR1779443 ERR1779503 ERR1779422
do
    epileptic_bams="${epileptic_bams},${DATA_DIR}/${d}/Aligned.sortedByCoord.out.bam"
done

python ${RMATS} \
       -b1 ${control_bams} \
       -b2 ${epileptic_bams} \
         -o out -t paired -len 75



######################################################## run on dataset A ########################################################
mkdir -p ${WORK_DIR}/dataset_A
cd ${WORK_DIR}/dataset_A

control_bams="${DATA_DIR}/ERR1779355/Aligned.sortedByCoord.out.bam"
for d in  ERR1779332 ERR1779372 ERR1779317 ERR1779333 ERR1779382 ERR1779363 ERR1779327 ERR1779353 ERR1779300 ERR1779349 ERR1779367
do
    control_bams="${control_bams},${DATA_DIR}/${d}/Aligned.sortedByCoord.out.bam"
done

epileptic_bams="${DATA_DIR}/ERR1779449/Aligned.sortedByCoord.out.bam"
for d in ERR1779513 ERR1779451 ERR1779414 ERR1779444 ERR1779452 ERR1779491 ERR1779420 ERR1779435 ERR1779430
do
    epileptic_bams="${epileptic_bams},${DATA_DIR}/${d}/Aligned.sortedByCoord.out.bam"
done

python ${RMATS} \
       -b1 ${control_bams} \
       -b2 ${epileptic_bams} \
         -o out -t paired -len 75

wait

######################################################## run on dataset D ########################################################
mkdir -p ${WORK_DIR}/dataset_D
cd ${WORK_DIR}/dataset_D

control_bams="${DATA_DIR}/ERR1779344/Aligned.sortedByCoord.out.bam"
for d in ERR1779346 ERR1779350 ERR1779334 ERR1779379 ERR1779320 ERR1779309 ERR1779321 ERR1779370 ERR1779351 ERR1779301 ERR1779343
do
    control_bams="${control_bams},${DATA_DIR}/${d}/Aligned.sortedByCoord.out.bam"
done

epileptic_bams="${DATA_DIR}/ERR1779502/Aligned.sortedByCoord.out.bam"
for d in ERR1779500 ERR1779457 ERR1779432 ERR1779487 ERR1779489 ERR1779417 ERR1779443 ERR1779503 ERR1779422
do
    epileptic_bams="${epileptic_bams},${DATA_DIR}/${d}/Aligned.sortedByCoord.out.bam"
done

python ${RMATS} \
       -b1 ${control_bams} \
       -b2 ${epileptic_bams} \
         -o out -t paired -len 75

wait
