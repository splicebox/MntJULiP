BASE_DIR="/ccb/salz3/florea/Hippocampus"
DATA_DIR="${BASE_DIR}/Star/"
WORK_DIR="${BASE_DIR}/MAJIQ"
LOCAL_DATA_DIR="${WORK_DIR}/data"
SOFTWARE_DIR="/ccb/salz3/gyang/softwares"

unset PYTHONPATH
export PATH=/home/dyang/.local/bin:$PATH
export PATH=${SOFTWARE_DIR}/python-3.6.8/bin:$PATH
export PYTHONPATH=${SOFTWARE_DIR}/python-3.6.8


mkdir -p ${LOCAL_DATA_DIR}
cd ${WORK_DIR}

##############
n=20
i=0
for d in ERR1779367 ERR1779300 ERR1779327 ERR1779417 ERR1779443 ERR1779346 ERR1779363 ERR1779487 ERR1779414 ERR1779513 ERR1779435 ERR1779309 ERR1779457 ERR1779333 ERR1779503 ERR1779350 ERR1779301 ERR1779370 ERR1779420 ERR1779332 ERR1779444 ERR1779349 ERR1779489 ERR1779379 ERR1779430 ERR1779317 ERR1779451 ERR1779334 ERR1779500 ERR1779321 ERR1779344 ERR1779351 ERR1779355 ERR1779372 ERR1779382 ERR1779422 ERR1779432 ERR1779449 ERR1779452 ERR1779491 ERR1779502 ERR1779320 ERR1779343 ERR1779353
do
    ln -s ${DATA_DIR}/${d}/Aligned.sortedByCoord.out.bam ${LOCAL_DATA_DIR}/${d}.bam
    samtools index ${LOCAL_DATA_DIR}/${d}.bam &
    i=$(($i+1))
    if [ $i -eq $n ]; then
        wait
        i=0
    fi
done
wait


############
gff3="/ccb/salz3/florea/Hippocampus/gencode.vM17.annotation.gff3"


######################################################## run on all ########################################################
mkdir -p ${WORK_DIR}/results
cd ${WORK_DIR}/results

rm -rf config.txt
echo "[info]" >> config.txt
echo "readlen=75" >> config.txt
echo "samdir=${LOCAL_DATA_DIR}" >> config.txt
echo "genome=mm10" >> config.txt
echo "" >> config.txt
echo "[experiments]" >> config.txt

#############
control_bams="ERR1779355"
for d in  ERR1779332 ERR1779372 ERR1779317 ERR1779333 ERR1779382 ERR1779363 ERR1779327 ERR1779353 ERR1779300 ERR1779349 ERR1779367 ERR1779344 ERR1779346 ERR1779350 ERR1779334 ERR1779379 ERR1779320 ERR1779309 ERR1779321 ERR1779370 ERR1779351 ERR1779301 ERR1779343
do
    control_bams="${control_bams},${d}"
done

epileptic_bams="ERR1779449"
for d in ERR1779513 ERR1779451 ERR1779414 ERR1779444 ERR1779452 ERR1779491 ERR1779420 ERR1779435 ERR1779430 ERR1779502 ERR1779500 ERR1779457 ERR1779432 ERR1779487 ERR1779489 ERR1779417 ERR1779443 ERR1779503 ERR1779422
do
    epileptic_bams="${epileptic_bams},${d}"
done

echo "CONTROL=${control_bams}" >> config.txt
echo "EPILEPTIC=${epileptic_bams}" >> config.txt


############
threads=20
majiq build ${gff3} -c config.txt -j $threads  -o build_out


############
control_majiqs="build_out/ERR1779355.majiq"
for d in  ERR1779332 ERR1779372 ERR1779317 ERR1779333 ERR1779382 ERR1779363 ERR1779327 ERR1779353 ERR1779300 ERR1779349 ERR1779367 ERR1779344 ERR1779346 ERR1779350 ERR1779334 ERR1779379 ERR1779320 ERR1779309 ERR1779321 ERR1779370 ERR1779351 ERR1779301 ERR1779343
do
    control_majiqs="${control_majiqs} build_out/${d}.majiq"
done

epileptic_majiqs="build_out/ERR1779449.majiq"
for d in ERR1779513 ERR1779451 ERR1779414 ERR1779444 ERR1779452 ERR1779491 ERR1779420 ERR1779435 ERR1779430 ERR1779502 ERR1779500 ERR1779457 ERR1779432 ERR1779487 ERR1779489 ERR1779417 ERR1779443 ERR1779503 ERR1779422
do
    epileptic_majiqs="${epileptic_majiqs} build_out/${d}.majiq"
done


threads=20
majiq deltapsi -grp1 `echo ${control_majiqs}` \
               -grp2 `echo ${epileptic_majiqs}` \
               -j $threads \
               -o dpsi_out \
               -n control epileptic


voila deltapsi dpsi_out/control_epileptic.deltapsi.voila \
               --splice-graph build_out/splicegraph.sql \
               -j $threads \
               --show-all \
               -o voila_out



######################################################## run on dataset A ########################################################
mkdir -p ${WORK_DIR}/dataset_A
cd ${WORK_DIR}/dataset_A

rm -rf config.txt
echo "[info]" >> config.txt
echo "readlen=75" >> config.txt
echo "samdir=${LOCAL_DATA_DIR}" >> config.txt
echo "genome=mm10" >> config.txt
echo "" >> config.txt
echo "[experiments]" >> config.txt

#############
control_bams="ERR1779355"
for d in  ERR1779332 ERR1779372 ERR1779317 ERR1779333 ERR1779382 ERR1779363 ERR1779327 ERR1779353 ERR1779300 ERR1779349 ERR1779367
do
    control_bams="${control_bams},${d}"
done

epileptic_bams="ERR1779449"
for d in ERR1779513 ERR1779451 ERR1779414 ERR1779444 ERR1779452 ERR1779491 ERR1779420 ERR1779435 ERR1779430
do
    epileptic_bams="${epileptic_bams},${d}"
done

echo "CONTROL=${control_bams}" >> config.txt
echo "EPILEPTIC=${epileptic_bams}" >> config.txt


############
threads=20
majiq build ${gff3} -c config.txt -j $threads  -o build_out


############
control_majiqs="build_out/ERR1779355.majiq"
for d in  ERR1779332 ERR1779372 ERR1779317 ERR1779333 ERR1779382 ERR1779363 ERR1779327 ERR1779353 ERR1779300 ERR1779349 ERR1779367
do
    control_majiqs="${control_majiqs} build_out/${d}.majiq"
done

epileptic_majiqs="build_out/ERR1779449.majiq"
for d in ERR1779513 ERR1779451 ERR1779414 ERR1779444 ERR1779452 ERR1779491 ERR1779420 ERR1779435 ERR1779430
do
    epileptic_majiqs="${epileptic_majiqs} build_out/${d}.majiq"
done


threads=20
majiq deltapsi -grp1 `echo ${control_majiqs}` \
               -grp2 `echo ${epileptic_majiqs}` \
               -j $threads \
               -o dpsi_out \
               -n control epileptic


voila deltapsi dpsi_out/control_epileptic.deltapsi.voila \
               --splice-graph build_out/splicegraph.sql \
               -j $threads \
               --show-all \
               -o voila_out


######################################################## run on dataset D ########################################################
mkdir -p ${WORK_DIR}/dataset_D
cd ${WORK_DIR}/dataset_D

rm -rf config.txt
echo "[info]" >> config.txt
echo "readlen=75" >> config.txt
echo "samdir=${LOCAL_DATA_DIR}" >> config.txt
echo "genome=mm10" >> config.txt
echo "" >> config.txt
echo "[experiments]" >> config.txt

#############
control_bams="ERR1779344"
for d in ERR1779346 ERR1779350 ERR1779334 ERR1779379 ERR1779320 ERR1779309 ERR1779321 ERR1779370 ERR1779351 ERR1779301 ERR1779343
do
    control_bams="${control_bams},${d}"
done

epileptic_bams="ERR1779502"
for d in ERR1779500 ERR1779457 ERR1779432 ERR1779487 ERR1779489 ERR1779417 ERR1779443 ERR1779503 ERR1779422
do
    epileptic_bams="${epileptic_bams},${d}"
done


echo "CONTROL=${control_bams}" >> config.txt
echo "EPILEPTIC=${epileptic_bams}" >> config.txt


############
threads=20
majiq build ${gff3} -c config.txt -j $threads  -o build_out


############
control_majiqs="build_out/ERR1779344.majiq"
for d in ERR1779346 ERR1779350 ERR1779334 ERR1779379 ERR1779320 ERR1779309 ERR1779321 ERR1779370 ERR1779351 ERR1779301 ERR1779343
do
    control_majiqs="${control_majiqs} build_out/${d}.majiq"
done

epileptic_majiqs="build_out/ERR1779502.majiq"
for d in ERR1779500 ERR1779457 ERR1779432 ERR1779487 ERR1779489 ERR1779417 ERR1779443 ERR1779503 ERR1779422
do
    epileptic_majiqs="${epileptic_majiqs} build_out/${d}.majiq"
done


threads=20
majiq deltapsi -grp1 `echo ${control_majiqs}` \
               -grp2 `echo ${epileptic_majiqs}` \
               -j $threads \
               -o dpsi_out \
               -n control epileptic


voila deltapsi dpsi_out/control_epileptic.deltapsi.voila \
               --splice-graph build_out/splicegraph.sql \
               -j $threads \
               --show-all \
               -o voila_out
