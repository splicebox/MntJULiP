import matplotlib.pyplot as plt

base_dir = '/ccb/salz3/florea/Hippocampus/'
file = base_dir + 'LeafCutter/results_dataset_A/leafcutter_ds_cluster_significance.txt'
with open(file, 'r') as f:
    lines = f.readlines()

cluster_pvalue_dict = {}
cluster_qvalue_dict = {}
for line in lines[1:]:
    cluster, status, _, _, p_value, q_value, gene_name = line.strip().split('\t')
    if status == 'Success':
        _chr, cluster_id = cluster.split(':')
        p_value, q_value = float(p_value), float(q_value)
        cluster_pvalue_dict[cluster_id] = p_value
        cluster_qvalue_dict[cluster_id] = q_value

######### diff genes
file = base_dir + 'LeafCutter/results_dataset_A/leafcutter_ds_effect_sizes.txt'
with open(file, 'r') as f:
    lines = f.readlines()

intron_dpsi_list = []
for line in lines[1:]:
    # intron  logef   case    control deltapsi
    intron_info, _, _, _, dpsi = line.strip().split('\t')
    dpsi = float(dpsi)
    _chr, start, end, cluster_id = intron_info.split(':')
    # p_value = cluster_pvalue_dict[cluster_id]
    p_value = cluster_pvalue_dict[cluster_id]
    if p_value < 0.05 and abs(dpsi) > 0.05:
        intron_dpsi_list.append(((_chr, start, end), abs(dpsi)))

intron_dpsi_sorted = sorted(intron_dpsi_list, key=lambda x: x[1], reverse=True)

##
introns_database_A = []
for (intron_coord, dpsi) in intron_dpsi_sorted:
    introns_database_A.append(intron_coord)



###################
file = base_dir + 'LeafCutter/results_dataset_D/leafcutter_ds_cluster_significance.txt'
with open(file, 'r') as f:
    lines = f.readlines()

cluster_pvalue_dict = {}
cluster_qvalue_dict = {}
for line in lines[1:]:
    cluster, status, _, _, p_value, q_value, gene_name = line.strip().split('\t')
    if status == 'Success':
        _chr, cluster_id = cluster.split(':')
        p_value, q_value = float(p_value), float(q_value)
        cluster_pvalue_dict[cluster_id] = p_value
        cluster_qvalue_dict[cluster_id] = q_value

######### diff genes
file = base_dir + 'LeafCutter/results_dataset_D/leafcutter_ds_effect_sizes.txt'
with open(file, 'r') as f:
    lines = f.readlines()

intron_dpsi_list = []
for line in lines[1:]:
    # intron  logef   case    control deltapsi
    intron_info, _, _, _, dpsi = line.strip().split('\t')
    dpsi = float(dpsi)
    _chr, start, end, cluster_id = intron_info.split(':')
    # p_value = cluster_pvalue_dict[cluster_id]
    p_value = cluster_pvalue_dict[cluster_id]
    if p_value < 0.05 and abs(dpsi) > 0.05:
        intron_dpsi_list.append(((_chr, start, end), abs(dpsi)))

intron_dpsi_sorted = sorted(intron_dpsi_list, key=lambda x: x[1], reverse=True)

##
introns_database_D = []
for (intron_coord, dpsi) in intron_dpsi_sorted:
    introns_database_D.append(intron_coord)


x = []
y = []
for i in range(2, len(introns_database_A)):
    set_A = set(introns_database_A[:i])
    set_D = set(introns_database_D[:i])
    num = len(set_A.intersection(set_D))
    den = len(set_A)
    x.append(i)
    y.append(num / den)

plt.plot(x, y)
plt.savefig('lineplot_leafcutter.png')
