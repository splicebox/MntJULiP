#!/bin/bash -l

## In R install prerequired packages
# dotR <- file.path(Sys.getenv("HOME"), ".R")
# if (!file.exists(dotR)) dir.create(dotR)
# M <- file.path(dotR, "Makevars")
# if (!file.exists(M)) file.create(M)
# cat("\nCXXFLAGS=-O3 -mtune=native -march=native -Wno-unused-variable -Wno-unused-function  -Wno-macro-redefined",
#     file = M, sep = "\n", append = TRUE)
# cat("\nCXXFLAGS+=-flto -Wno-unused-local-typedefs",
#     file = M, sep = "\n", append = TRUE)
# cat("\nCXXFLAGS += -Wno-ignored-attributes -Wno-deprecated-declarations",
#     file = M, sep = "\n", append = TRUE)
# install.packages(c("Rcpp", "foreach", "ggplot2", "R.utils", "gridExtra", "reshape2", "Hmisc",
#                    "dplyr", "doMC", "optparse", "shiny", "intervals", "shinycssloaders", "DT", "gtables"))
# install.packages("rstan", repos = "https://cloud.r-project.org/", dependencies=TRUE)

###########################################

## build package
# cd /scratch/groups/lflorea1/Guangyu/softwares/leafcutter/leafcutter
# $R CMD INSTALL --build .

BASE_DIR="/ccb/salz3/florea/Hippocampus"
DATA_DIR="${BASE_DIR}/Star/"
WORK_DIR="${BASE_DIR}/LeafCutter"
LOCAL_DATA_DIR="${WORK_DIR}/data"

mkdir -p ${LOCAL_DATA_DIR}
cd ${WORK_DIR}

rm -rf test_juncfiles.txt test_diff_introns.txt

SOFTWARE_BASE_DIR="/ccb/salz3/gyang/softwares/leafcutter"
bam2junc="${SOFTWARE_BASE_DIR}/scripts/bam2junc.sh"
leafcutter_cluster="${SOFTWARE_BASE_DIR}/clustering/leafcutter_cluster.py"
leafcutter_ds="${SOFTWARE_BASE_DIR}/scripts/leafcutter_ds.R"

PATH=$PATH:${SOFTWARE_BASE_DIR}/scripts

n=20
i=0
for d in ERR1779367 ERR1779300 ERR1779327 ERR1779417 ERR1779443 ERR1779346 ERR1779363 ERR1779487 ERR1779414 ERR1779513 ERR1779435 ERR1779309 ERR1779457 ERR1779333 ERR1779503 ERR1779350 ERR1779301 ERR1779370 ERR1779420 ERR1779332 ERR1779444 ERR1779349 ERR1779489 ERR1779379 ERR1779430 ERR1779317 ERR1779451 ERR1779334 ERR1779500 ERR1779321 ERR1779344 ERR1779351 ERR1779355 ERR1779372 ERR1779382 ERR1779422 ERR1779432 ERR1779449 ERR1779452 ERR1779491 ERR1779502 ERR1779320 ERR1779343 ERR1779353
do
    ln -s ${DATA_DIR}/${d}/Aligned.sortedByCoord.out.bam ${LOCAL_DATA_DIR}/${d}.bam
    sh ${bam2junc} ${LOCAL_DATA_DIR}/${d}.bam ${LOCAL_DATA_DIR}/${d}.bam.junc &
    echo ${LOCAL_DATA_DIR}/${d}.bam.junc >> test_juncfiles.txt
    i=$(($i+1))
    if [ $i -eq $n ]; then
        wait
        i=0
    fi
done
wait


######## run all
cd ${WORK_DIR}

for d in ERR1779355 ERR1779332 ERR1779372 ERR1779317 ERR1779333 ERR1779382 ERR1779363 ERR1779327 ERR1779353 ERR1779300 ERR1779349 ERR1779367 ERR1779449 ERR1779513 ERR1779451 ERR1779414 ERR1779444 ERR1779452 ERR1779491 ERR1779420 ERR1779435 ERR1779430 ERR1779344 ERR1779346 ERR1779350 ERR1779334 ERR1779379 ERR1779320 ERR1779309 ERR1779321 ERR1779370 ERR1779351 ERR1779301 ERR1779343 ERR1779502 ERR1779500 ERR1779457 ERR1779432 ERR1779487 ERR1779489 ERR1779417 ERR1779443 ERR1779503 ERR1779422
do
    echo ${LOCAL_DATA_DIR}/${d}.bam.junc >> test_juncfiles.txt
done

mkdir results
cd results

python ${leafcutter_cluster} -j ../test_juncfiles.txt -o results


### generate exon file
Rscript ${SOFTWARE_BASE_DIR}/scripts_to_exons.R ${BASE_DIR}/gencode.vM17.annotation.gz ${WORK_DIR}/exons.txt.gz


###
t='control'
for d in ERR1779355 ERR1779332 ERR1779372 ERR1779317 ERR1779333 ERR1779382 ERR1779363 ERR1779327 ERR1779353 ERR1779300 ERR1779349 ERR1779367 ERR1779344 ERR1779346 ERR1779350 ERR1779334 ERR1779379 ERR1779320 ERR1779309 ERR1779321 ERR1779370 ERR1779351 ERR1779301 ERR1779343
do
    echo "${d}.bam ${t}" >> test_diff_introns.txt
done


t='epileptic'
for d in ERR1779449 ERR1779513 ERR1779451 ERR1779414 ERR1779444 ERR1779452 ERR1779491 ERR1779420 ERR1779435 ERR1779430 ERR1779502 ERR1779500 ERR1779457 ERR1779432 ERR1779487 ERR1779489 ERR1779417 ERR1779443 ERR1779503 ERR1779422
do
    echo "${d}.bam ${t}" >> test_diff_introns.txt
done

threads=24
${leafcutter_ds} -p ${threads} -e "${WORK_DIR}/exons.txt.gz" \
                 results_perind_numers.counts.gz \
                 test_diff_introns.txt


######## run on dataset A
cd ${WORK_DIR}

for d in ERR1779355 ERR1779332 ERR1779372 ERR1779317 ERR1779333 ERR1779382 ERR1779363 ERR1779327 ERR1779353 ERR1779300 ERR1779349 ERR1779367 ERR1779449 ERR1779513 ERR1779451 ERR1779414 ERR1779444 ERR1779452 ERR1779491 ERR1779420 ERR1779435 ERR1779430
do
    echo ${LOCAL_DATA_DIR}/${d}.bam.junc >> test_juncfiles_dataset_A.txt
done

mkdir results_dataset_A
cd results_dataset_A

python ${leafcutter_cluster} -j ../test_juncfiles_dataset_A.txt -o results

t='control'
for d in ERR1779355 ERR1779332 ERR1779372 ERR1779317 ERR1779333 ERR1779382 ERR1779363 ERR1779327 ERR1779353 ERR1779300 ERR1779349 ERR1779367
do
    echo "${d}.bam ${t}" >> test_diff_introns.txt
done


t='epileptic'
for d in ERR1779449 ERR1779513 ERR1779451 ERR1779414 ERR1779444 ERR1779452 ERR1779491 ERR1779420 ERR1779435 ERR1779430
do
    echo "${d}.bam ${t}" >> test_diff_introns.txt
done

threads=20
${leafcutter_ds} -p ${threads} -e "${WORK_DIR}/exons.txt.gz"\
                 results_perind_numers.counts.gz \
                 test_diff_introns.txt

######## run on dataset D
cd ${WORK_DIR}

for d in ERR1779344 ERR1779346 ERR1779350 ERR1779334 ERR1779379 ERR1779320 ERR1779309 ERR1779321 ERR1779370 ERR1779351 ERR1779301 ERR1779343 ERR1779502 ERR1779500 ERR1779457 ERR1779432 ERR1779487 ERR1779489 ERR1779417 ERR1779443 ERR1779503 ERR1779422
do
    echo ${LOCAL_DATA_DIR}/${d}.bam.junc >> test_juncfiles_dataset_D.txt
done

mkdir results_dataset_D
cd results_dataset_D

python ${leafcutter_cluster} -j ../test_juncfiles_dataset_D.txt -o results

t='control'
for d in ERR1779344 ERR1779346 ERR1779350 ERR1779334 ERR1779379 ERR1779320 ERR1779309 ERR1779321 ERR1779370 ERR1779351 ERR1779301 ERR1779343
do
    echo "${d}.bam ${t}" >> test_diff_introns.txt
done

t='epileptic'
for d in ERR1779502 ERR1779500 ERR1779457 ERR1779432 ERR1779487 ERR1779489 ERR1779417 ERR1779443 ERR1779503 ERR1779422
do
    echo "${d}.bam ${t}" >> test_diff_introns.txt
done

threads=20
${leafcutter_ds} -p ${threads} -e "${WORK_DIR}/exons.txt.gz"\
                 results_perind_numers.counts.gz \
                 test_diff_introns.txt

