from pathlib import Path
from collections import defaultdict
import os

import numpy as np
import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt


base_dir = Path('/ccb/salz3/florea/Hippocampus/Mnt_JULiP/all')


file = f'{base_dir}/hippocampus.bam.txt'
with open(file, 'r') as f:
    lines = f.readlines()

sample_names = []
for line in lines[1:]:
    sample_name = line.strip().split('\t')[0].split('/')[-1].split('.')[0]
    sample_names.append(sample_name)

file = f'{base_dir}/diff_introns.txt'
with open(file, 'r') as f:
    lines = f.readlines()

gene_dict = defaultdict(lambda: (0, 0))
for line in lines[1:]:
    _chr, start, end, strand, gene_names_str, status, _, p_value, q_value, m1, m2 = line.strip().split('\t')[:11]
    if status == 'TEST' and gene_names_str != '.':
        start, end, p_value, q_value = int(start), int(end), float(p_value), float(q_value)
        m1, m2 = float(m1), float(m2)
        for name in gene_names_str.split(','):
            _m1, _m2 = gene_dict[name]
            gene_dict[name] = (_m1 + m1, _m2 + m2)

min_count = 20
outputs = 'gene_name\tintron\tavg_intron_counts_cond1\tavg_intron_counts_cond2\tavg_gene_counts_cond1\tavg_gene_counts_cond2\n'
for line in lines[1:]:
    _chr, start, end, strand, gene_names_str, status, _, p_value, q_value, m1, m2 = line.strip().split('\t')[:11]
    if status == 'TEST' and gene_names_str != '.':
        start, end, p_value, q_value = int(start), int(end), float(p_value), float(q_value)
        if end - start > 10000:
            continue

        m1, m2 = float(m1), float(m2)
        if m1 < min_count or m2 < min_count:
            continue

        r = m1 / m2 if m2 != 0 else float('inf')
        for name in gene_names_str.split(','):
            gm1, gm2 = gene_dict[name]
            gr = gm1 / gm2
            if gr > 1 and r > 1 and r / gr > 2:
                sig_introns.add(f"{_chr}:{start}-{end}")
                outputs += f'{name}\t{_chr}:{start}-{end}\t{m1:.2f}\t{m2:.2f}\t{gm1:.2f}\t{gm2:.2f}\n'
            elif gr < 1 and r < 1 and r / gr < 1/2.:
                outputs += f'{name}\t{_chr}:{start}-{end}\t{m1:.2f}\t{m2:.2f}\t{gm1:.2f}\t{gm2:.2f}\n'
            elif gr > 1 and r < 1/2.:
                outputs += f'{name}\t{_chr}:{start}-{end}\t{m1:.2f}\t{m2:.2f}\t{gm1:.2f}\t{gm2:.2f}\n'
            elif gr < 1 and r > 2.:
                outputs += f'{name}\t{_chr}:{start}-{end}\t{m1:.2f}\t{m2:.2f}\t{gm1:.2f}\t{gm2:.2f}\n'

with open('/ccb/salz3/florea/Hippocampus/Mnt_JULiP/all/sig_fold_change_introns.txt', 'w') as f:
    f.write(outputs)

# discover diff spliced introns from MntJULiP results
# (1) if the direction change of intron expressions are the same as gene expression, the change must be larger
# (2) if the direction change of intron expressions are opposited to gene expression, changes should > 2 fold
# (3) the p-value < 0.05
# (4) intron expression > 100
