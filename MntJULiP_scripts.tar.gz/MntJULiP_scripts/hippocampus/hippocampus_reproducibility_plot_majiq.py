import matplotlib.pyplot as plt

base_dir = '/ccb/salz3/florea/Hippocampus/'

file = base_dir + 'MAJIQ/dataset_A/voila_out/control_epileptic.deltapsi.tsv'
with open(file, 'r') as f:
    lines = f.readlines()

intron_dpsi_dict = {}
for line in lines[1:]:
    items = line.strip().split('\t')
    _chr, strand = items[15: 17]
    gene_id = items[1]
    gene_name = items[0]
    lsv_id = items[2]
    dpsis = [float(v) for v in items[3].split(';')]
    intron_coords = [v for v in items[17].split(';')]
    for dpsi, intron_coord in zip(dpsis, intron_coords):
        start, end = intron_coord.split('-')
        if abs(dpsi) > 0.05:
            if (_chr, strand, start, end) in intron_dpsi_dict and intron_dpsi_dict[(_chr, strand, start, end)] < abs(dpsi):
                intron_dpsi_dict[(_chr, strand, start, end)] = abs(dpsi)
            else:
                intron_dpsi_dict[(_chr, strand, start, end)] = abs(dpsi)

intron_dpsi_list = []
for key, value in intron_dpsi_dict.items():
    intron_dpsi_list.append((key, value))

intron_dpsi_sorted = sorted(intron_dpsi_list, key=lambda x: x[1], reverse=True)

##
introns_database_A = []
for (intron_coord, dpsi) in intron_dpsi_sorted:
    introns_database_A.append(intron_coord)

########
file = base_dir + 'MAJIQ/dataset_D/voila_out/control_epileptic.deltapsi.tsv'
with open(file, 'r') as f:
    lines = f.readlines()

intron_dpsi_dict = {}
for line in lines[1:]:
    items = line.strip().split('\t')
    _chr, strand = items[15: 17]
    gene_id = items[1]
    gene_name = items[0]
    lsv_id = items[2]
    dpsis = [float(v) for v in items[3].split(';')]
    intron_coords = [v for v in items[17].split(';')]
    for dpsi, intron_coord in zip(dpsis, intron_coords):
        start, end = intron_coord.split('-')
        if abs(dpsi) > 0.05:
            if (_chr, strand, start, end) in intron_dpsi_dict and intron_dpsi_dict[(_chr, strand, start, end)] < abs(dpsi):
                intron_dpsi_dict[(_chr, strand, start, end)] = abs(dpsi)
            else:
                intron_dpsi_dict[(_chr, strand, start, end)] = abs(dpsi)

intron_dpsi_list = []
for key, value in intron_dpsi_dict.items():
    intron_dpsi_list.append((key, value))

intron_dpsi_sorted = sorted(intron_dpsi_list, key=lambda x: x[1], reverse=True)

##
introns_database_D = []
for (intron_coord, dpsi) in intron_dpsi_sorted:
    introns_database_D.append(intron_coord)

x = []
y = []
for i in range(2, len(introns_database_A)):
    set_A = set(introns_database_A[:i])
    set_D = set(introns_database_D[:i])
    num = len(set_A.intersection(set_D))
    den = len(set_A)
    x.append(i)
    y.append(num / den)

plt.plot(x, y)
plt.savefig('lineplot_majiq.png')
