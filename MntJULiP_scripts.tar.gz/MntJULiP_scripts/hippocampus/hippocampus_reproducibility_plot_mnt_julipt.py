import matplotlib.pyplot as plt
from collections import defaultdict
import numpy as np

base_dir = '/ccb/salz3/florea/Hippocampus/'
file = base_dir + 'Mnt_JULiP/dataset_A/diff_spliced_groups.txt'
with open(file, 'r') as f:
    lines = f.readlines()

group_p_values = {}
for line in lines[1:]:
    group_id, _chr, _, strand, gene_names_str, _, _, p_value, q_value = line.strip().split('\t')
    group_p_values[group_id] = float(p_value)

file = base_dir + 'Mnt_JULiP/dataset_A/diff_spliced_introns.txt'
with open(file, 'r') as f:
    lines = f.readlines()

intron_dpsi_dict = defaultdict(list)
for line in lines[1:]:
    group_id, _chr, start, end, strand, _, _, _, dpsi = line.strip().split('\t')
    start, end, dpsi = int(start), int(end), float(dpsi)
    p_value = group_p_values[group_id]
    if p_value < 0.05 and abs(dpsi) > 0.05:
        intron_dpsi_dict[(_chr, strand, start, end)].append(dpsi)

intron_dpsi_list = []
for key, _list in intron_dpsi_dict.items():
    intron_dpsi_list.append((key, np.mean(_list)))
    # if len(_list) == 1:
    #     intron_dpsi_list.append((key, _list[0]))

intron_dpsi_sorted = sorted(intron_dpsi_list, key=lambda x: x[1], reverse=True)

##
introns_database_A = []
for (intron_coord, dpsi) in intron_dpsi_sorted:
    introns_database_A.append(intron_coord)


################################################################################
file = base_dir + 'Mnt_JULiP/dataset_D/diff_spliced_groups.txt'
with open(file, 'r') as f:
    lines = f.readlines()

group_p_values = {}
for line in lines[1:]:
    group_id, _chr, _, strand, gene_names_str, _, _, p_value, q_value = line.strip().split('\t')
    group_p_values[group_id] = float(p_value)

file = base_dir + 'Mnt_JULiP/dataset_D/diff_spliced_introns.txt'
with open(file, 'r') as f:
    lines = f.readlines()

intron_dpsi_dict = defaultdict(list)
for line in lines[1:]:
    group_id, _chr, start, end, strand, _, _, _, dpsi = line.strip().split('\t')
    start, end, dpsi = int(start), int(end), float(dpsi)
    p_value = group_p_values[group_id]
    if p_value < 0.05 and abs(dpsi) > 0.05:
        intron_dpsi_dict[(_chr, strand, start, end)].append(dpsi)

intron_dpsi_list = []
for key, _list in intron_dpsi_dict.items():
    intron_dpsi_list.append((key, np.mean(_list)))
    # if len(_list) == 1:
    #     intron_dpsi_list.append((key, _list[0]))

intron_dpsi_sorted = sorted(intron_dpsi_list, key=lambda x: x[1], reverse=True)

##
introns_database_D = []
for (intron_coord, dpsi) in intron_dpsi_sorted:
    introns_database_D.append(intron_coord)

################################################################################
x = []
y = []
for i in range(2, len(introns_database_A)):
    set_A = set(introns_database_A[:i])
    set_D = set(introns_database_D[:i])
    num = len(set_A.intersection(set_D))
    den = len(set_A)
    x.append(i)
    y.append(num / den)

plt.plot(x, y)
plt.savefig('lineplot_mntjulip.png')
