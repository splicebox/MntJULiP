from pathlib import Path
from collections import defaultdict

import numpy as np


def get_introns(exons):
    if len(exons) <= 1:
        return []
    else:
        introns = []
        _list = sorted(exons)
        start = _list[0][1]
        for i in range(1, len(_list)):
            end = _list[i][0]
            introns.append((start, end))
            start = _list[i][1]
        return introns


# read exon info from the file.
tran_exons_dict = defaultdict(list)
# gtf_file = '/Users/gyang/test/annotation.gtf'
gtf_file = '/Users/gyang/test/gencode.v22.annotation.gtf'

tran_exons_dict = defaultdict(list)
tran_gene_dict = {}
gene_name_id_dict = defaultdict(list)
with open(gtf_file, 'r') as f:
    for line in f:
        if line is not '\n' and not(line.startswith('#')):
            items = line.strip().split('\t')
            if items[2] == 'exon':
                _chr, strand = items[0], items[6]
                start, end = items[3: 5]
                _items = items[8].split('"')
                tran_id, gene_id = _items[3], _items[1]
                gene_id, gene_name = _items[1], _items[9]
                tran_exons_dict[(_chr, strand, tran_id)].append((int(start), int(end)))
                tran_gene_dict[tran_id] = gene_id
                gene_name_id_dict[gene_name].append(gene_id)


intron_genes_dict = defaultdict(set)
for (_chr, strand, tran_id), exons in tran_exons_dict.items():
    introns = get_introns(exons)
    gene_id = tran_gene_dict[tran_id]
    for intron_coord in introns:
        intron_genes_dict[(_chr, strand, *intron_coord)].add(gene_id)

###########################################################
gene_file = '/Users/gyang/test/genes_info.txt'
diff_spliced_genes = {}

with open(gene_file, 'r') as f:
    for line in f:
        items = line.strip().split('\t')
        gene_id = items[0]
        bool1, bool2, bool3 = [b == 'True' for b in items[3: 6]]
        if bool1 and not(bool2) and not(bool3):  # DS
            diff_spliced_genes[gene_id] = 1

        if bool1 and (bool2 or bool3):  # DE & DS
            diff_spliced_genes[gene_id] = 1


########################################################### without filter #########################
folder = '0.0'
file = f'/Users/gyang/test/simulation_3_out/{folder}/diff_spliced_groups.txt'
with open(file, 'r') as f:
    lines = f.readlines()

group_pvalue_dict = {}
group_gene_dict = {}
for line in lines[1:]:
    group_id, _chr, _, strand, gene_name, _, p_value, q_value = line.strip().split('\t')
    group_pvalue_dict[group_id] = float(p_value)
    group_gene_dict[group_id] = gene_name

file = f'/Users/gyang/test/simulation_3_out/{folder}/diff_spliced_introns.txt'
with open(file, 'r') as f:
    lines = f.readlines()

gene_dict = {}
for line in lines[1:]:
    group_id, _chr, start, end, strand, gene_names_str, _, _, dpsi = line.strip().split('\t')
    start, end, dpsi = int(start), int(end), float(dpsi)
    p_value = group_pvalue_dict[group_id]
    if p_value < 0.1 and abs(dpsi) > 0.05 and gene_names_str != '.':
        gene_names = gene_names_str.split(',')
        for gene_name in gene_names:
            if gene_name in gene_dict and gene_dict[gene_name] == 1:
                continue

            gene_dict[gene_name] = 0
            for gene_id in gene_name_id_dict[gene_name]:
                if gene_id in diff_spliced_genes:
                    gene_dict[gene_name] = 1

tp_genes = set()
fp_genes = set()
for gene_name, v in gene_dict.items():
    if v == 1:
        tp_genes.add(gene_name)
    else:
        fp_genes.add(gene_name)

print(len(tp_genes), len(fp_genes))

########################################################### with filter #########################

file = f'/Users/gyang/test/simulation_3_out/{folder}/diff_spliced_groups.txt'
with open(file, 'r') as f:
    lines = f.readlines()

group_pvalue_dict = {}
group_gene_dict = {}
for line in lines[1:]:
    group_id, _chr, _, strand, gene_name, _, p_value, q_value = line.strip().split('\t')
    group_pvalue_dict[group_id] = float(p_value)
    group_gene_dict[group_id] = gene_name


file = f'/Users/gyang/test/simulation_3_out/{folder}/diff_introns.txt'
with open(file, 'r') as f:
    # chrom, start, end, strand, gene_name, status, llr, p_value, q_value, avg_read_counts_cond1, avg_read_counts_cond2
    lines = f.readlines()

gene_max_expr_dict = defaultdict(lambda: (0, 0))
intron_exprs_dict = {}
for line in lines[1:]:
    items = line.strip().split('\t')
    _chr, start, end, strand, gene_name, status = items[: 6]
    if status == 'TEST':
        start, end = int(start), int(end)
        p_value, q_value, v1, v2 = [float(v) for v in items[-4:]]
        intron_exprs_dict[(_chr, strand, start, end)] = (v1, v2)
        if (_chr, strand, start, end) in intron_genes_dict:
            for gene_id in intron_genes_dict[(_chr, strand, start, end)]:
                mv1, mv2 = gene_max_expr_dict[gene_id]
                if v1 > mv1:
                    mv1 = v1
                if v2 > mv2:
                    mv2 = v2
                gene_max_expr_dict[gene_id] = (mv1, mv2)

file = f'/Users/gyang/test/simulation_3_out/{folder}/diff_spliced_introns.txt'
with open(file, 'r') as f:
    lines = f.readlines()

threshold = 0.1
gene_dict = {}
for line in lines[1:]:
    group_id, _chr, start, end, strand, gene_names_str, _, _, dpsi = line.strip().split('\t')
    start, end, dpsi = int(start), int(end), float(dpsi)
    p_value = group_pvalue_dict[group_id]
    v1, v2 = intron_exprs_dict[(_chr, strand, start, end)]
    if p_value < 0.1 and abs(dpsi) > 0.05 and gene_names_str != '.':
        gene_names = gene_names_str.split(',')
        for gene_name in gene_names:
            if gene_name in gene_dict and gene_dict[gene_name] == 1:
                continue

            for gene_id in gene_name_id_dict[gene_name]:
                mv1, mv2 = gene_max_expr_dict[gene_id]
                if (v1 > mv1 * threshold or v2 > mv2 * threshold):
                    gene_dict[gene_name] = 0 if gene_name not in gene_dict else gene_dict[gene_name]
                    if gene_id in diff_spliced_genes:
                        gene_dict[gene_name] = 1

tp_genes = set()
fp_genes = set()
for gene_name, v in gene_dict.items():
    if v == 1:
        tp_genes.add(gene_name)
    else:
        fp_genes.add(gene_name)

print(len(tp_genes), len(fp_genes))

