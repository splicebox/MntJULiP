# base_dir = "/ccb/salz3/gyang/DRA005238/MntJULiP_20_min_count"
base_dir = "/ccb/salz3/gyang/DRA005238/MntJULiP"
folder = "all"
file = f'{base_dir}/{folder}/diff_spliced_groups.txt'
with open(file, 'r') as f:
    lines = f.readlines()

group_pvalue_dict = {}
for line in lines[1:]:
    group_id, _chr, _, strand, gene_name_str, _, _, p_value, q_value = line.strip().split('\t')
    group_pvalue_dict[group_id] = float(p_value)

file = f'{base_dir}/{folder}/diff_spliced_introns.txt'
with open(file, 'r') as f:
    lines = f.readlines()

all_genes = set()
count = 0
for line in lines[1:]:
    items = line.strip().split('\t')
    group_id, _chr, start, end, strand, gene_name_str = items[:6]
    start, end = int(start), int(end)
    psis = [float(v) for v in items[6:]]
    max_dpsi = max(abs(psis[i] - psis[j]) for i in range(len(psis)-1) for j in range(i+1, len(psis)))
    if group_pvalue_dict[group_id] < 0.05 and max_dpsi > 0.05:
        for gene_name in gene_name_str.split(','):
            all_genes.add(gene_name)
            count += 1


# qualified_introns = set()
# for folder in ["2D_4D", "2D_6D", "2D_8D", "2D_10D", "2D_12D", "2D_14D", "4D_6D", "4D_8D", "4D_10D", "4D_12D", "4D_14D", "6D_8D", "6D_10D", "6D_12D", "6D_14D", "8D_10D", "8D_12D", "8D_14D", "10D_12D", "10D_14D", "12D_14D"]:
#     file = f'{base_dir}/{folder}/diff_introns.txt'
#     with open(file, 'r') as f:
#         lines = f.readlines()

#     for line in lines[1:]:
#         _chr, start, end, strand, gene_names_str, status, _, p_value, q_value, count1, count2 = line.strip().split('\t')
#         if status == 'TEST':
#             start, end, p_value = int(start), int(end), float(p_value)
#             count1, count2 = float(count1), float(count2)
#             if count1 > 20 or count2 > 20:
#                 qualified_introns.add((_chr, strand, start, end))


union_genes = set()
introns = set()
for folder in ["2D_4D", "2D_6D", "2D_8D", "2D_10D", "2D_12D", "2D_14D", "4D_6D", "4D_8D", "4D_10D", "4D_12D", "4D_14D", "6D_8D", "6D_10D", "6D_12D", "6D_14D", "8D_10D", "8D_12D", "8D_14D", "10D_12D", "10D_14D", "12D_14D"]:
    file = f'{base_dir}/{folder}/diff_spliced_groups.txt'
    with open(file, 'r') as f:
        lines = f.readlines()

    group_pvalue_dict = {}
    for line in lines[1:]:
        group_id, _chr, _, strand, gene_name_str, _, _, p_value, q_value = line.strip().split('\t')
        group_pvalue_dict[group_id] = float(p_value)

    file = f'{base_dir}/{folder}/diff_spliced_introns.txt'
    with open(file, 'r') as f:
        lines = f.readlines()

    for line in lines[1:]:
        items = line.strip().split('\t')
        group_id, _chr, start, end, strand, gene_name_str = items[:6]
        start, end, dpsi = int(start), int(end), float(items[-1])
        # if group_pvalue_dict[group_id] < 0.05 and abs(dpsi) > 0.05 and (_chr, strand, start, end) in qualified_introns:
        if group_pvalue_dict[group_id] < 0.05 and abs(dpsi) > 0.05 and (_chr, strand, start, end):
            for gene_name in gene_name_str.split(','):
                union_genes.add(gene_name)
                introns.add((_chr, strand, start, end))
