from collections import defaultdict
from collections import OrderedDict
import numpy as np
import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt

folder = '/ccb/salz3/gyang/DRA005238/MntJULiP/all/'
file = folder + 'diff_introns.txt'
with open(file, 'r') as f:
    lines = f.readlines()

num_conds = len(lines[0].split('\t')) - 9
gene_dict = defaultdict(lambda: np.zeros(num_conds))  #############
for line in lines[1:]:
    items = line.strip().split('\t')
    _chr, start, end, strand, gene_names_str, status, _, p_value, q_value = items[:9]
    if status == 'TEST' and gene_names_str != '.':
        start, end, p_value, q_value = int(start), int(end), float(p_value), float(q_value)
        means = np.array([float(m) for m in items[9:]])
        for name in gene_names_str.split(','):
            gene_dict[name] += means

gene_set = set(name for name, means in gene_dict.items() if np.any(gene_dict[name] > 30))

##########
file = folder + 'intron_data.txt'
with open(file, 'r') as f:
    lines = f.readlines()

sample_counts_dict = defaultdict(lambda: 0)
intron_counts_dict = {}
for line in lines[1:]:
    items = line.strip().split('\t')
    _chr, start, end, strand, gene_names_str, status = items[:6]
    if status == "OK":
        counts = []
        i = 0
        for cond_counts in items[6:]:
            for count in cond_counts.split(','):
                count = int(count)
                counts.append(count)
                sample_counts_dict[i] += count
                i += 1
        intron_counts_dict[(_chr, strand, int(start), int(end))] = counts

sample_counts_mean = np.mean(list(sample_counts_dict.values()))
_intron_normalized_counts_dict = {}
save_items = items

for intron, counts in intron_counts_dict.items():
    normalized_counts = []
    for i, count in enumerate(counts):
        normalized_counts.append(count * sample_counts_dict[i] / sample_counts_mean)
    _intron_normalized_counts_dict[intron] = np.log2(np.array(normalized_counts)+ 0.01)

##########
def max_diff(nums):
    res = 0
    for i in range(len(nums)-1):
        for j in range(i+1, len(nums)):
            res = max(res, abs(nums[i]-nums[j]))
    return res


file = folder + 'diff_introns.txt'
with open(file, 'r') as f:
    lines = f.readlines()

gene_value_dict = {}
for line in lines[1:]:
    items = line.strip().split('\t')
    _chr, start, end, strand, gene_names_str, status, _, p_value, q_value = items[:9]
    if status == 'TEST' and gene_names_str != '.':
        start, end, p_value, q_value = int(start), int(end), float(p_value), float(q_value)
        intron = (_chr, strand, int(start), int(end))
        if q_value < 0.05:
            value = max_diff([np.log2(float(v) + 0.01) for v in items[9:]])
            for gene_name in gene_names_str.split(','):
                if gene_name not in gene_set:
                    continue
                if gene_name not in gene_value_dict:
                    gene_value_dict[gene_name] = (intron, value)
                else:
                    old_intron, old_value = gene_value_dict[gene_name]
                    if old_value < value:
                        gene_value_dict[gene_name] = (intron, value)

intron_value_list = []
for gene_name, (intron, value) in gene_value_dict.items():
    intron_value_list.append((intron, value))

intron_value_list.sort(reverse=True, key=lambda x: x[1])

intron_normalized_counts_dict = OrderedDict()
for i in range(1000):
    intron, value = intron_value_list[i]
    if intron in _intron_normalized_counts_dict:
        intron_normalized_counts_dict[intron] = _intron_normalized_counts_dict[intron]

##########
file = folder + 'intron_data.txt'
with open(file, 'r') as f:
    lines = f.readlines()

columns = []
for _str, cond_counts in zip(lines[0].strip().split('\t')[6:], save_items[6:]):
    name = _str[12:-1]
    columns += [name] * len(cond_counts.split(','))

intron_counts_df = pd.DataFrame.from_dict(intron_normalized_counts_dict, orient='index', columns=columns)
intron_counts_df = pd.concat([intron_counts_df.iloc[:, 6:], intron_counts_df.iloc[:, :6]], axis=1)

cmap = 'RdYlGn_r'
ax = sns.heatmap(intron_counts_df, linewidth=0, yticklabels=False,
                 cmap=cmap, vmin=-8, vmax=12)

file = f'/ccb/salz3/gyang/DRA005238/MntJULiP/mntjulip_heatmap_DSA_multiway.png'
figure = ax.get_figure()
figure.savefig(file)

plt.close()


method = 'average'
metric = 'cityblock'

file = f'/ccb/salz3/gyang/DRA005238/MntJULiP/mntjulip_clustermap_DSA_multiway.png'
figure = sns.clustermap(intron_counts_df, cmap=cmap,
                        metric=metric, method=method,
                        yticklabels=False)
figure.ax_heatmap.set_facecolor("lightgray")
figure.savefig(file)
plt.close()


file = f'/ccb/salz3/gyang/DRA005238/MntJULiP/mntjulip_clustermap_DSA_multiway_row_cluster.png'
figure = sns.clustermap(intron_counts_df, cmap=cmap, col_cluster=False,
                        metric=metric, method=method,
                        yticklabels=False)
figure.ax_heatmap.set_facecolor("lightgray")
figure.savefig(file)
plt.close()
