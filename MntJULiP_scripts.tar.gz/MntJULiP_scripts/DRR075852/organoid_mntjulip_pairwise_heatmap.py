from collections import defaultdict
import gzip
import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt


base_dir = "/ccb/salz3/gyang/DRA005238/MntJULiP"
# base_dir = "/ccb/salz3/gyang/DRA005238/MntJULiP_group_filter"
sig_introns = set()
sig_genes = set()
cutoff = 0.2 ###################
# for folder in ["2D_4D", "4D_6D", "6D_8D", "8D_10D", "10D_12D", "12D_14D"]:
for folder in ["2D_4D", "2D_6D", "2D_8D", "2D_10D", "2D_12D", "2D_14D", "4D_6D", "4D_8D", "4D_10D", "4D_12D", "4D_14D", "6D_8D", "6D_10D", "6D_12D", "6D_14D", "8D_10D", "8D_12D", "8D_14D", "10D_12D", "10D_14D", "12D_14D"]:
    file = f'{base_dir}/{folder}/diff_spliced_groups.txt'
    with open(file, 'r') as f:
        lines = f.readlines()

    sig_groups = set()
    for line in lines[1:]:
        group_id, _chr, _, strand, gene_name_str, _, _, p_value, q_value = line.strip().split('\t')
        if float(p_value) < 0.05:
            sig_groups.add(group_id)

    file = f'{base_dir}/{folder}/diff_spliced_introns.txt'
    with open(file, 'r') as f:
        lines = f.readlines()

    for line in lines[1:]:
        items = line.strip().split('\t')
        group_id, _chr, start, end, strand, gene_name_str = items[:6]
        start, end, dpsi = int(start), int(end), float(items[-1])
        if group_id in sig_groups and abs(dpsi) > cutoff:
            sig_introns.add((_chr, strand, start, end))
            sig_genes.update(gene_name_str.split(','))

print(f"pairwise :{len(sig_introns)} introns, {len(sig_genes)} genes")

def func(c, _sum):
    return None if _sum == 0 else c / _sum


def custom_max(v1, v2):
    if not(v1) or not(v2):
        return v1 or v2
    return max(v1, v2)


type_dict = {'2D': 'DRR075852,DRR075859', '4D': 'DRR075853,DRR075860', '6D': 'DRR075854,DRR075861', '8D': 'DRR075862,DRR075855', '10D': 'DRR075856,DRR075863', '12D': 'DRR075864,DRR075857', '14D': 'DRR075865,DRR075858'}

sample_intron_dict = defaultdict(list)
# for folder in ["2D_4D", "4D_6D", "6D_8D", "8D_10D", "10D_12D", "12D_14D"]:
for folder in ["2D_4D", "2D_6D", "2D_8D", "2D_10D", "2D_12D", "2D_14D", "4D_6D", "4D_8D", "4D_10D", "4D_12D", "4D_14D", "6D_8D", "6D_10D", "6D_12D", "6D_14D", "8D_10D", "8D_12D", "8D_14D", "10D_12D", "10D_14D", "12D_14D"]:
    file = f'{base_dir}/{folder}/diff_spliced_introns.txt'
    with open(file, 'r') as f:
        lines = f.readlines()

    group_introns_dict = defaultdict(dict)
    intron_groups_dict = defaultdict(list)
    selected_introns = set()
    for line in lines[1:]:
        items = line.strip().split('\t')
        group_id, _chr, start, end, strand, gene_name_str = items[:6]
        start, end, dpsi = int(start), int(end), float(items[-1])
        group_introns_dict[group_id][(_chr, strand, start, end)] = []
        intron_groups_dict[(_chr, strand, start, end)].append(group_id)

    file = f'{base_dir}/{folder}/intron_data.txt'
    with open(file, 'r') as f:
        lines = f.readlines()

    d1, d2 = folder.split('_')
    s1, s2 = type_dict[d1].split(',')
    s3, s4 = type_dict[d2].split(',')
    for line in lines[1:]:
        _chr, start, end, strand, gene_name_str, status, str1, str2 = line.strip().split('\t')
        start, end = int(start), int(end)
        if (_chr, strand, start, end) in intron_groups_dict:
            c1, c2 = (float(c) for c in str1.split(','))
            c3, c4 = (float(c) for c in str2.split(','))
            for group_id in intron_groups_dict[(_chr, strand, start, end)]:
                group_introns_dict[group_id][(_chr, strand, start, end)] = (c1, c2, c3, c4)

    intron_sample_dict = defaultdict(list)
    for group_id, _dict in group_introns_dict.items():
        sum1 = sum2 = sum3 = sum4 = 0
        for intron, (c1, c2, c3, c4) in _dict.items():
            sum1 += c1
            sum2 += c2
            sum3 += c3
            sum4 += c4
        for intron, (c1, c2, c3, c4) in _dict.items():
            v1 = func(c1, sum1)
            v2 = func(c2, sum2)
            v3 = func(c3, sum3)
            v4 = func(c4, sum4)
            if intron in sig_introns:
                if intron in intron_sample_dict:
                    _v1 = intron_sample_dict[intron][s1]
                    _v2 = intron_sample_dict[intron][s2]
                    _v3 = intron_sample_dict[intron][s3]
                    _v4 = intron_sample_dict[intron][s4]
                    intron_sample_dict[intron][s1] = custom_max(_v1, v1)
                    intron_sample_dict[intron][s2] = custom_max(_v2, v2)
                    intron_sample_dict[intron][s3] = custom_max(_v3, v3)
                    intron_sample_dict[intron][s4] = custom_max(_v4, v4)
                else:
                    intron_sample_dict[intron] = {s1: v1, s2: v2, s3: v3, s4: v4}

    for (_chr, strand, start, end), _dict in intron_sample_dict.items():
        for s, v in _dict.items():
            sample_intron_dict[(s, _chr, strand, start, end)].append(v)


def custom_mean(_list):
    _sum = count = 0
    for v in _list:
        if v:
            _sum += v
            count += 1
    return _sum / count if count else 0


intron_sample_dict = defaultdict(dict)
for (s, _chr, strand, start, end), _list in sample_intron_dict.items():
    intron_sample_dict[(f'{_chr}_{strand}_{start}_{end}')][s] = custom_mean(_list)


data_df = pd.DataFrame.from_dict(intron_sample_dict, orient='index')
data_df = data_df.rename(columns={'DRR075852': '2D', 'DRR075859': '2D', 'DRR075853': '4D', 'DRR075860': '4D', 'DRR075854': '6D', 'DRR075861': '6D', 'DRR075862': '8D', 'DRR075855': '8D', 'DRR075856': '10D', 'DRR075863': '10D', 'DRR075864': '12D', 'DRR075857': '12D', 'DRR075865': '14D', 'DRR075858': '14D'})

mask = data_df.isnull()
method = 'average'
metric = 'cityblock'
# file = '/ccb/salz3/gyang/DRA005238/MntJULiP/mntjulip_clustermap_0.5.png'
# figure = sns.clustermap(data_df.fillna(0.5), cmap="YlOrBr",
#                         metric=metric, method=method, mask=mask,
#                         yticklabels=False, xticklabels=True)
# figure.ax_heatmap.set_facecolor("lightgray")
# figure.savefig(file)
# plt.close()


file = f'{base_dir}/mntjulip_clustermap_pairwise_na0_dpsi{cutoff}.png'
figure = sns.clustermap(data_df.fillna(0), cmap="YlOrBr",
                        metric=metric, method=method, mask=mask,
                        yticklabels=False, xticklabels=True)
figure.ax_heatmap.set_facecolor("lightgray")
figure.savefig(file)
plt.close()
