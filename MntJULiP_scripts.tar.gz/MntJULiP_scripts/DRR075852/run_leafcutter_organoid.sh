BASE_DIR="/ccb/salz3/gyang/DRA005238"
DATA_DIR="${BASE_DIR}/BAMs/"
LOCAL_DATA_DIR="${BASE_DIR}/LeafCutter/data"

SOFTWARE_BASE_DIR="/ccb/salz3/gyang/softwares/leafcutter"
bam2junc="${SOFTWARE_BASE_DIR}/scripts/bam2junc.sh"
leafcutter_cluster="${SOFTWARE_BASE_DIR}/clustering/leafcutter_cluster.py"
leafcutter_ds="${SOFTWARE_BASE_DIR}/scripts/leafcutter_ds.R"
gtf_to_exons="${SOFTWARE_BASE_DIR}/scripts/gtf_to_exons.R"

PATH=$PATH:${SOFTWARE_BASE_DIR}/scripts

mkdir -p $LOCAL_DATA_DIR

n=15
i=0
for name in DRR075852 DRR075854 DRR075856 DRR075858 DRR075860 DRR075862 DRR075864 DRR075853 DRR075855 DRR075857 DRR075859 DRR075861 DRR075863 DRR075865
do
    ln -s ${DATA_DIR}/star_${name}_Aligned.sortedByCoord.out.bam ${LOCAL_DATA_DIR}/${name}.bam
    sh ${bam2junc} ${LOCAL_DATA_DIR}/${name}.bam ${LOCAL_DATA_DIR}/${name}.bam.junc &
    echo ${LOCAL_DATA_DIR}/${d}.bam.junc >> test_juncfiles.txt
    i=$(($i+1))
    if [ $i -eq $n ]; then
        wait
        i=0
    fi
done
wait

Rscript ${gtf_to_exons} /ccb/salz3/florea/Hippocampus/gencode.vM17.annotation.gtf.gz ${LOCAL_DATA_DIR}/exons.txt.gz &  ##

##################################################### 2D vs 4D ##########################################################
WORK_DIR="${BASE_DIR}/LeafCutter/2D_4D"  ##
mkdir -p ${WORK_DIR}
cd ${WORK_DIR}

for name in DRR075852 DRR075859 DRR075853 DRR075860
do
    echo ${LOCAL_DATA_DIR}/${name}.bam.junc >> test_juncfiles.txt
done

python ${leafcutter_cluster} -j test_juncfiles.txt -o results

for name in DRR075852 DRR075859
do
    echo "${name}.bam 2D" >> test_diff_introns.txt
done

for name in DRR075853 DRR075860
do
    echo "${name}.bam 4D" >> test_diff_introns.txt
done

threads=10
${leafcutter_ds} -i 2 -g 2 -p ${threads} \
                 -e "${LOCAL_DATA_DIR}/exons.txt.gz" \
                 results_perind_numers.counts.gz \
                 test_diff_introns.txt




for i in 2D,4D,DRR075852,DRR075859,DRR075853,DRR075860 2D,6D,DRR075852,DRR075859,DRR075854,DRR075861 2D,8D,DRR075852,DRR075859,DRR075862,DRR075855 2D,10D,DRR075852,DRR075859,DRR075856,DRR075863 2D,12D,DRR075852,DRR075859,DRR075864,DRR075857 2D,14D,DRR075852,DRR075859,DRR075865,DRR075858 4D,6D,DRR075853,DRR075860,DRR075854,DRR075861 4D,8D,DRR075853,DRR075860,DRR075862,DRR075855 4D,10D,DRR075853,DRR075860,DRR075856,DRR075863 4D,12D,DRR075853,DRR075860,DRR075864,DRR075857 4D,14D,DRR075853,DRR075860,DRR075865,DRR075858 6D,8D,DRR075854,DRR075861,DRR075862,DRR075855 6D,10D,DRR075854,DRR075861,DRR075856,DRR075863 6D,12D,DRR075854,DRR075861,DRR075864,DRR075857 6D,14D,DRR075854,DRR075861,DRR075865,DRR075858 8D,10D,DRR075862,DRR075855,DRR075856,DRR075863 8D,12D,DRR075862,DRR075855,DRR075864,DRR075857 8D,14D,DRR075862,DRR075855,DRR075865,DRR075858 10D,12D,DRR075856,DRR075863,DRR075864,DRR075857 10D,14D,DRR075856,DRR075863,DRR075865,DRR075858 12D,14D,DRR075864,DRR075857,DRR075865,DRR075858
do
    IFS=","
    set -- $i
    WORK_DIR="${BASE_DIR}/LeafCutter/${1}_${2}"  ##
    mkdir -p ${WORK_DIR}
    cd ${WORK_DIR}

    for name in $3 $4 $5 $6
    do
        echo ${LOCAL_DATA_DIR}/${name}.bam.junc >> test_juncfiles.txt
    done

    python ${leafcutter_cluster} -j test_juncfiles.txt -o results

    for name in $3 $4
    do
        echo "${name}.bam ${1}" >> test_diff_introns.txt
    done

    for name in $5 $6
    do
        echo "${name}.bam ${2}" >> test_diff_introns.txt
    done

    threads=10
    ${leafcutter_ds} -i 2 -g 2 -p ${threads} \
                     -e "${LOCAL_DATA_DIR}/exons.txt.gz" \
                     results_perind_numers.counts.gz \
                     test_diff_introns.txt
done


# python script to generate param tuples
# L = [('2D', 'DRR075852,DRR075859'), ('4D', 'DRR075853,DRR075860'), ('6D', 'DRR075854,DRR075861'), ('8D', 'DRR075862,DRR075855'), ('10D', 'DRR075856,DRR075863'), ('12D', 'DRR075864,DRR075857'), ('14D', 'DRR075865,DRR075858')]

# out = ''
# for i in range(len(L)):
#     for j in range(i+1, len(L)):
#         o1, o2 = L[i]
#         o3, o4 = L[j]
#         out += f"{o1},{o3},{o2},{o4} "

# print(out)
