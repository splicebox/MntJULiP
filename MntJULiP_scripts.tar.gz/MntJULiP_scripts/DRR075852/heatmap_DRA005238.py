################################################################################################################
from collections import defaultdict
import numpy as np
import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt


file = '/ccb/salz3/gyang/DRA005238/Mnt_JULiP_out/diff_introns.txt'
with open(file, 'r') as f:
    lines = f.readlines()

gene_dict = defaultdict(lambda: (0, 0, 0, 0, 0, 0, 0))
for line in lines[1:]:
    _chr, start, end, strand, gene_names_str, status, _, p_value, q_value, m1, m2, m3, m4, m5, m6, m7 = line.strip().split('\t')
    if status == 'TEST' and gene_names_str != '.':
        start, end, p_value, q_value = int(start), int(end), float(p_value), float(q_value)
        m1, m2, m3, m4, m5, m6, m7 = float(m1), float(m2), float(m3), float(m4), float(m5), float(m6), float(m7)
        for name in gene_names_str.split(','):
            _m1, _m2, _m3, _m4, _m5, _m6, _m7 = gene_dict[name]
            gene_dict[name] = (_m1 + m1, _m2 + m2, _m3 + m3, _m4 + m4, _m5 + m5, _m6 + m6, _m7 + m7)

gene_set = set()
for name, (m1, m2, m3, m4, m5, m6, m7) in gene_dict.items():
    if m1 > 30 or m2 > 30 or m3 > 30 or m4 > 30 or m5 > 30 or m6 > 30 or m7 > 30:
        gene_set.add(name)


file = '/ccb/salz3/gyang/DRA005238/Mnt_JULiP_out/diff_spliced_groups.txt'
with open(file, 'r') as f:
    lines = f.readlines()

group_set = set()
group_gene_dict = {}
for line in lines[1:]:
    group_id, _chr, _, strand, gene_names_str, _, _, p_value, q_value = line.strip().split('\t')
    p_value, q_value = float(p_value), float(q_value)
    if gene_names_str != '.' and len(gene_names_str.split(',')) == 1:
        gene_name = gene_names_str.split(',')[0]
        if gene_name in gene_set and p_value < 0.05:
            group_set.add(group_id)
            group_gene_dict[group_id] = gene_name


file = '/ccb/salz3/gyang/DRA005238/Mnt_JULiP_out/diff_spliced_introns.txt'
with open(file, 'r') as f:
    lines = f.readlines()

def get_abs_max_dpsi(psi_list):
    abs_max_dpsi = 0
    for i, psi1 in enumerate(psi_list):
        for psi2 in psi_list[i + 1:]:
            if abs(psi1 - psi2) > abs_max_dpsi:
                abs_max_dpsi = abs(psi1 - psi2)
    return abs_max_dpsi


group_introns_dict = defaultdict(list)
group_sig_introns_dict = defaultdict(list)
for line in lines[1:]:
    group_id, _chr, start, end, strand, gene_names_str, psi1, psi2, psi3, psi4, psi5, psi6, psi7 = line.strip().split('\t')
    start, end = int(start), int(end)
    psi_list = [psi1, psi2, psi3, psi4, psi5, psi6, psi7]
    psi_list = [float(v) for v in psi_list]
    if group_id in group_set:
        group_introns_dict[group_id].append((_chr, strand, start, end))
        abs_max_dpsi = get_abs_max_dpsi(psi_list)
        if abs_max_dpsi > 0.2:
            group_sig_introns_dict[group_id].append((_chr, strand, start, end))

file = '/ccb/salz3/gyang/DRA005238/Mnt_JULiP_out/intron_data.txt'
with open(file, 'r') as f:
    lines = f.readlines()

intron_counts_dict = {}
for line in lines[1:]:
    _chr, start, end, strand, gene_names_str, status, cond1, cond2, cond3, cond4, cond5, cond6, cond7 = line.strip().split('\t')
    if status == "OK":
        counts = []
        for cond in [cond1, cond2, cond3, cond4, cond5, cond6, cond7]:
            for count in cond.split(','):
                counts.append(int(count))
        intron_counts_dict[(_chr, strand, int(start), int(end))] = counts

columns = ['2D', '2D', '4D', '4D', '6D', '6D', '8D', '8D', '10D', '10D', '12D', '12D', '14D', '14D']
intron_counts_df = pd.DataFrame.from_dict(intron_counts_dict, orient='index', columns=columns)

psis_list = []
# gene_set = set()
for group_id, intron_list in group_introns_dict.items():
    sums = intron_counts_df.loc[intron_list].sum(axis = 0).values
    for index, row in intron_counts_df.loc[group_sig_introns_dict[group_id]].iterrows():
        values = row.values
        psis = values / sums
        psis_list.append(psis.tolist())
        # print(row.name, group_gene_dict[group_id])
    # gene_set.add(group_gene_dict[group_id])


psis_array = pd.DataFrame(np.asarray(psis_list), columns=columns)
cmap = sns.cm.rocket_r

ax = sns.heatmap(psis_array, yticklabels=False, cmap=cmap)
file = 'heatmap.png'
figure = ax.get_figure()
figure.savefig(file)

# file = 'clustermap.png'
# figure = sns.clustermap(psis_array, yticklabels=False, cmap=cmap)
# figure.savefig(file)

plt.close()
