## tophat script
WORKDIR=/ccb/salz3/gyang/DRA005238
STAR2IDX=/ccb/salz3/florea/Hippocampus/STAR_IDX

cd ${WORKDIR}

cores=15

for name in DRR075852 DRR075854 DRR075856 DRR075858 DRR075860 DRR075862 DRR075864 DRR075853 DRR075855 DRR075857 DRR075859 DRR075861 DRR075863 DRR075865
do
    STAR --runThreadN ${cores} \
         --genomeDir ${STAR2IDX} \
         --readFilesIn ${WORKDIR}/${name}.fastq.bz2 \
         --readFilesCommand bzcat \
         --outSAMtype BAM SortedByCoordinate \
         --outSAMstrandField intronMotif \
         --outFileNamePrefix star_${name}_
done
