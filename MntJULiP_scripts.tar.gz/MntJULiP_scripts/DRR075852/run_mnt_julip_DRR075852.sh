SOFTWARE_DIR='/ccb/salz3/gyang/softwares/'
BASE_DIR='/ccb/salz3/gyang/DRA005238/MntJULiP'

cd ${SOFTWARE_DIR}/MntJULiP
# mkdir -p ${BASE_DIR}/

#######

for dir in all 2D_4D 2D_6D 2D_8D 2D_10D 2D_12D 2D_14D 4D_6D 4D_8D 4D_10D 4D_12D 4D_14D 6D_8D 6D_10D 6D_12D 6D_14D 8D_10D 8D_12D 8D_14D 10D_12D 10D_14D 12D_14D
do
    WORK_DIR="${BASE_DIR}/${dir}"
    python3 run.py --out-dir ${WORK_DIR} \
                   --bam-list ${WORK_DIR}/bam_list.txt \
                   --num-threads 10 \
                   --min-count 5 \
                   --batch-size 2000 \
                   --anno-file /ccb/salz3/florea/Hippocampus/gencode.vM17.annotation.gtf
done



###################
SOFTWARE_DIR='/ccb/salz3/gyang/softwares/'
BASE_DIR='/ccb/salz3/gyang/DRA005238/MntJULiP_group_filter'

cd ${SOFTWARE_DIR}/MntJULiP
# mkdir -p ${BASE_DIR}/

#######

for dir in all 2D_4D 2D_6D 2D_8D 2D_10D 2D_12D 2D_14D 4D_6D 4D_8D 4D_10D 4D_12D 4D_14D
do
    WORK_DIR="${BASE_DIR}/${dir}"
    python3 run.py --out-dir ${WORK_DIR} \
                   --bam-list ${WORK_DIR}/bam_list.txt \
                   --num-threads 10 \
                   --min-count 20 \
                   --batch-size 2000 \
                   --group-filter 15 \
                   --anno-file /ccb/salz3/florea/Hippocampus/gencode.vM17.annotation.gtf
done

for dir in 6D_8D 6D_10D 6D_12D 6D_14D 8D_10D 8D_12D 8D_14D 10D_12D 10D_14D 12D_14D
do
    WORK_DIR="${BASE_DIR}/${dir}"
    python3 run.py --out-dir ${WORK_DIR} \
                   --bam-list ${WORK_DIR}/bam_list.txt \
                   --num-threads 10 \
                   --min-count 20 \
                   --batch-size 2000 \
                   --group-filter 15 \
                   --anno-file /ccb/salz3/florea/Hippocampus/gencode.vM17.annotation.gtf
done
