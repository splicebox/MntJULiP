from collections import defaultdict
import gzip
import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt
import seaborn as sns


base_dir = "/ccb/salz3/gyang/DRA005238/MntJULiP"
sig_introns = set()
sig_genes = set()
group_count_dict = {}
cutoff = 0.2 ###################
global_group_count_dict = defaultdict(int)
# for folder in ["2D_4D", "4D_6D", "6D_8D", "8D_10D", "10D_12D", "12D_14D"]:
for folder in ["2D_4D", "2D_6D", "2D_8D", "2D_10D", "2D_12D", "2D_14D", "4D_6D", "4D_8D", "4D_10D", "4D_12D", "4D_14D", "6D_8D", "6D_10D", "6D_12D", "6D_14D", "8D_10D", "8D_12D", "8D_14D", "10D_12D", "10D_14D", "12D_14D"]:
    # get sig groups
    file = f'{base_dir}/{folder}/diff_spliced_groups.txt'
    with open(file, 'r') as f:
        lines = f.readlines()

    sig_groups = {}
    for line in lines[1:]:
        group_id, _chr, _, strand, gene_name_str, _, _, p_value, q_value = line.strip().split('\t')
        if float(p_value) < 0.05:
            sig_groups[group_id] = 0

    # get intron max count
    file = f'{base_dir}/{folder}/intron_data.txt'
    with open(file, 'r') as f:
        lines = f.readlines()

    intron_counts_dict = {}
    for line in lines[1:]:
        _chr, start, end, strand, gene_name_str, status, str1, str2 = line.strip().split('\t')
        start, end = int(start), int(end)
        intron = (_chr, strand, start, end)
        c1, c2 = (float(c) for c in str1.split(','))
        c3, c4 = (float(c) for c in str2.split(','))
        intron_counts_dict[intron] = max(c1, c2, c3, c4)

    file = f'{base_dir}/{folder}/diff_spliced_introns.txt'
    with open(file, 'r') as f:
        lines = f.readlines()

    group_counts_dict = defaultdict(int)
    group_introns_dict = defaultdict(list)
    for line in lines[1:]:
        items = line.strip().split('\t')
        group_id, _chr, start, end, strand, gene_name_str = items[:6]
        start, end, dpsi = int(start), int(end), float(items[-1])
        group_introns_dict[group_id].append((_chr, strand, start, end))
        group_counts_dict[group_id] += intron_counts_dict[(_chr, strand, start, end)]
        if group_id in sig_groups and abs(dpsi) > 0.05:
            sig_groups[group_id] = 1

    for group_id, val in sig_groups.items():
        if val == 1:
            temp = set()
            for (_chr, strand, start, end) in group_introns_dict[group_id]:
                temp.add(start)
                temp.add(end)
            _str = '_'.join([str(v) for v in sorted(temp)])
            new_id = f'{_chr}_{strand}_{_str}'
            global_group_count_dict[new_id] = max(group_counts_dict[group_id], global_group_count_dict[new_id])

file = f'/ccb/salz3/gyang/DRA005238/MntJULiP/distplot_max_dpsi0.2.png'
plot = sns.distplot(list(global_group_count_dict.values()), bins=2000)

plot.set(xlim=(0, 200))
fig = plot.get_figure()
fig.savefig(file)
plt.close()
