from collections import defaultdict
import gzip
import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt
import seaborn as sns
import numpy as np
import gzip

base_dir = "/ccb/salz3/gyang/DRA005238/LeafCutter"
sig_introns = set()
sig_genes = set()
group_count_dict = {}
cutoff = 0.2 ###################
global_group_count_dict = defaultdict(list)


# for folder in ["2D_4D", "4D_6D", "6D_8D", "8D_10D", "10D_12D", "12D_14D"]:
for folder in ["2D_4D", "2D_6D", "2D_8D", "2D_10D", "2D_12D", "2D_14D", "4D_6D", "4D_8D", "4D_10D", "4D_12D", "4D_14D", "6D_8D", "6D_10D", "6D_12D", "6D_14D", "8D_10D", "8D_12D", "8D_14D", "10D_12D", "10D_14D", "12D_14D"]:
    # get sig groups
    file = f'{base_dir}/{folder}/leafcutter_ds_cluster_significance.txt'
    with open(file, 'r') as f:
        lines = f.readlines()

    sig_groups = {}
    # cluster status  loglr   df      p       p.adjust        genes
    # chr1:clu_142_NA Success 0.0360730198593444
    for line in lines[1:]:
        group, status, _, _, p_value, q_value, gene_name_str = line.strip().split('\t')
        if status == "Success" and float(p_value) < 0.05:
            _chr, group_id = group.split(':')
            sig_groups[group_id] = 0

    # get intron counts
    file = f'{base_dir}/{folder}/results_perind_numers.counts.gz'
    with gzip.open(file, 'rb') as f:
        lines = f.readlines()

    intron_counts_dict = {}
    for line in lines[1:]:
        # chr2:3713636:3772796:clu_1_NA 27 17 20 6
        info, c1, c2, c3, c4 = line.decode('UTF-8').strip().split(' ')
        c1, c2, c3, c4 = int(c1), int(c2), int(c3), int(c4)
        _chr, start, end, group_id = info.split(':')
        start, end = int(start), int(end)
        intron = (_chr, start, end)
        intron_counts_dict[intron] = [c1, c2, c3, c4]

    file = f'{base_dir}/{folder}/leafcutter_ds_effect_sizes.txt'
    with open(file, 'r') as f:
        lines = f.readlines()

    group_counts_dict = defaultdict(lambda: (0, 0, 0, 0))
    group_introns_dict = defaultdict(list)
    for line in lines[1:]:
        # intron  logef   14D     8D      deltapsi
        info, _, _, _, dpsi = line.strip().split('\t')
        _chr, start, end, group_id = info.split(':')
        start, end, dpsi = int(start), int(end), float(dpsi)
        group_introns_dict[group_id].append((_chr, start, end))
        group_counts_dict[group_id] = [v1 + v2 for v1, v2 in zip(group_counts_dict[group_id], intron_counts_dict[(_chr, start, end)])]
        if group_id in sig_groups and abs(dpsi) > 0.05:
            sig_groups[group_id] = 1

    for group_id, val in sig_groups.items():
        if val == 1:
            temp = set()
            for (_chr, start, end) in group_introns_dict[group_id]:
                temp.add(start)
                temp.add(end)
            _str = '_'.join([str(v) for v in sorted(temp)])
            new_id = f'{_chr}_{_str}'
            global_group_count_dict[new_id] += group_counts_dict[group_id]

res = [np.median(l) for l in global_group_count_dict.values()]

file = f'/ccb/salz3/gyang/DRA005238/LeafCutter/distplot_median_dpsi0.2.png'
plot = sns.distplot(res, bins=2000)

plot.set(xlim=(0, 200))
fig = plot.get_figure()
fig.savefig(file)
plt.close()
