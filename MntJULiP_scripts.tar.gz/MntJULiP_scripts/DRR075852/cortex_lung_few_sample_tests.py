from collections import defaultdict
import numpy as np
base_dir = "/home-2/gyang22@jhu.edu/work/projects/MntJulip/mntjulip_testing"

for folder in ["2_samples", "3_samples", "5_samples", "7_samples", "10_samples", "15_samples"]:
    file = f'{base_dir}/{folder}/diff_introns.txt'
    with open(file, 'r') as f:
        lines = f.readlines()

    num_conds = len(lines[0].split('\t')) - 9
    gene_dict = defaultdict(lambda: np.zeros(num_conds))
    for line in lines[1:]:
        items = line.strip().split('\t')
        _chr, start, end, strand, gene_names_str, status, _, p_value, q_value = items[:9]
        if status == 'TEST' and gene_names_str != '.':
            start, end, p_value, q_value = int(start), int(end), float(p_value), float(q_value)
            means = np.array([float(m) for m in items[9:]])
            for name in gene_names_str.split(','):
                gene_dict[name] += means

    gene_set = set(name for name, means in gene_dict.items() if np.any(gene_dict[name] > 30))

    file = f'{base_dir}/{folder}/diff_spliced_groups.txt'
    with open(file, 'r') as f:
        lines = f.readlines()

    group_pvalue_dict = {}
    for line in lines[1:]:
        group_id, _chr, _, strand, gene_name_str, _, _, p_value, q_value = line.strip().split('\t')
        group_pvalue_dict[group_id] = float(p_value)

    file = f'{base_dir}/{folder}/diff_spliced_introns.txt'
    with open(file, 'r') as f:
        lines = f.readlines()

    introns = set()
    genes = set()
    for line in lines[1:]:
        items = line.strip().split('\t')
        group_id, _chr, start, end, strand, gene_name_str = items[:6]
        start, end, dpsi = int(start), int(end), float(items[-1])
        if group_pvalue_dict[group_id] < 0.05 and abs(dpsi) > 0.05:
            for gene_name in gene_name_str.split(','):
                if gene_name in gene_set:
                    introns.add((_chr, strand, start, end))
                    genes.add(gene_name)
    print(f'{folder}: {len(introns)} introns, {len(genes)} genes')



base_dir = "/home-2/gyang22@jhu.edu/work/projects/MntJulip"
folder = 'cortex_lung_out'
file = f'{base_dir}/{folder}/diff_introns.txt'
with open(file, 'r') as f:
    lines = f.readlines()

num_conds = len(lines[0].split('\t')) - 9
gene_dict = defaultdict(lambda: np.zeros(num_conds))
for line in lines[1:]:
    items = line.strip().split('\t')
    _chr, start, end, strand, gene_names_str, status, _, p_value, q_value = items[:9]
    if status == 'TEST' and gene_names_str != '.':
        start, end, p_value, q_value = int(start), int(end), float(p_value), float(q_value)
        means = np.array([float(m) for m in items[9:]])
        for name in gene_names_str.split(','):
            gene_dict[name] += means

gene_set = set(name for name, means in gene_dict.items() if np.any(gene_dict[name] > 30))

file = f'{base_dir}/{folder}/diff_spliced_groups.txt'
with open(file, 'r') as f:
    lines = f.readlines()

group_pvalue_dict = {}
for line in lines[1:]:
    group_id, _chr, _, strand, gene_name_str, _, _, p_value, q_value = line.strip().split('\t')
    group_pvalue_dict[group_id] = float(p_value)

file = f'{base_dir}/{folder}/diff_spliced_introns.txt'
with open(file, 'r') as f:
    lines = f.readlines()

introns = set()
genes = set()
for line in lines[1:]:
    items = line.strip().split('\t')
    group_id, _chr, start, end, strand, gene_name_str = items[:6]
    start, end, dpsi = int(start), int(end), float(items[-1])
    if group_pvalue_dict[group_id] < 0.05 and abs(dpsi) > 0.05:
        for gene_name in gene_name_str.split(','):
            if gene_name in gene_set:
                introns.add((_chr, strand, start, end))
                genes.add(gene_name)
print(f'{folder}: {len(introns)} introns, {len(genes)} genes')
