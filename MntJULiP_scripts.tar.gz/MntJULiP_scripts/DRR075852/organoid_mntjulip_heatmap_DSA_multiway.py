from collections import defaultdict
from collections import OrderedDict
import numpy as np
import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt


folder = '/ccb/salz3/gyang/DRA005238/MntJULiP/all/'

file = folder + 'diff_introns.txt'
with open(file, 'r') as f:
    lines = f.readlines()

num_conds = len(lines[0].split('\t')) - 9
sig_introns = set()
for line in lines[1:]:
    items = line.strip().split('\t')
    _chr, start, end, strand, gene_names_str, status, _, p_value, q_value = items[:9]
    if status == 'TEST' and gene_names_str != '.':
        start, end, p_value, q_value = int(start), int(end), float(p_value), float(q_value)
        if p_value < 0.05:
            sig_introns.add((_chr, strand, start, end))

##########
file = folder + 'intron_data.txt'
with open(file, 'r') as f:
    lines = f.readlines()

intron_counts_dict = {}
for line in lines[1:]:
    items = line.strip().split('\t')
    _chr, start, end, strand, gene_names_str, status = items[:6]
    start, end = int(start), int(end)
    intron = (_chr, strand, start, end)
    if status == "OK" and intron in sig_introns:
        counts = []
        for cond_counts in items[6:]:
            for count in cond_counts.split(','):
                counts.append(int(count))
        intron_counts_dict[intron] = np.log2(np.array(counts)+0.01)

##########
columns = []
for _str, cond_counts in zip(lines[0].strip().split('\t')[6:], items[6:]):
    name = _str[12:-1]
    columns += [name] * len(cond_counts.split(','))


intron_counts_df = pd.DataFrame.from_dict(intron_counts_dict, orient='index', columns=columns)
intron_counts_df = pd.concat([intron_counts_df.iloc[:, 6:], intron_counts_df.iloc[:, :6]], axis=1)

method = 'average'
metric = 'cityblock'

file = f'/ccb/salz3/gyang/DRA005238/MntJULiP/mntjulip_clustermap_DSA_multiway.png'
figure = sns.clustermap(intron_counts_df, cmap="YlOrBr",
                        metric=metric, method=method,
                        yticklabels=False)
figure.ax_heatmap.set_facecolor("lightgray")
figure.savefig(file)
plt.close()

file = f'/ccb/salz3/gyang/DRA005238/MntJULiP/mntjulip_clustermap_DSA_multiway_row_cluster.png'
figure = sns.clustermap(intron_counts_df, cmap="YlOrBr", col_cluster=False,
                        metric=metric, method=method,
                        yticklabels=False)
figure.ax_heatmap.set_facecolor("lightgray")
figure.savefig(file)
plt.close()
