# dict tran and fpkm
from collections import defaultdict

import numpy as np


tran_exons_dict = defaultdict(list)
gtf_file = '/Users/gyang/test/annotation.gtf'
chr_strand_tran_exons_dict = defaultdict(lambda: defaultdict(lambda: defaultdict(list)))
gene_chr_strand_dict = {}
with open(gtf_file, 'r') as f:
    for line in f:
        if line is not '\n':
            items = line.strip().split('\t')
            if items[2] == 'exon':
                _chr, strand = items[0], items[6]
                start, end = items[3: 5]
                _items = items[8].split('"')
                tran_id, gene_id = _items[3], _items[1]
                chr_strand_tran_exons_dict[_chr][strand][tran_id].append((int(start), int(end)))
                gene_chr_strand_dict[gene_id] = (_chr, strand)

chrs = list(chr_strand_tran_exons_dict.keys())


def get_introns(exons):
    if len(exons) <= 1:
        return []
    else:
        introns = []
        _list = sorted(exons)
        start = _list[0][1]
        for i in range(1, len(_list)):
            end = _list[i][0]
            introns.append((start, end))
            start = _list[i][1]
        return introns


chr_strand_tran_introns_dict = defaultdict(lambda: defaultdict(lambda: defaultdict(list)))
chr_strand_intron_trans_dict = defaultdict(lambda: defaultdict(lambda: defaultdict(list)))
for _chr in chrs:
    for strand in ['-', '+']:
        for tran_id, exons in chr_strand_tran_exons_dict[_chr][strand].items():
            introns = get_introns(exons)
            chr_strand_tran_introns_dict[_chr][strand][tran_id] = introns
            for intron in introns:
                chr_strand_intron_trans_dict[_chr][strand][intron].append(tran_id)


gene_file = '/Users/gyang/test/genes_info.txt'
tran_fpkm_control_dict = {}
tran_fpkm_case_dict = {}
chosen_tran_set = set()
gene_fpkm_control_dict = defaultdict(lambda: 0)
gene_fpkm_case_dict = defaultdict(lambda: 0)
tran_gene_dict = {}

with open(gene_file, 'r') as f:
    for line in f:
        items = line.strip().split('\t')
        gene_id = items[0]
        _chr, strand = gene_chr_strand_dict[gene_id]
        bool1, bool2, bool3 = [b == 'True' for b in items[3: 6]]
        if not(bool1 and bool2, and bool3):  # none
            for item in items[6].split(', ')[:1]:
                tran_id, fpkm = item.strip().split(':')


        elif bool1 and not(bool2) and not(bool3):  # DS


        elif not(bool1) and (bool2 or bool3):  # DE

        elif bool1 and bool2 and bool3:  # DE & DS

        else:
            print('error!')
