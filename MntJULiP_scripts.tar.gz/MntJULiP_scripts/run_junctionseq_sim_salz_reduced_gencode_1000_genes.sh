# commands work on bash, in salz machine

QORTS=/ccb/salz3/gyang/QoRTs.jar
BASE_DIR="/ccb/salz3/gyang/simulation3"
WORK_DIR="${BASE_DIR}/JunctionSeq_reduced_annotation_1000_ds_genes"
DATA_DIR="${BASE_DIR}/Tophat"
GTF="${BASE_DIR}/meta_info/reduced_gencode.v22.annotation_1000_ds_genes.gtf"

# rm -rf ${WORK_DIR}
mkdir -p ${WORK_DIR}/inputData/annoFiles/
mkdir -p ${WORK_DIR}/outputData/qortsData/
cd ${WORK_DIR}

mkdir -p ${WORK_DIR}/inputData/annoFiles/
cp ${BASE_DIR}/JunctionSeq/inputData/annoFiles/chrom.sizes ${WORK_DIR}/inputData/annoFiles/


rm -rf outputData/qortsData/*
for t in case control
do
    for i in {01..25}
    do

        java -Xmx18G -jar $QORTS QC \
             --minMAPQ 50 \
             --runFunctions writeKnownSplices,writeNovelSplices,writeSpliceExon \
             --chromSizes inputData/annoFiles/chrom.sizes \
             ${DATA_DIR}/${t}/sample_${i}/accepted_hits.bam \
             ${GTF} \
             outputData/qortsData/${t}_sample_${i}
    done
done

##### starting Here !!!!!!!!!
##############################################################################
cp ${BASE_DIR}/JunctionSeq/inputData/annoFiles/decoder.byUID.txt ${WORK_DIR}/inputData/annoFiles/

mkdir -p ${WORK_DIR}/outputData/countTables/
java -jar $QORTS \
            mergeAllCounts \
            outputData/qortsData/ \
            inputData/annoFiles/decoder.byUID.txt \
            outputData/countTables/


##############################################################################
cp ${BASE_DIR}/JunctionSeq/inputData/annoFiles/decoder.bySample.txt ${WORK_DIR}/inputData/annoFiles/

java -Xmx14G -jar $QORTS \
                mergeNovelSplices \
                --minCount 6 \
                outputData/countTables/ \
                inputData/annoFiles/decoder.bySample.txt \
                ${GTF} \
                outputData/countTables/

mkdir -p ${WORK_DIR}/outputData/analyses/JunctionSeq/results/

######################################### In R, run JunctionSeq ##########################
# /ccb/salz3/gyang/softwares/R_3.6.2/bin/R
suppressPackageStartupMessages(library("JunctionSeq"));

#The sample decoder:
decoder <- read.table("inputData/annoFiles/decoder.bySample.txt",
                    header=T,stringsAsFactors=F);
countFiles <- paste0("outputData/countTables/",
                    decoder$sample.ID,
                    "/QC.spliceJunctionAndExonCounts.withNovel.forJunctionSeq.txt.gz"
);

jscs <- runJunctionSeqAnalyses(sample.files = countFiles,
                            sample.names = decoder$sample.ID,
                            condition = factor(decoder$group.ID),
                            flat.gff.file = "outputData/countTables/withNovel.forJunctionSeq.gff.gz",
                            nCores = 4,
                            verbose = TRUE,
                            analysis.type = "junctionsAndExons",
);

writeCompleteResults(jscs,
                    outfile.prefix = "outputData/analyses/JunctionSeq/",
                    save.jscs = TRUE
);
