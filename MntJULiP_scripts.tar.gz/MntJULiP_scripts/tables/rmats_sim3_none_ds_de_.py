from pathlib import Path
from collections import defaultdict


def get_introns(exons):
    if len(exons) <= 1:
        return []
    else:
        introns = []
        _list = sorted(exons)
        start = _list[0][1]
        for i in range(1, len(_list)):
            end = _list[i][0]
            introns.append((start, end))
            start = _list[i][1]
        return introns
###############################################################################
# gene_file = '/Users/gyang/test/genes_info.txt'
gene_file = '/ccb/salz3/gyang/simulation3/meta_info/genes_info.txt'

ds_gene_ids = set()
de_gene_ids = set()
ds_de_gene_ids = set()
none_gene_ids = set()
all_gene_ids = set()

with open(gene_file, 'r') as f:
    for line in f:
        items = line.strip().split('\t')
        gene_id = items[0]
        bool1, bool2, bool3 = [b == 'True' for b in items[3: 6]]
        all_gene_ids.add(gene_id)
        if bool1 and not(bool2) and not(bool3):  # DS
            ds_gene_ids.add(gene_id)

        if not(bool1) and (bool2 or bool3):  # DE
            de_gene_ids.add(gene_id)

        if bool1 and (bool2 or bool3):  # DE & DS
            ds_de_gene_ids.add(gene_id)

        if not(bool1 or bool2 or bool3):
            none_gene_ids.add(gene_id)

###############################################################################
# gtf_file = '/Users/gyang/test/annotation.gtf'
# gtf_file = '/Users/gyang/test/gencode.v22.annotation.gtf'
gtf_file = '/ccb/salz3/gyang/simulation3/gencode.v22.annotation.gtf'

gene_id_name_dict = {}
gene_name_ids_dict = defaultdict(list)
tran_exons_dict = defaultdict(list)
with open(gtf_file, 'r') as f:
    for line in f:
        if line is not '\n' and not(line.startswith('#')):
            items = line.strip().split('\t')
            if items[2] == 'exon':
                _chr, strand = items[0], items[6]
                start, end = items[3: 5]
                _items = items[8].split('"')
                tran_id, gene_id = _items[3], _items[1]
                gene_id, gene_name = _items[1], _items[9]
                # rename gene name (from U2AF1 to A2AF1L5) for ENSG00000275895.3 to reduce confusion
                if gene_id == 'ENSG00000275895.3':
                    gene_name = 'A2AF1L5'
                    chr_A2AF1L5 = _chr
                    strand_A2AF1L5 = strand
                    tran_exons_dict[(_chr, strand, tran_id)].append((int(start), int(end)))
                gene_id_name_dict[gene_id] = gene_name
                gene_name_ids_dict[gene_name].append(gene_id)

introns_A2AF1L5 = set()
for _, exons in tran_exons_dict.items():
    introns = get_introns(exons)
    for intron in introns:
        introns_A2AF1L5.add((chr_A2AF1L5, strand_A2AF1L5, *intron))

gene_name_id_dict = {}
for gene_name, gene_ids in gene_name_ids_dict.items():
    gene_name_id_dict[gene_name] = gene_ids[0]
    if len(gene_ids) > 1:
        for gene_id in gene_ids:
            if gene_id in all_gene_ids:
                gene_name_id_dict[gene_name] = gene_id


###############################################################################
# results_dir = Path('/Users/gyang/test/rMATS.3.2.5_star_output')
results_dir = Path('/ccb/salz3/gyang/simulation3/rMATS.3.2.5_stmerged/out/MATS_output')

files = []
numbers = []
files.append(results_dir / 'SE.MATS.ReadsOnTargetAndJunctionCounts.txt')
files.append(results_dir / 'MXE.MATS.ReadsOnTargetAndJunctionCounts.txt')
files.append(results_dir / 'A5SS.MATS.ReadsOnTargetAndJunctionCounts.txt')
files.append(results_dir / 'A3SS.MATS.ReadsOnTargetAndJunctionCounts.txt')
files.append(results_dir / 'RI.MATS.ReadsOnTargetAndJunctionCounts.txt')

# p_values
numbers.append(18)
numbers.append(20)
numbers.append(18)
numbers.append(18)
numbers.append(18)

predicted_gene_ids = set()
for file, num in zip(files, numbers):
    with open(file, 'r') as f:
        lines = f.readlines()

    for line in lines[1:]:
        items = line.strip().split('\t')
        gene_id, p_value = items[1][1:-1], float(items[num])
        gene_name = items[2][1:-1]
        dpsi = float(items[-1])
        if p_value <= 0.1:
            predicted_gene_ids.update(gene_name_ids_dict[gene_name])

print(f"rMATS None: {len(predicted_gene_ids.intersection(none_gene_ids))}")
print(f"rMATS TP DS: {len(predicted_gene_ids.intersection(ds_gene_ids))}")
print(f"rMATS TP DE: {len(predicted_gene_ids.intersection(de_gene_ids))}")
print(f"rMATS TP DS&DE: {len(predicted_gene_ids.intersection(ds_de_gene_ids))}")
print(f"rMATS ALL: {len(predicted_gene_ids)}")
print(f"rMATS others: {len(predicted_gene_ids.difference(none_gene_ids.union(ds_gene_ids).union(de_gene_ids).union(ds_de_gene_ids)))}")

print('\n')
DSR_gene_ids = ds_gene_ids | ds_de_gene_ids
print(f"rMATS TP DSR:", len(DSR_gene_ids & predicted_gene_ids))
print(f"rMATS FP DSR:", len(predicted_gene_ids - DSR_gene_ids))
print(f"rMATS FN DSR:", len(DSR_gene_ids - predicted_gene_ids))

print('\n')
DSA_gene_ids = de_gene_ids | ds_gene_ids | ds_de_gene_ids
print(f"rMATS TP DSR:", len(DSA_gene_ids & predicted_gene_ids))
print(f"rMATS FP DSR:", len(predicted_gene_ids - DSA_gene_ids))
print(f"rMATS FN DSR:", len(DSA_gene_ids - predicted_gene_ids))


# for gene_id in predicted_gene_ids.difference(none_gene_ids.union(ds_gene_ids).union(de_gene_ids).union(ds_de_gene_ids)):
    # print(gene_id_name_dict[gene_id])

