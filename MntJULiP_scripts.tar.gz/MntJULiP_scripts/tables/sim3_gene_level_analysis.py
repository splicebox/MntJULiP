from collections import defaultdict
import numpy as np


def get_introns(exons):
    if len(exons) <= 1:
        return []
    else:
        introns = []
        _list = sorted(exons)
        start = _list[0][1]
        for i in range(1, len(_list)):
            end = _list[i][0]
            introns.append((start, end))
            start = _list[i][1]
        return introns


# read exon info from the file.
tran_exons_dict = defaultdict(list)
gtf_file = '/Users/gyang/test/annotation.gtf'

gene_id_name_dict = {}
gene_name_id_dict = defaultdict(set)
tran_exons_dict = defaultdict(list)
with open(gtf_file, 'r') as f:
    for line in f:
        if line is not '\n':
            items = line.strip().split('\t')
            if items[2] == 'exon':
                _chr, strand = items[0], items[6]
                start, end = items[3: 5]
                _items = items[8].split('"')
                tran_id, gene_id = _items[3], _items[1]
                gene_id, gene_name = _items[1], _items[9]
                tran_exons_dict[(_chr, strand, tran_id)].append((int(start), int(end)))
                gene_id_name_dict[gene_id] = gene_name
                gene_name_id_dict[gene_name].add(gene_id)

# get intron info
tran_introns_dict = {}
intron_trans_dict = defaultdict(list)
for (_chr, strand, tran_id), exons in tran_exons_dict.items():
    introns = get_introns(exons)
    tran_introns_dict[(_chr, strand, tran_id)] = introns
    for intron in introns:
        intron_trans_dict[(_chr, strand, *intron)].append(tran_id)


###############################################################################
gene_file = '/Users/gyang/test/genes_info.txt'
de_genes = []
none_genes = []
ds_genes = []
de_ds_genes = []


with open(gene_file, 'r') as f:
    for line in f:
        items = line.strip().split('\t')
        gene_id = items[0]
        bool1, bool2, bool3 = [b == 'True' for b in items[3: 6]]
        if not(bool1 or bool2 or bool3):
            none_genes.append(gene_id_name_dict[gene_id])

        if bool1 and not(bool2) and not(bool3):  # only swapped the top two trans' expr
            ds_genes.append(gene_id_name_dict[gene_id])

        if not(bool1) and (bool2 or bool3):
            de_genes.append(gene_id_name_dict[gene_id])

        if bool1 and (bool2 or bool3):
            de_ds_genes.append(gene_id_name_dict[gene_id])


print(len(none_genes), len(de_genes), len(ds_genes), len(de_ds_genes))


##########################################################. rMATS  ##############################################################
results_dir = Path('/Users/gyang/test/rMATS.3.2.5_star_output')

files = []
numbers = []
files.append(results_dir / 'SE.MATS.ReadsOnTargetAndJunctionCounts.txt')
files.append(results_dir / 'MXE.MATS.ReadsOnTargetAndJunctionCounts.txt')
files.append(results_dir / 'A5SS.MATS.ReadsOnTargetAndJunctionCounts.txt')
files.append(results_dir / 'A3SS.MATS.ReadsOnTargetAndJunctionCounts.txt')
files.append(results_dir / 'RI.MATS.ReadsOnTargetAndJunctionCounts.txt')

# p_values
numbers.append(18)
numbers.append(20)
numbers.append(18)
numbers.append(18)
numbers.append(18)

for threshold in [0.1, 0.05, 0.01]:
    gene_names = set()
    for file, num in zip(files, numbers):
        with open(file, 'r') as f:
            lines = f.readlines()

        for line in lines[1:]:
            items = line.strip().split('\t')
            gene_name, p_value = items[2][1:-1], float(items[18])
            if p_value <= threshold:
                gene_names.add(gene_name)

    print (len(gene_names.intersection(none_genes)), len(gene_names.intersection(de_genes)),
           len(gene_names.intersection(ds_genes)), len(gene_names.intersection(de_ds_genes)))


file = '/ccb/salz3/gyang/simulation3/LeafCutter/leafcutter_ds_cluster_significance.txt'
for threshold in [0.1, 0.05, 0.01]:
    gene_names = set()
    with open(file, 'r') as f:
        lines = f.readlines()

    for line in lines[1:]:
        items = line.strip().split('\t')
        status, gene_name, p_value = items[1], items[4], items[6]
        if status == 'Success':
            p_value = float(p_value)
            if p_value <= threshold:
                gene_names.add(gene_name)

    print (len(gene_names.intersection(none_genes)), len(gene_names.intersection(de_genes)),
           len(gene_names.intersection(ds_genes)), len(gene_names.intersection(de_ds_genes)))

