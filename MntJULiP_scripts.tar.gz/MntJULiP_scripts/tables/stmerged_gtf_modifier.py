file = '/ccb/salz3/gyang/simulation3/stringtie/sim.stmerged.gtf'
with open(file, 'r') as f:
    lines = f.readlines()

out_buffer = ''
for line in lines:
    if line.startswith('#'):
        out_buffer += line
        continue

    items = line.strip().split('\t')[8].split('; ')
    if "ref_gene_id" in items[-1]:
        ref_gene_id = items[-1].split(' ')[1][:-1]
        gene_id = items[0].split(' ')[1]
        line = line.replace(gene_id, ref_gene_id)
    out_buffer += line

file = '/ccb/salz3/gyang/simulation3/stringtie/sim.stmerged.modified.gtf'
with open(file, 'w') as f:
    f.write(out_buffer)
