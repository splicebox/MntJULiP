import gzip
# gtf_file = '/ccb/salz3/gyang/simulation3/meta_info/annotation.gtf'
gtf_file = '/ccb/salz3/gyang/simulation3/gencode.v22.annotation.gtf'

gene_id_name_dict = {}
gene_id_chr_strand = {}
with open(gtf_file, 'r') as f:
    for line in f:
        if line is not '\n' and not(line.startswith('#')):
            items = line.strip().split('\t')
            if items[2] == 'exon':
                _chr, strand = items[0], items[6]
                start, end = items[3: 5]
                _items = items[8].split('"')
                tran_id, gene_id = _items[3], _items[1]
                gene_id, gene_name = _items[1], _items[9]
                # rename gene name (from U2AF1 to A2AF1L5) for ENSG00000275895.3 to reduce confusion
                if gene_id == 'ENSG00000275895.3':
                    gene_name = 'A2AF1L5'
                gene_id_name_dict[gene_id] = gene_name
                gene_id_chr_strand[gene_id] = (_chr, strand)

###############################################################################
gene_file = '/ccb/salz3/gyang/simulation3/meta_info/genes_info.txt'
diff_present_gene_ids = set()
diff_spliced_gene_ids = set()
diff_gene_ids = set()

with open(gene_file, 'r') as f:
    for line in f:
        items = line.strip().split('\t')
        gene_id = items[0]
        bool1, bool2, bool3 = [b == 'True' for b in items[3: 6]]
        if bool1 and not(bool2) and not(bool3):  # DS
            diff_spliced_gene_ids.add(gene_id)
            diff_gene_ids.add(gene_id)

        if not(bool1) and (bool2 or bool3):  # DE
            diff_present_gene_ids.add(gene_id)
            diff_gene_ids.add(gene_id)

        if bool1 and (bool2 or bool3):  # DE & DS
            diff_present_gene_ids.add(gene_id)
            diff_spliced_gene_ids.add(gene_id)
            diff_gene_ids.add(gene_id)

diff_present_genes = set([gene_id_name_dict[g] for g in diff_present_gene_ids])
diff_spliced_genes = set([gene_id_name_dict[g] for g in diff_spliced_gene_ids])
diff_genes = set([gene_id_name_dict[g] for g in diff_gene_ids])

########################################################  JunctionSeq  #######################################################
# in this result, JunctionSeq is run with 'intronAndExon' option
# but only use differential introns presence to identify differential genes,
# the differential presence of the exons is excluded

# file = '/ccb/salz3/gyang/simulation3/JunctionSeq/outputData/analyses/JunctionSeq/allGenes.results.txt.gz'
file = '/ccb/salz3/gyang/simulation3/JunctionSeq_gencode/outputData/analyses/JunctionSeq/allGenes.results.txt.gz'
with gzip.open(file, 'rb') as f:
    lines = f.readlines()

predicted_gene_ids = set()
for line in lines[1:]:
    items = line.decode('utf8').strip().split('\t')
    gene_id, bin_id, status = items[1], items[2], items[4]
    gene_name = gene_id_name_dict[gene_id]
    if bin_id.startswith('J') and status == 'OK':
        p_value, q_value = float(items[11]), float(items[12])
        start, end = int(items[14]), int(items[15])
        _chr, strand = gene_id_chr_strand[gene_id] # do this because the strand in the junctionseq results file are '.'
        if p_value < 0.1:
            predicted_gene_ids.add(gene_id)

predicted_genes = set([gene_id_name_dict[g] for g in predicted_gene_ids])


# diff all
tp_genes = predicted_genes.intersection(diff_genes)
fp_genes = predicted_genes.difference(diff_genes)
fn_genes = diff_genes.difference(predicted_genes)
print(len(tp_genes), len(fp_genes), len(fn_genes))

# diff presence
tp_genes = predicted_genes.intersection(diff_present_genes)
fp_genes = predicted_genes.difference(diff_present_genes)
fn_genes = diff_present_genes.difference(predicted_genes)
print(len(tp_genes), len(fp_genes), len(fn_genes))
