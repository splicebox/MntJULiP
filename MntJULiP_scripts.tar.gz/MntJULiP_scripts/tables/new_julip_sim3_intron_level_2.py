from collections import defaultdict

import numpy as np


def get_introns(exons):
    if len(exons) <= 1:
        return []
    else:
        introns = []
        _list = sorted(exons)
        start = _list[0][1]
        for i in range(1, len(_list)):
            end = _list[i][0]
            introns.append((start, end))
            start = _list[i][1]
        return introns


# read exon info from the file.
tran_exons_dict = defaultdict(list)
gtf_file = '/Users/gyang/test/gencode.v22.annotation.gtf'

gene_id_name_dict = {}
gene_name_id_dict = defaultdict(set)
tran_exons_dict = defaultdict(list)
tran_gene_dict = {}
with open(gtf_file, 'r') as f:
    for line in f:
        if line.startswith('#'):
            continue
        if line is not '\n':
            items = line.strip().split('\t')
            if items[2] == 'exon':
                _chr, strand = items[0], items[6]
                start, end = items[3: 5]
                _items = items[8].split('"')
                tran_id, gene_id = _items[3], _items[1]
                gene_id, gene_name = _items[1], _items[9]
                tran_exons_dict[(_chr, strand, tran_id)].append((int(start), int(end)))
                gene_id_name_dict[gene_id] = gene_name
                gene_name_id_dict[gene_name].add(gene_id)
                tran_gene_dict[tran_id] = gene_id

# get intron info
tran_introns_dict = defaultdict(set)
intron_gene_dict = defaultdict(set)
for (_chr, strand, tran_id), exons in tran_exons_dict.items():
    introns = get_introns(exons)
    for intron in introns:
        tran_introns_dict[tran_id].add((_chr, strand, *intron))
        intron_gene_dict[(_chr, strand, *intron)].add(tran_gene_dict[tran_id])

###############################################################################
gene_file = '/Users/gyang/test/genes_info.txt'
diff_spliced_intron = {}

diff_spliced_genes = set()
with open(gene_file, 'r') as f:
    for line in f:
        items = line.strip().split('\t')
        gene_id = items[0]
        bool1, bool2, bool3 = [b == 'True' for b in items[3: 6]]
        if bool1 and not(bool2) and not(bool3):  # DS
            diff_spliced_genes.add(gene_id)
            for v in items[6].split(', ')[:2]:
                tran_id, fpkm = v.split(':')
                for intron in tran_introns_dict[tran_id]:
                    diff_spliced_intron[intron] = 1

        if bool1 and (bool2 or bool3):  # DE & DS
            diff_spliced_genes.add(gene_id)
            for v in items[6].split(', '):
                tran_id, fpkm = v.split(':')
                for intron in tran_introns_dict[tran_id]:
                    diff_spliced_intron[intron] = 1

############################################################################################################################
## diff splicing

##
folder = '0.6'  ###
file = f'/Users/gyang/test/simulation_3_out/{folder}/diff_spliced_groups.txt'
with open(file, 'r') as f:
    lines = f.readlines()

group_pvalue_dict = {}
for line in lines[1:]:
    group_id, _chr, _, strand, gene_name, _, _, p_value, q_value = line.strip().split('\t')
    group_pvalue_dict[group_id] = float(p_value)

##
file = f'/Users/gyang/test/simulation_3_out/{folder}/diff_spliced_introns.txt'
with open(file, 'r') as f:
    lines = f.readlines()

tp_diff_spliced_intron = {}
fp_diff_spliced_intron = {}
for line in lines[1:]:
    group_id, _chr, start, end, strand, gene_names_str, _, _, dpsi = line.strip().split('\t')
    start, end, dpsi = int(start), int(end), float(dpsi)
    p_value = group_pvalue_dict[group_id]
    if p_value < 0.1 and abs(dpsi) > 0.05 and gene_names_str != '.':
        if (_chr, strand, start, end) in diff_spliced_intron:
            tp_diff_spliced_intron[(_chr, strand, start, end)] = 1
        else:
            fp_diff_spliced_intron[(_chr, strand, start, end)] = 1

print(len(tp_diff_spliced_intron), len(fp_diff_spliced_intron))
print(len(tp_diff_spliced_intron) + len(fp_diff_spliced_intron))

fp_fp_genes = set()
for intron in fp_diff_spliced_intron.keys():
    gene_ids = intron_gene_dict[intron]
    for gene_id in gene_ids:
        fp_fp_genes.add(gene_id)


tp_fp_genes = set()
for intron in tp_diff_spliced_intron.keys():
    gene_ids = intron_gene_dict[intron]
    for gene_id in gene_ids:
        tp_fp_genes.add(gene_id)

print(len(fp_fp_genes.difference(diff_spliced_genes)))
print(len(fp_fp_genes.intersection(diff_spliced_genes)))

gene_set = fp_fp_genes.difference(tp_fp_genes)

intron_set = set()
for intron in fp_diff_spliced_intron.keys():
    gene_ids = intron_gene_dict[intron]
    for gene_id in gene_ids:
        if gene_id in gene_set:
            intron_set.add(intron)

print(len(intron_set))


print(len(tp_fp_genes.difference(diff_spliced_genes)))
print(len(tp_fp_genes.intersection(diff_spliced_genes)))

# gene_names_a = set()
# for gene_id in a:
#     gene_names_a.add(gene_id_name_dict[gene_id])


# gene_names_b = set()
# for gene_id in b:
#     gene_names_b.add(gene_id_name_dict[gene_id])


# gene_names_b.difference(c)
# # {'IDS', 'ZNF286A'}

# gene_names_a.difference(c)
# # {'CBS', 'U2AF1'}
