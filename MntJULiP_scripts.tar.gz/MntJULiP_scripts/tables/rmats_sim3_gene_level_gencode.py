
from pathlib import Path
from collections import defaultdict

import numpy as np


def get_introns(exons):
    if len(exons) <= 1:
        return []
    else:
        introns = []
        _list = sorted(exons)
        start = _list[0][1]
        for i in range(1, len(_list)):
            end = _list[i][0]
            introns.append((start, end))
            start = _list[i][1]
        return introns


# read exon info from the file.
tran_exons_dict = defaultdict(list)
gtf_file = '/Users/gyang/test/gencode.v22.annotation.gtf'

gene_id_name_dict = {}
gene_name_id_dict = defaultdict(set)
tran_exons_dict = defaultdict(list)
with open(gtf_file, 'r') as f:
    for line in f:
        if line.startswith('#'):
            continue
        if line is not '\n':
            items = line.strip().split('\t')
            if items[2] == 'exon':
                _chr, strand = items[0], items[6]
                start, end = items[3: 5]
                _items = items[8].split('"')
                tran_id, gene_id = _items[3], _items[1]
                gene_id, gene_name = _items[1], _items[9]
                tran_exons_dict[(_chr, strand, tran_id)].append((int(start), int(end)))
                gene_id_name_dict[gene_id] = gene_name
                gene_name_id_dict[gene_name].add(gene_id)

# get intron info
tran_introns_dict = {}
intron_trans_dict = defaultdict(list)
for (_chr, strand, tran_id), exons in tran_exons_dict.items():
    introns = get_introns(exons)
    tran_introns_dict[(_chr, strand, tran_id)] = introns
    for intron in introns:
        intron_trans_dict[(_chr, strand, *intron)].append(tran_id)

###############################################################################
gene_file = '/Users/gyang/test/genes_info.txt'
diff_present_genes = {}
diff_spliced_genes = {}
diff_genes = {}

with open(gene_file, 'r') as f:
    for line in f:
        items = line.strip().split('\t')
        gene_id = items[0]
        bool1, bool2, bool3 = [b == 'True' for b in items[3: 6]]
        if bool1 and not(bool2) and not(bool3):  # DS
            diff_present_genes[gene_id] = 1
            diff_spliced_genes[gene_id] = 1
            diff_genes[gene_id] = 1

        if not(bool1) and (bool2 or bool3):  # DE
            diff_present_genes[gene_id] = 1
            diff_genes[gene_id] = 1

        if bool1 and (bool2 or bool3):  # DE & DS
            diff_present_genes[gene_id] = 1
            diff_spliced_genes[gene_id] = 1
            diff_genes[gene_id] = 1


###############################################################################
results_dir = Path('/Users/gyang/test/rMATS.3.2.5_star_output_gencode')

files = []
numbers = []
files.append(results_dir / 'SE.MATS.ReadsOnTargetAndJunctionCounts.txt')
files.append(results_dir / 'MXE.MATS.ReadsOnTargetAndJunctionCounts.txt')
files.append(results_dir / 'A5SS.MATS.ReadsOnTargetAndJunctionCounts.txt')
files.append(results_dir / 'A3SS.MATS.ReadsOnTargetAndJunctionCounts.txt')
files.append(results_dir / 'RI.MATS.ReadsOnTargetAndJunctionCounts.txt')

# p_values
numbers.append(18)
numbers.append(20)
numbers.append(18)
numbers.append(18)
numbers.append(18)

gene_dict = {}
tp_diff_spliced_genes = {}
tp_diff_present_genes = {}
for file, num in zip(files, numbers):
    with open(file, 'r') as f:
        lines = f.readlines()

    for line in lines[1:]:
        items = line.strip().split('\t')
        gene_id, gene_name, p_value = items[1][1:-1], items[2][1:-1], float(items[num])
        dpsi = float(items[-1])
        if p_value <= 0.1 and abs(dpsi) > 0.05:
        # if p_value <= 0.1:
            if gene_name in gene_dict and gene_dict[gene_name] == 1:
                continue
            else:
                gene_dict[gene_name] = 0  # fp
            if gene_id in diff_genes:
                gene_dict[gene_name] = 1  # tp
                if gene_id in diff_spliced_genes:
                    tp_diff_spliced_genes[gene_name] = 1
                if gene_id in diff_present_genes:
                    tp_diff_present_genes[gene_name] = 1
                diff_genes[gene_id] = 0

tp_genes = set()
fp_genes = set()
for gene_name, v in gene_dict.items():
    if v == 1:
        tp_genes.add(gene_name)
    else:
        fp_genes.add(gene_name)

fn_genes = set()
for gene_id, v in diff_genes.items():
    if v == 1:
        gene_name = gene_id_name_dict[gene_id]
        fn_genes.add(gene_name)

print(len(tp_genes), len(fp_genes), len(fn_genes), len(tp_diff_spliced_genes), len(tp_diff_present_genes))


####### write results to file
out_file = '/Users/gyang/OneDrive/1-Florea Lab/New_JULiP_Paper/results/simulation/gencode/rMATS.txt'
with open(out_file, 'w') as f:
    f.write('TP genes\n')
    f.write(', '.join(tp_genes) + '\n\n')
    f.write('FP genes\n')
    f.write(', '.join(fp_genes) + '\n\n')
    f.write('FN genes\n')
    f.write(', '.join(fn_genes) + '\n\n')
    f.write('TP genes that are differential spliced\n')
    f.write(', '.join(tp_diff_spliced_genes.keys()) + '\n\n')
    f.write('TP genes that are differential present\n')
    f.write(', '.join(tp_diff_present_genes.keys()) + '\n\n')


############################################################################################################################
gene_file = '/Users/gyang/test/genes_info.txt'
diff_present_genes = {}
diff_spliced_genes = {}
diff_genes = {}

with open(gene_file, 'r') as f:
    for line in f:
        items = line.strip().split('\t')
        gene_id = items[0]
        bool1, bool2, bool3 = [b == 'True' for b in items[3: 6]]
        if bool1 and not(bool2) and not(bool3):  # DS
            diff_present_genes[gene_id] = 1
            diff_spliced_genes[gene_id] = 1
            diff_genes[gene_id] = 1

        if not(bool1) and (bool2 or bool3):  # DE
            diff_present_genes[gene_id] = 1
            diff_genes[gene_id] = 1

        if bool1 and (bool2 or bool3):  # DE & DS
            diff_present_genes[gene_id] = 1
            diff_spliced_genes[gene_id] = 1
            diff_genes[gene_id] = 1

results_dir = Path('/Users/gyang/test/rMATS.3.2.5_star_output_gencode')

files = []
numbers = []
files.append(results_dir / 'SE.MATS.ReadsOnTargetAndJunctionCounts.txt')
files.append(results_dir / 'MXE.MATS.ReadsOnTargetAndJunctionCounts.txt')
files.append(results_dir / 'A5SS.MATS.ReadsOnTargetAndJunctionCounts.txt')
files.append(results_dir / 'A3SS.MATS.ReadsOnTargetAndJunctionCounts.txt')
files.append(results_dir / 'RI.MATS.ReadsOnTargetAndJunctionCounts.txt')

# p_values
numbers.append(18)
numbers.append(20)
numbers.append(18)
numbers.append(18)
numbers.append(18)

gene_dict = {}
for file, num in zip(files, numbers):
    with open(file, 'r') as f:
        lines = f.readlines()

    for line in lines[1:]:
        items = line.strip().split('\t')
        gene_id, gene_name, p_value = items[1][1:-1], items[2][1:-1], float(items[num])
        dpsi = float(items[-1])
        # if p_value <= 0.1 and abs(dpsi) > 0.05:
        if p_value <= 0.1:
            if gene_name in gene_dict and gene_dict[gene_name] == 1:
                continue
            else:
                gene_dict[gene_name] = 0  # fp
            if gene_id in diff_spliced_genes:
                gene_dict[gene_name] = 1  # tp
                diff_spliced_genes[gene_id] = 0

tp_genes = set()
fp_genes = set()
for gene_name, v in gene_dict.items():
    if v == 1:
        tp_genes.add(gene_name)
    else:
        fp_genes.add(gene_name)

fn_genes = set()
for gene_id, v in diff_spliced_genes.items():
    if v == 1:
        gene_name = gene_id_name_dict[gene_id]
        fn_genes.add(gene_name)

print(len(tp_genes), len(fp_genes), len(fn_genes))
