# dict tran and fpkm
from collections import defaultdict
from scipy import stats
import matplotlib.pyplot as plt

import numpy as np


def get_introns(exons):
    if len(exons) <= 1:
        return []
    else:
        introns = []
        _list = sorted(exons)
        start = _list[0][1]
        for i in range(1, len(_list)):
            end = _list[i][0]
            introns.append((start, end))
            start = _list[i][1]
        return introns

######################
# gtf_file = '/Users/gyang/test/annotation.gtf'
gtf_file = '/ccb/salz3/gyang/simulation3/meta_info/annotation.gtf'
tran_exons_dict = defaultdict(list)
tran_chr_strand_dict = {}
with open(gtf_file, 'r') as f:
    for line in f:
        if line is not '\n':
            items = line.strip().split('\t')
            if items[2] == 'exon':
                _chr, strand = items[0], items[6]
                start, end = int(items[3]), int(items[4])
                _items = items[8].split('"')
                tran_id, gene_id = _items[3], _items[1]
                tran_exons_dict[tran_id].append((start, end))
                tran_chr_strand_dict[tran_id] = (_chr, strand)

intron_trans_dict = defaultdict(list)
for tran_id, exons in tran_exons_dict.items():
    introns = get_introns(exons)
    _chr, strand = tran_chr_strand_dict[tran_id]
    for intron in introns:
        intron_trans_dict[(_chr, strand, *intron)].append(tran_id)


######################
# gene_file = '/Users/gyang/test/genes_info.txt'
gene_file = '/ccb/salz3/gyang/simulation3/meta_info/genes_info.txt'
tran_fpkm_control_dict = {}
tran_fpkm_case_dict = {}
chosen_trans = set()
gene_fpkm_control_dict = defaultdict(lambda: 0)
gene_fpkm_case_dict = defaultdict(lambda: 0)
tran_gene_dict = {}

with open(gene_file, 'r') as f:
    for line in f:
        items = line.strip().split('\t')
        gene_id = items[0]
        bool1, bool2, bool3 = [b == 'True' for b in items[3: 6]]
        if bool1:
            for item in items[6].split(', ')[:2]:
                tran_id, fpkm = item.strip().split(':')
                chosen_trans.add(tran_id)

        for item in items[6].split(', '):
            tran_id, fpkm = item.strip().split(':')
            tran_fpkm_control_dict[tran_id] = float(fpkm)
            gene_fpkm_control_dict[gene_id] += float(fpkm)
            tran_gene_dict[tran_id] = gene_id

        for item in items[7].split(','):
            tran_id, fpkm = item.strip().split(':')
            tran_fpkm_case_dict[tran_id] = float(fpkm)
            gene_fpkm_case_dict[gene_id] += float(fpkm)


########################################################  LeafCutter  #####################################################
# base_dir = '/Users/gyang/test/leafcutter_star/'
base_dir = '/ccb/salz3/gyang/simulation3/LeafCutter/STMerged/'
file = base_dir + 'leafcutter_ds_cluster_significance.txt'
with open(file, 'r') as f:
    lines = f.readlines()

cluster_pvalue_dict = {}
for line in lines[1:]:
    cluster, status, _, _, p_value, _, _ = line.strip().split('\t')
    if status == 'Success':
        _chr, cluster_id = cluster.split(':')
        cluster_pvalue_dict[cluster_id] = float(p_value)

#######
file = base_dir + 'leafcutter_ds_effect_sizes.txt'
with open(file, 'r') as f:
    lines = f.readlines()

leafcutter_intron_dpsi_dict = {}
# leafcutter_intron_cluster_pvalue_dict = defaultdict(list)
for line in lines[1:]:
    # intron  logef   case    control deltapsi
    intron_info, _, _, _, dpsi = line.strip().split('\t')
    dpsi = float(dpsi)
    strand = 'NA'
    _chr, start, end, cluster_id = intron_info.split(':')
    start, end = int(start), int(end)
    # do this because the strand is not show in the file
    for strand in ['-', '+']:
        leafcutter_intron_dpsi_dict[(_chr, strand, start, end)] = dpsi
        # leafcutter_intron_cluster_pvalue_dict[(_chr, strand, start, end)] = cluster_pvalue_dict[cluster_id]


#################################### ALL ######################################
ref_intron_dpsis = []
leafcutter_intron_dpsis = []
for intron, trans in intron_trans_dict.items():
    # only consider the introns in common
    if intron not in leafcutter_intron_dpsi_dict:
        continue

    cntrl_sum = 0
    case_sum = 0
    for tran_id in trans:
        if tran_id in tran_fpkm_control_dict:
            cntrl_sum += tran_fpkm_control_dict[tran_id]

        if tran_id in tran_fpkm_case_dict:
            case_sum += tran_fpkm_case_dict[tran_id]

    # this works because a intron only belong to one gene in our annotation.
    gene_id = tran_gene_dict[tran_id]
    psi_cntrl = cntrl_sum / gene_fpkm_control_dict[gene_id]
    psi_case = case_sum / gene_fpkm_case_dict[gene_id]
    ref_intron_dpsis.append(psi_cntrl - psi_case)
    leafcutter_intron_dpsis.append(leafcutter_intron_dpsi_dict[intron])

print(np.corrcoef(ref_intron_dpsis, leafcutter_intron_dpsis))


#################################### DSR ######################################
ref_intron_dpsis = []
leafcutter_intron_dpsis = []
for intron, trans in intron_trans_dict.items():
    # only consider the introns in common
    if intron not in leafcutter_intron_dpsi_dict:
        continue

    cntrl_sum = 0
    case_sum = 0
    flag = False
    for tran_id in trans:
        if tran_id in chosen_trans:
            flag = True

        if tran_id in tran_fpkm_control_dict:
            cntrl_sum += tran_fpkm_control_dict[tran_id]

        if tran_id in tran_fpkm_case_dict:
            case_sum += tran_fpkm_case_dict[tran_id]

    if flag:
        gene_id = tran_gene_dict[tran_id]
        psi_cntrl = cntrl_sum / gene_fpkm_control_dict[gene_id]
        psi_case = case_sum / gene_fpkm_case_dict[gene_id]
        ref_intron_dpsis.append(psi_cntrl - psi_case)
        leafcutter_intron_dpsis.append(leafcutter_intron_dpsi_dict[intron])

print(np.corrcoef(ref_intron_dpsis, leafcutter_intron_dpsis))
