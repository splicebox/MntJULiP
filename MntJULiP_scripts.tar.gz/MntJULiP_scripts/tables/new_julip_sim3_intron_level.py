# dict tran and fpkm
from collections import defaultdict

import numpy as np


def get_introns(exons):
    if len(exons) <= 1:
        return []
    else:
        introns = []
        _list = sorted(exons)
        start = _list[0][1]
        for i in range(1, len(_list)):
            end = _list[i][0]
            introns.append((start, end))
            start = _list[i][1]
        return introns


# read exon info from the file.
tran_exons_dict = defaultdict(list)
gtf_file = '/Users/gyang/test/annotation.gtf'

gene_id_name_dict = {}
gene_name_id_dict = defaultdict(set)
tran_exons_dict = defaultdict(list)
with open(gtf_file, 'r') as f:
    for line in f:
        if line != '\n':
            items = line.strip().split('\t')
            if items[2] == 'exon':
                _chr, strand = items[0], items[6]
                start, end = items[3: 5]
                _items = items[8].split('"')
                tran_id, gene_id = _items[3], _items[1]
                gene_id, gene_name = _items[1], _items[9]
                tran_exons_dict[(_chr, strand, tran_id)].append((int(start), int(end)))
                gene_id_name_dict[gene_id] = gene_name
                gene_name_id_dict[gene_name].add(gene_id)

# get intron info
tran_introns_dict = defaultdict(list)
intron_trans_dict = defaultdict(list)
tran_info_dict = {}
for (_chr, strand, tran_id), exons in tran_exons_dict.items():
    tran_info_dict[tran_id] = (_chr, strand, tran_id)
    introns = get_introns(exons)
    for intron in introns:
        tran_introns_dict[(_chr, strand, tran_id)].append((_chr, strand, *intron))
        intron_trans_dict[(_chr, strand, *intron)].append(tran_id)


###############################################################################
gene_file = '/Users/gyang/test/genes_info.txt'
diff_present_introns = set()
diff_spliced_introns = set()

with open(gene_file, 'r') as f:
    for line in f:
        items = line.strip().split('\t')
        gene_id = items[0]
        bool1, bool2, bool3 = [b == 'True' for b in items[3: 6]]
        if bool1 and not(bool2) and not(bool3):  # DS
            for item in items[6].split(', ')[:2]:
                tran_id, fpkm = item.strip().split(':')
                diff_spliced_introns.update(tran_introns_dict[tran_info_dict[tran_id]])
                # diff_present_introns.update(tran_introns_dict[tran_info_dict[tran_id]])

        if not(bool1) and (bool2 or bool3):  # DE
            for item in items[6].split(', '):
                tran_id, fpkm = item.strip().split(':')
                diff_present_introns.update(tran_introns_dict[tran_info_dict[tran_id]])

        if bool1 and (bool2 or bool3):  # DE & DS
            for item in items[6].split(', ')[:2]:
                tran_id, fpkm = item.strip().split(':')
                diff_spliced_introns.update(tran_introns_dict[tran_info_dict[tran_id]])
                diff_present_introns.update(tran_introns_dict[tran_info_dict[tran_id]])

            for item in items[6].split(', '):
                tran_id, fpkm = item.strip().split(':')
                diff_present_introns.update(tran_introns_dict[tran_info_dict[tran_id]])


########################################################. JULIP  #######################################################
# base_dir = '/Users/gyang/test/simulation_3_out/'
base_dir = '/Users/gyang/test_mntjulip_out/'

file = base_dir + 'diff_spliced_groups.txt'
with open(file, 'r') as f:
    lines = f.readlines()

gene_dict = {}
group_p_values = {}
for line in lines[1:]:
    group_id, _chr, _, strand, gene_names_str, _, _, p_value, q_value = line.strip().split('\t')
    group_p_values[group_id] = float(p_value)

file = base_dir + 'diff_spliced_introns.txt'
with open(file, 'r') as f:
    lines = f.readlines()

pred_diff_spliced_introns_dict = {}
for line in lines[1:]:
    group_id, _chr, start, end, strand, _, _, _, dpsi = line.strip().split('\t')
    start, end, dpsi = int(start), int(end), float(dpsi)
    p_value = group_p_values[group_id]
    if p_value < 0.1 and dpsi > 0.05:
        pred_diff_spliced_introns_dict[(_chr, strand, start, end)] = 0
        if (_chr, strand, start, end) in diff_spliced_introns:
            pred_diff_spliced_introns_dict[(_chr, strand, start, end)] = 1

tp = sum(list(pred_diff_spliced_introns_dict.values()))
fp = len(pred_diff_spliced_introns_dict) - tp
fn = 0


## diff present
file = '/Users/gyang/test/simulation_3_out/gencode/diff_introns.txt'
with open(file, 'r') as f:
    lines = f.readlines()

pred_diff_present_introns_dict = {}
for line in lines[1:]:
    _chr, start, end, strand, gene_names_str, status, _, p_value, q_value, _, _ = line.strip().split('\t')
    if status == 'TEST':
        start, end, p_value = int(start), int(end), float(p_value)
        if p_value < 0.1:
            pred_diff_present_introns_dict[(_chr, strand, start, end)] = 0
            if (_chr, strand, start, end) in diff_present_introns:
                pred_diff_present_introns_dict[(_chr, strand, start, end)] = 1

tp = sum(list(pred_diff_present_introns_dict.values()))
fp = len(pred_diff_present_introns_dict) - tp
fn = len(diff_present_introns) - tp
