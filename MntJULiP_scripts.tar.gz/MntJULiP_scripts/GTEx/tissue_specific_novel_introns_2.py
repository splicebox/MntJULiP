# from scipy import stats
import numpy as np
from collections import defaultdict
import pickle
import rpy2.robjects.numpy2ri
from rpy2.robjects.packages import importr
rpy2.robjects.numpy2ri.activate()


intron_samples_dict = pickle.load(open('/Users/gyang/Desktop/intron_samples_dict.pkl', 'rb'))

intron_matrix_dict = {}
intron_cutoff = 0.9
for intron, result in intron_samples_dict.items():
    intron_matrix_dict[intron] = defaultdict(list)
    for key, counts in result.items():
        for count in counts:
            val = 1 if count > intron_cutoff else 0
            intron_matrix_dict[intron][key].append(val)

stats = importr('stats')
# kwargs = {'simulate.p.value': 'TRUE'}
# hybridPars = {'expect':5, 'percent': 80, 'Emin':1}
kwargs = {'simulate.p.value': True}#, 'B': 1e4}

tested_introns = []
sum_array = np.array([80, 262, 357, 349, 102, 102,  75,  71])
# scale = 100 / sum_array
# the gtex data has 1398 samples, 8 merged tissue types
for intron, value_dict in intron_matrix_dict.items():
    result = [[0] * 2 for _ in range(8)]
    for key, vals in value_dict.items():
        for val in vals:
            result[key][val] += 1
    result = np.array(result).T
    result[1] = sum_array - result[0]
    # result2 = result * scale
    res = stats.chisq_test(result.T, **kwargs)
    pvalue = res[2][0]
    # res = stats.fisher_test(result2.T, **kwargs)
    # print(res[0][0])
    # res = stats.chisq_test(np.array(result), **kwargs)
    if pvalue < 0.01:
        tested_introns.append((intron, pvalue))

print(len(tested_introns))

