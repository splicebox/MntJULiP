module load samtools
BASE_DIR='/scratch/groups/lflorea1/projects/MntJulip/Star/Cerebellum'


JUNC=/scratch/groups/lflorea1/Guangyu/new_julip/bin/junc

mkdir -p ${BASE_DIR}/SPLICEs

i=0
n=20

for name in `cat name_list.txt`
do
    $JUNC BAMs/star_${name}_Aligned.sortedByCoord.out.bam > SPLICEs/star_${name}_Aligned.sortedByCoord.out.splice &
    i=$(($i+1))
    if [ $i -eq $n ]; then
        wait
        i=0
    fi
done
wait


for name in SRR598009 SRR598396 SRR820468
do
    rm -rf *_${name}_*
done

less star_SRR598009_Log.final.out
