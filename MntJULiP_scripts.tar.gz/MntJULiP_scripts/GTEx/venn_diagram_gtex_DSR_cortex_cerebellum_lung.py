# Venn Diagram for cortex_cerebellum', 'cortex_lung', 'cerebellum_lung'


from collections import defaultdict
import numpy as np
import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt


def get_abs_max_dpsi(psi_list):
    abs_max_dpsi = 0
    for i, psi1 in enumerate(psi_list):
        for psi2 in psi_list[i + 1:]:
            if abs(psi1 - psi2) > abs_max_dpsi:
                abs_max_dpsi = abs(psi1 - psi2)
    return abs_max_dpsi


folder = '/Users/gyang/Desktop/gtex'

gene_names_list = []
for test_name in ['cortex_cerebellum', 'cortex_lung', 'cerebellum_lung']:
    subfolder = f'{folder}/{test_name}_out/'

    # file = subfolder + 'diff_introns.txt'
    # with open(file, 'r') as f:
    #     lines = f.readlines()

    # gene_dict = defaultdict(lambda: np.zeros(2))
    # for line in lines[1:]:
    #     items = line.strip().split('\t')
    #     _chr, start, end, strand, gene_names_str, status, _, p_value, q_value = items[:9]
    #     if status == 'TEST' and gene_names_str != '.':
    #         start, end, p_value, q_value = int(start), int(end), float(p_value), float(q_value)
    #         means = np.array([float(m) for m in items[9:]])
    #         for name in gene_names_str.split(','):
    #             gene_dict[name] = gene_dict[name] + means

    # gene_set = set()
    # for name, means in gene_dict.items():
    #     if np.any(gene_dict[name] > 30):
    #         gene_set.add(name)

    ##########
    file = subfolder + 'diff_spliced_groups.txt'
    with open(file, 'r') as f:
        lines = f.readlines()

    group_set = set()
    group_genes_dict = defaultdict(list)
    for line in lines[1:]:
        group_id, _chr, _, strand, gene_names_str, _, _, p_value, q_value = line.strip().split('\t')
        p_value, q_value = float(p_value), float(q_value)
        if gene_names_str != '.' and len(gene_names_str.split(',')) == 1:
            gene_name = gene_names_str.split(',')[0]
            # if gene_name in gene_set and q_value < 0.05:  ##################
            if p_value < 0.05:
                group_set.add(group_id)
                group_genes_dict[group_id].append(gene_name)

    ##########
    file = subfolder + 'diff_spliced_introns.txt'
    with open(file, 'r') as f:
        lines = f.readlines()


    group_introns_dict = defaultdict(list)
    group_sig_introns_dict = defaultdict(list)
    intron_set = set()
    for line in lines[1:]:
        items = line.strip().split('\t')
        group_id, _chr, start, end, strand, gene_names_st = items[:6]
        start, end = int(start), int(end)
        psi_list = [float(psi) for psi in items[6:-1]]
        if group_id in group_set:
            group_introns_dict[group_id].append((_chr, strand, start, end))
            abs_max_dpsi = get_abs_max_dpsi(psi_list)
            if abs_max_dpsi > 0.05:  ##################
                group_sig_introns_dict[group_id].append((_chr, strand, start, end))
                intron_set.add((_chr, strand, start, end))

    selected_genes = set()
    for group_id in group_sig_introns_dict.keys():
        selected_genes.update(group_genes_dict[group_id])

    print(f"{test_name} :{len(intron_set)} introns, {len(selected_genes)} genes")
    gene_names_list.append(list(selected_genes))


###############################################################################
folder = '/Users/gyang/Desktop/gtex/cortex_cerebellum_lung_out/'
# file = folder + 'diff_introns.txt'
# with open(file, 'r') as f:
#     lines = f.readlines()

# gene_dict = defaultdict(lambda: np.zeros(3))
# for line in lines[1:]:
#     items = line.strip().split('\t')
#     _chr, start, end, strand, gene_names_str, status, _, p_value, q_value = items[:9]
#     if status == 'TEST' and gene_names_str != '.':
#         start, end, p_value, q_value = int(start), int(end), float(p_value), float(q_value)
#         means = np.array([float(m) for m in items[9:]])
#         for name in gene_names_str.split(','):
#             gene_dict[name] = gene_dict[name] + means

# gene_set = set()
# for name, means in gene_dict.items():
#     if np.any(gene_dict[name] > 30):
#         gene_set.add(name)

##########
file = folder + 'diff_spliced_groups.txt'
with open(file, 'r') as f:
    lines = f.readlines()

group_set = set()
group_genes_dict = defaultdict(list)
for line in lines[1:]:
    group_id, _chr, _, strand, gene_names_str, _, _, p_value, q_value = line.strip().split('\t')
    p_value, q_value = float(p_value), float(q_value)
    if gene_names_str != '.' and len(gene_names_str.split(',')) == 1:
        gene_name = gene_names_str.split(',')[0]
        # if gene_name in gene_set and q_value < 0.05:  ##################
        if p_value < 0.05:
            group_set.add(group_id)
            group_genes_dict[group_id].append(gene_name)

##########
file = folder + 'diff_spliced_introns.txt'
with open(file, 'r') as f:
    lines = f.readlines()


group_introns_dict = defaultdict(list)
group_sig_introns_dict = defaultdict(list)
intron_set = set()
for line in lines[1:]:
    items = line.strip().split('\t')
    group_id, _chr, start, end, strand, gene_names_st = items[:6]
    start, end = int(start), int(end)
    psi_list = [float(psi) for psi in items[6:]]
    if group_id in group_set:
        group_introns_dict[group_id].append((_chr, strand, start, end))
        abs_max_dpsi = get_abs_max_dpsi(psi_list)
        if abs_max_dpsi > 0.05:  ##################
            group_sig_introns_dict[group_id].append((_chr, strand, start, end))
            intron_set.add((_chr, strand, start, end))

selected_genes = set()
for group_id in group_sig_introns_dict.keys():
    selected_genes.update(group_genes_dict[group_id])

print(f"cortex_cerebellum_lung :{len(intron_set)} introns, {len(selected_genes)} genes")
gene_names_list.append(list(selected_genes))


###############################################################################
import venn
import matplotlib.pyplot as plt

labels = venn.get_labels(gene_names_list, fill=['number'])
fig, ax = venn.venn4(labels, names=['cortex_cerebellum', 'cortex_lung', 'cerebellum_lung', 'cortex_cerebellum_lung'])
fig.savefig('/Users/gyang/OneDrive/1-Florea Lab/New_JULiP_Paper/GTEx_heatmaps/gtex_venn4_DSR_cortex_cerebellum_lung_p_value.png')
plt.close()

a = gene_names_list
print(set(a[3]).difference(set(a[0]).union(a[1]).union(a[2])))
