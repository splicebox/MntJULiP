# from scipy import stats
import numpy as np
from collections import defaultdict
import pickle
from scipy import stats


intron_samples_dict = pickle.load(open('/Users/gyang/Desktop/intron_samples_dict.pkl', 'rb'))

intron_matrix_dict = {}
intron_cutoff = 0.9
for intron, result in intron_samples_dict.items():
    intron_matrix_dict[intron] = defaultdict(list)
    for key, counts in result.items():
        for count in counts:
            val = 1 if count > intron_cutoff else 0
            intron_matrix_dict[intron][key].append(val)


# do the test
tested_introns = []
sum_array = [80, 262, 357, 349, 102, 102,  75,  71]
ratio = 0.85
intron_pvalue_dict = {}
# scale = 100 / sum_array
# the gtex data has 1398 samples, 8 merged tissue types
for intron, value_dict in intron_matrix_dict.items():
    result = [[0] * 2 for _ in range(8)]
    for key, vals in value_dict.items():
        for val in vals:
            result[key][val] += 1
    statistic = count = 0
    for i in range(len(result)):
        exp = sum_array[i] * ratio
        obs = sum_array[i] - result[i][1]
        if obs >= exp:
            count += 1
            statistic += (obs - exp) ** 2 / exp

    if statistic == 0 or count == 0:
        continue
    df = 1 if count == 1 else count - 1
    pvalue = 1 - stats.chi2.cdf(statistic, df)
    tested_introns.append((intron, pvalue))
    intron_pvalue_dict[intron] = pvalue

print(min(tested_introns, key=lambda x: x[1]))
significant_intron_pairs = []
significant_introns = []
for intron, pvalue in sorted(tested_introns, key=lambda x:x[1]):
    if pvalue < 0.01:
        significant_intron_pairs.append((intron, pvalue))
        significant_introns.append(intron)


index_name_dict = {0: 'amygdala',
                   1: 'Cerebellum',
                   2: 'basal_ganglia',
                   3: 'cortex',
                   4: 'hippocampus',
                   5: 'Hypothalamus',
                   6: 'Spinal_cord_cervical_c1',
                   7: 'Substantia_nigra'}

# for those significant introns, determine which tissue they are expressed
intron_tissues_dict = defaultdict(set)
for intron in sorted(significant_introns, key=lambda x: x[1]):
    result = [[0] * 2 for _ in range(8)]
    for key, vals in intron_matrix_dict[intron].items():
        for val in vals:
            result[key][val] += 1
    for i in range(8):
        if result[i][1] > (sum_array[i] * 0.15):
            intron_tissues_dict[intron].add(index_name_dict[i])

with open('/Users/gyang/Desktop/novel_introns_tissues.txt', 'w') as f:
    for intron, tissues in intron_tissues_dict.items():
        f.write(f'{intron}\t{tissues}\n')
