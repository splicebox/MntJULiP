# srun -N 1 --exclusive -p parallel -t 12:0:0 --pty /bin/bash

cd ~/MntJULiP
module load gcc/6.4.0.lua

## brain all: cortex, cerebellum, frontalcortex
BASE_DIR="/home-2/gyang22@jhu.edu/work/projects/MntJulip"
WORK_DIR="${BASE_DIR}/MntJulip_out"

# module load python/3.7.lua

/software/apps/python/3.7/bin/python3 run.py --out-dir ${WORK_DIR} \
               --splice-list ${BASE_DIR}/GTEx.brain.splice.txt \
               --num-threads 23 \
               --min-count 5\
               --batch-size 2000 \
               --anno-file ${BASE_DIR}/gencode.v22.annotation.gtf

## cortex vs cerebellum
BASE_DIR="/home-2/gyang22@jhu.edu/work/projects/MntJulip"
WORK_DIR="${BASE_DIR}/cortex_cerebellum_out"

# module load python/3.7.lua

/software/apps/python/3.7/bin/python3 run.py --out-dir ${WORK_DIR} \
               --splice-list ${BASE_DIR}/cortex_cerebellum.splice.txt \
               --num-threads 23 \
               --min-count 5\
               --batch-size 2000 \
               --anno-file ${BASE_DIR}/gencode.v22.annotation.gtf


## cortex vs frontalcortex
BASE_DIR="/home-2/gyang22@jhu.edu/work/projects/MntJulip"
WORK_DIR="${BASE_DIR}/cortex_frontalcortex_out"

/software/apps/python/3.7/bin/python3 run.py --out-dir ${WORK_DIR} \
               --splice-list ${BASE_DIR}/cortex_frontalcortex.splice.txt \
               --num-threads 23 \
               --min-count 5\
               --batch-size 2000 \
               --anno-file ${BASE_DIR}/gencode.v22.annotation.gtf


## cortex vs lung
BASE_DIR="/home-2/gyang22@jhu.edu/work/projects/MntJulip"
WORK_DIR="${BASE_DIR}/cortex_lung_out"

/software/apps/python/3.7/bin/python3 run.py --out-dir ${WORK_DIR} \
               --splice-list ${BASE_DIR}/cortex_lung.splice.txt \
               --num-threads 23 \
               --min-count 5\
               --batch-size 2000 \
               --anno-file ${BASE_DIR}/gencode.v22.annotation.gtf


## frontalcortex vs cerebellum
BASE_DIR="/home-2/gyang22@jhu.edu/work/projects/MntJulip"
WORK_DIR="${BASE_DIR}/frontalcortex_cerebellum_out"

/software/apps/python/3.7/bin/python3 run.py --out-dir ${WORK_DIR} \
               --splice-list ${BASE_DIR}/frontalcortex_cerebellum.splice.txt \
               --num-threads 23 \
               --min-count 5\
               --batch-size 2000 \
               --anno-file ${BASE_DIR}/gencode.v22.annotation.gtf


## cerebellum vs lung
BASE_DIR="/home-2/gyang22@jhu.edu/work/projects/MntJulip"
WORK_DIR="${BASE_DIR}/cerebellum_lung_out"

/software/apps/python/3.7/bin/python3 run.py --out-dir ${WORK_DIR} \
               --splice-list ${BASE_DIR}/cerebellum_lung.splice.txt \
               --num-threads 23 \
               --min-count 5\
               --batch-size 2000 \
               --anno-file ${BASE_DIR}/gencode.v22.annotation.gtf


## cortex, cerebellum, lung
BASE_DIR="/home-2/gyang22@jhu.edu/work/projects/MntJulip"
WORK_DIR="${BASE_DIR}/cortex_cerebellum_lung_out"

/software/apps/python/3.7/bin/python3 run.py --out-dir ${WORK_DIR} \
               --splice-list ${BASE_DIR}/GTEx.cortex_cerebellum_lung.splice.txt \
               --num-threads 23 \
               --min-count 5\
               --batch-size 2000 \
               --anno-file ${BASE_DIR}/gencode.v22.annotation.gtf
