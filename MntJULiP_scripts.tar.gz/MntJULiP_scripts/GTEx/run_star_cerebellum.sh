## load necessary modules
module load star/2.4.2a
#module load bowtie2/2.2.5
module load samtools/1.9

## tophat script
DATADIR=/home-2/gyang22@jhu.edu/work/projects/MntJulip/Star/Cerebellum
WORKDIR=/scratch/groups/lflorea1/projects/MntJulip/Star/Cerebellum/BAMs
STAR2IDX=/scratch/groups/lflorea1/shared/genomes/hg38/star

mkdir -p ${WORKDIR}
cd ${WORKDIR}

core=23

for i in `cat ../name_list.txt`
do
    STAR --runThreadN ${core} \
         --genomeDir $STAR2IDX/ \
         --readFilesIn ${DATADIR}/${i}_1.fastq.gz ${DATADIR}/${i}_2.fastq.gz \
         --readFilesCommand zcat \
         --outSAMtype BAM SortedByCoordinate \
         --outSAMstrandField intronMotif \
         --outFileNamePrefix star_${i}_
done



# core=23

# for i in SRR1086680 SRR1093527 SRR1307770 SRR1311771 SRR1314187 SRR1318407 SRR1319672 SRR1320093 SRR1322010 SRR1322163 SRR1322291 SRR1324452 SRR1330041 SRR1331841 SRR1331944 SRR1335377 SRR1335856 SRR1337119 SRR1338669 SRR1340095 SRR1348021 SRR1348770 SRR1350107 SRR1352129 SRR1352415 SRR1356204 SRR1357413 SRR1359367 SRR1361714 SRR1361736 SRR1362183 SRR5125409 SRR5125410 SRR5125541 SRR5125542 SRR598009 SRR598396 SRR600876 SRR607967 SRR612419 SRR613270 SRR613366 SRR614383 SRR615249 SRR627299 SRR627429 SRR627433 SRR627453 SRR627462 SRR657325 SRR657915 SRR657997 SRR658813 SRR659331 SRR659412 SRR662871 SRR663453 SRR663681 SRR807657 SRR810957 SRR814563 SRR815232 SRR816292 SRR817258 SRR82046
# do
#     STAR --runThreadN ${core} \
#          --genomeDir $STAR2IDX/ \
#          --readFilesIn ${DATADIR}/${i}_1.fastq.gz ${DATADIR}/${i}_2.fastq.gz \
#          --readFilesCommand zcat \
#          --outSAMtype BAM SortedByCoordinate \
#          --outSAMstrandField intronMotif \
#          --outFileNamePrefix star_${i}_
# done


# fastq files that contain error SRR598009 SRR598396
