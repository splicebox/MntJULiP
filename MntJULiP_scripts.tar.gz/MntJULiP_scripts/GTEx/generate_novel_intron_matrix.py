# 12-20-2020, works with generate_data_12.py
import gzip
from collections import defaultdict
from pathlib import Path
import pandas as pd


def get_introns(exons):
    if len(exons) <= 1:
        return []
    else:
        introns = []
        _list = sorted(exons)
        start = _list[0][1]
        for i in range(1, len(_list)):
            end = _list[i][0]
            introns.append((start, end))
            start = _list[i][1]
        return introns


tran_exons_dict = defaultdict(list)
tran_genes_dict = {}
gtf_file = '/ccb/salz3/gyang/gencode.v36.annotation.gtf.gz'
with gzip.open(gtf_file, 'rb') as f:
    for line in f:
        line = line.decode('UTF-8')
        if line != '\n' and not line.startswith('#'):
            items = line.strip().split('\t')
            if items[2] == 'exon':
                _chr, strand = items[0], items[6]
                start, end = items[3: 5]
                tags = items[8]
                tag_dict = dict(kv.strip().split(" ") for kv in tags.strip(";").split("; "))
                tran_id, gene_name = tag_dict['transcript_id'][1:-1], tag_dict['gene_name'][1:-1]
                tran_exons_dict[(_chr, strand, tran_id)].append((int(start), int(end)))
                tran_genes_dict[tran_id] = gene_name

gencode_intron_set = set()
for (_chr, strand, tran_id), exons in tran_exons_dict.items():
    gene_name = tran_genes_dict[tran_id]
    for start, end in get_introns(exons):
        gencode_intron_set.add((_chr, strand, start, end))

###################
folders = ['Amygdala_Anterior_cingulate_cortex_BA24', 'Amygdala_Caudate_basal_ganglia', 'Amygdala_Cerebellar_hemisphere', 'Amygdala_Cerebellum', 'Amygdala_Cortex', 'Amygdala_Frontal_cortex', 'Amygdala_Hippocampus', 'Amygdala_Hypothalamus', 'Amygdala_Nucleus_accumbens_basal_ganglia', 'Amygdala_Putamen_basal_ganglia', 'Amygdala_Spinal_cord_cervical_c1', 'Amygdala_Substantia_nigra', 'Caudate_basal_ganglia_Anterior_cingulate_cortex_BA24', 'Caudate_basal_ganglia_Cerebellar_hemisphere', 'Caudate_basal_ganglia_Cerebellum', 'Caudate_basal_ganglia_Cortex', 'Caudate_basal_ganglia_Frontal_cortex', 'Caudate_basal_ganglia_Hippocampus', 'Caudate_basal_ganglia_Hypothalamus', 'Caudate_basal_ganglia_Nucleus_accumbens_basal_ganglia', 'Caudate_basal_ganglia_Putamen_basal_ganglia', 'Caudate_basal_ganglia_Spinal_cord_cervical_c1', 'Caudate_basal_ganglia_Substantia_nigra', 'Cerebellar_hemisphere_Anterior_cingulate_cortex_BA24', 'Cerebellar_hemisphere_Cerebellum', 'Cerebellar_hemisphere_Cortex', 'Cerebellar_hemisphere_Frontal_cortex', 'Cerebellar_hemisphere_Hippocampus', 'Cerebellar_hemisphere_Hypothalamus', 'Cerebellar_hemisphere_Nucleus_accumbens_basal_ganglia', 'Cerebellar_hemisphere_Putamen_basal_ganglia', 'Cerebellar_hemisphere_Spinal_cord_cervical_c1', 'Cerebellar_hemisphere_Substantia_nigra', 'Cerebellum_Anterior_cingulate_cortex_BA24', 'Cerebellum_Cortex', 'Cerebellum_Frontal_cortex', 'Cerebellum_Hippocampus', 'Cerebellum_Hypothalamus', 'Cerebellum_Nucleus_accumbens_basal_ganglia', 'Cerebellum_Putamen_basal_ganglia', 'Cerebellum_Spinal_cord_cervical_c1', 'Cerebellum_Substantia_nigra', 'Cortex_Anterior_cingulate_cortex_BA24', 'Frontal_cortex_Anterior_cingulate_cortex_BA24', 'Frontal_cortex_Cortex', 'Hippocampus_Anterior_cingulate_cortex_BA24', 'Hippocampus_Cortex', 'Hippocampus_Frontal_cortex', 'Hippocampus_Hypothalamus', 'Hippocampus_Nucleus_accumbens_basal_ganglia', 'Hippocampus_Putamen_basal_ganglia', 'Hippocampus_Spinal_cord_cervical_c1', 'Hippocampus_Substantia_nigra', 'Hypothalamus_Anterior_cingulate_cortex_BA24', 'Hypothalamus_Cortex', 'Hypothalamus_Frontal_cortex', 'Hypothalamus_Nucleus_accumbens_basal_ganglia', 'Hypothalamus_Putamen_basal_ganglia', 'Hypothalamus_Spinal_cord_cervical_c1', 'Hypothalamus_Substantia_nigra', 'Nucleus_accumbens_basal_ganglia_Anterior_cingulate_cortex_BA24', 'Nucleus_accumbens_basal_ganglia_Cortex', 'Nucleus_accumbens_basal_ganglia_Frontal_cortex', 'Nucleus_accumbens_basal_ganglia_Putamen_basal_ganglia', 'Nucleus_accumbens_basal_ganglia_Spinal_cord_cervical_c1', 'Nucleus_accumbens_basal_ganglia_Substantia_nigra', 'Putamen_basal_ganglia_Anterior_cingulate_cortex_BA24', 'Putamen_basal_ganglia_Cortex', 'Putamen_basal_ganglia_Frontal_cortex', 'Putamen_basal_ganglia_Spinal_cord_cervical_c1', 'Putamen_basal_ganglia_Substantia_nigra', 'Spinal_cord_cervical_c1_Anterior_cingulate_cortex_BA24', 'Spinal_cord_cervical_c1_Cortex', 'Spinal_cord_cervical_c1_Frontal_cortex', 'Spinal_cord_cervical_c1_Substantia_nigra', 'Substantia_nigra_Anterior_cingulate_cortex_BA24', 'Substantia_nigra_Cortex', 'Substantia_nigra_Frontal_cortex']
chr_names = ['chr{}'.format(i) for i in range(1, 23)] + ['chrX', 'chrY']

mntjulip_intron_set = set()
mntjulip_intron_dict = defaultdict(list)
base_dir = Path('/ccb/salz3/gyang/brain_GTEx/MntJULiP/')
for folder in folders:
    file = base_dir / folder / 'diff_introns.txt'
    with open(file, 'r') as f:
        lines = f.readlines()

    cond1, cond2 = lines[0].strip().split()[-2:]
    cond1, cond2 = cond1[16:-1], cond2[16:-1]
    genes = set()

    for line in lines[1:]:
        items = line.strip().split('\t')
        _chr, start, end, strand, gene_name, status, _, p_value, q_value, count1, count2 = items
        if status == 'TEST' and _chr in chr_names:
            start, end = int(start), int(end)
            mntjulip_intron_set.add((_chr, strand, start, end))
            mntjulip_intron_dict[(_chr, strand, start, end)] += [cond1, cond2]

result = defaultdict(dict)
for intron in mntjulip_intron_set - gencode_intron_set:
    for cond in mntjulip_intron_dict[intron]:
        result[intron][cond] = 1

data_df = pd.DataFrame.from_dict(result)
data_df = data_df.T.fillna(0).astype(int)
data_df.to_csv('/ccb/salz3/gyang/brain_GTEx/MntJULiP/novel_intron_matrix.txt', sep='\t')


