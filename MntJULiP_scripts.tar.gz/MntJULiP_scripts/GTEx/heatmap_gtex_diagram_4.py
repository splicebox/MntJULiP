# for pair-wise comparison (cortex_cerebellum', 'cortex_frontalcortex', 'cortex_lung', 'frontalcortex_cerebellum)

from collections import defaultdict
import numpy as np
import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt


folder = '/Users/gyang/Desktop/gtex'
out_dir = '/Users/gyang/Desktop/GTEx_heatmaps'
for test_name in ['cortex_cerebellum', 'cortex_lung', 'cerebellum_lung']:
    subfolder = f'{folder}/{test_name}_out/'

    file = subfolder + 'diff_introns.txt'
    with open(file, 'r') as f:
        lines = f.readlines()

    gene_dict = defaultdict(lambda: np.zeros(2))
    for line in lines[1:]:
        items = line.strip().split('\t')
        _chr, start, end, strand, gene_names_str, status, _, p_value, q_value = items[:9]
        if status == 'TEST' and gene_names_str != '.':
            start, end, p_value, q_value = int(start), int(end), float(p_value), float(q_value)
            means = np.array([float(m) for m in items[9:]])
            for name in gene_names_str.split(','):
                gene_dict[name] = gene_dict[name] + means

    gene_set = set()
    for name, means in gene_dict.items():
        if np.any(gene_dict[name] > 30):
            gene_set.add(name)

    ##########
    file = subfolder + 'diff_spliced_groups.txt'
    with open(file, 'r') as f:
        lines = f.readlines()

    group_set = set()
    group_genes_dict = defaultdict(list)
    for line in lines[1:]:
        group_id, _chr, _, strand, gene_names_str, _, _, p_value, q_value = line.strip().split('\t')
        p_value, q_value = float(p_value), float(q_value)
        if gene_names_str != '.' and len(gene_names_str.split(',')) == 1:
            gene_name = gene_names_str.split(',')[0]
            if gene_name in gene_set and q_value < 0.05:
                group_set.add(group_id)
                group_genes_dict[group_id].append(gene_name)

    ##########
    file = subfolder + 'diff_spliced_introns.txt'
    with open(file, 'r') as f:
        lines = f.readlines()


    def get_abs_max_dpsi(psi_list):
        abs_max_dpsi = 0
        for i, psi1 in enumerate(psi_list):
            for psi2 in psi_list[i + 1:]:
                if abs(psi1 - psi2) > abs_max_dpsi:
                    abs_max_dpsi = abs(psi1 - psi2)
        return abs_max_dpsi


    group_introns_dict = defaultdict(list)
    group_sig_introns_dict = defaultdict(list)
    intron_set = set()
    for line in lines[1:]:
        items = line.strip().split('\t')
        group_id, _chr, start, end, strand, gene_names_st = items[:6]
        start, end = int(start), int(end)
        psi_list = [float(psi) for psi in items[6:-1]]
        if group_id in group_set:
            group_introns_dict[group_id].append((_chr, strand, start, end))
            abs_max_dpsi = get_abs_max_dpsi(psi_list)
            if abs_max_dpsi > 0.2:  ##################
                group_sig_introns_dict[group_id].append((_chr, strand, start, end))
                intron_set.add((_chr, strand, start, end))

    selected_genes = set()
    for group_id in group_sig_introns_dict.keys():
        selected_genes.update(group_genes_dict[group_id])

    print(f"{test_name} :{len(intron_set)} introns, {len(selected_genes)} genes")


    ##########
    file = subfolder + 'intron_data.txt'
    with open(file, 'r') as f:
        lines = f.readlines()

    intron_counts_dict = {}
    for line in lines[1:]:
        items = line.strip().split('\t')
        _chr, start, end, strand, gene_names_str, status = items[:6]
        if status == "OK":
            counts = []
            for cond_counts in items[6:]:
                for count in cond_counts.split(','):
                    counts.append(int(count))
            intron_counts_dict[(_chr, strand, int(start), int(end))] = counts

    ##########
    columns = []
    vlines = []
    # col_colors = []
    xticks = []
    for _str, cond_counts in zip(lines[0].strip().split('\t')[6:], items[6:]):
        name = _str[12:-1]
        columns += [name] * len(cond_counts.split(','))
        labels = [''] * len(cond_counts.split(','))
        labels[len(cond_counts.split(','))//2] = name
        xticks += labels
        # col_colors += [subtype_color_dict[name]] * len(cond_counts.split(','))

        if vlines:
            vlines.append(vlines[-1] + len(cond_counts.split(',')))
        else:
            vlines.append(len(cond_counts.split(',')))

    intron_counts_df = pd.DataFrame.from_dict(intron_counts_dict, orient='index', columns=columns)

    psis_list = []
    for group_id, intron_list in group_introns_dict.items():
        if group_id not in group_sig_introns_dict:
            continue
        sums = intron_counts_df.loc[intron_list].sum(axis = 0).values
        for index, row in intron_counts_df.loc[group_sig_introns_dict[group_id]].iterrows():
            values = row.values
            psis = values / sums
            psis_list.append(psis.tolist())


    psis_array = pd.DataFrame(np.asarray(psis_list), columns=columns)
    mask = psis_array.isnull()

    ax = sns.heatmap(psis_array, linewidth=0, yticklabels=False, xticklabels=xticks, cmap='YlOrBr', mask=mask)

    # for tick_label, color in zip(ax.get_xticklabels(), col_colors):
    #     tick_label.set_backgroundcolor(color)

    ax.vlines(vlines[:-1], *ax.get_ylim())
    file =  f'{out_dir}/{test_name}_heatmap.png'
    figure = ax.get_figure()
    figure.savefig(file)

    plt.close()
