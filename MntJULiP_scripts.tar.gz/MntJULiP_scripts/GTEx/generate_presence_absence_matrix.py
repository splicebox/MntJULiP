# 12-20-2020, works with generate_data_12.py
import gzip
from collections import defaultdict
from pathlib import Path
import pandas as pd
from scipy import stats
import pickle


def get_introns(exons):
    if len(exons) <= 1:
        return []
    else:
        introns = []
        _list = sorted(exons)
        start = _list[0][1]
        for i in range(1, len(_list)):
            end = _list[i][0]
            introns.append((start, end))
            start = _list[i][1]
        return introns


tran_exons_dict = defaultdict(list)
tran_genes_dict = {}
gtf_file = '/home-2/gyang22@jhu.edu/work/Guangyu/gencode.v36.annotation.gtf'
with open(gtf_file, 'rb') as f:
    for line in f:
        line = line.decode('UTF-8')
        if line != '\n' and not line.startswith('#'):
            items = line.strip().split('\t')
            if items[2] == 'exon':
                _chr, strand = items[0], items[6]
                start, end = items[3: 5]
                tags = items[8]
                tag_dict = dict(kv.strip().split(" ") for kv in tags.strip(";").split("; "))
                tran_id, gene_name = tag_dict['transcript_id'][1:-1], tag_dict['gene_name'][1:-1]
                tran_exons_dict[(_chr, strand, tran_id)].append((int(start), int(end)))
                tran_genes_dict[tran_id] = gene_name

###############################
# extract introns from gencode annotation
gencode_intron_set = set()
for (_chr, strand, tran_id), exons in tran_exons_dict.items():
    gene_name = tran_genes_dict[tran_id]
    for start, end in get_introns(exons):
        gencode_intron_set.add((_chr, strand, start, end))

###################
folders = ['Amygdala_Cortex', 'Amygdala_Cerebellum', 'Amygdala_Cerebellar_hemisphere', 'Amygdala_Caudate_basal_ganglia', 'Amygdala_Anterior_cingulate_cortex_BA24', 'Spinal_cord_cervical_c1_Substantia_nigra', 'Putamen_basal_ganglia_Substantia_nigra', 'Putamen_basal_ganglia_Spinal_cord_cervical_c1', 'Nucleus_accumbens_basal_ganglia_Substantia_nigra', 'Nucleus_accumbens_basal_ganglia_Spinal_cord_cervical_c1', 'Nucleus_accumbens_basal_ganglia_Putamen_basal_ganglia', 'Hypothalamus_Substantia_nigra', 'Hypothalamus_Spinal_cord_cervical_c1', 'Hypothalamus_Putamen_basal_ganglia', 'Hypothalamus_Nucleus_accumbens_basal_ganglia', 'Hippocampus_Substantia_nigra', 'Hippocampus_Spinal_cord_cervical_c1', 'Hippocampus_Putamen_basal_ganglia', 'Hippocampus_Nucleus_accumbens_basal_ganglia', 'Hippocampus_Hypothalamus', 'Cortex_Substantia_nigra', 'Cortex_Spinal_cord_cervical_c1', 'Cortex_Putamen_basal_ganglia', 'Cortex_Nucleus_accumbens_basal_ganglia', 'Cortex_Hypothalamus', 'Cortex_Hippocampus', 'Cerebellum_Substantia_nigra', 'Cerebellum_Spinal_cord_cervical_c1', 'Cerebellum_Putamen_basal_ganglia', 'Cerebellum_Hippocampus', 'Cerebellar_hemisphere_Substantia_nigra', 'Cerebellar_hemisphere_Spinal_cord_cervical_c1', 'Cerebellar_hemisphere_Putamen_basal_ganglia', 'Cerebellar_hemisphere_Hypothalamus', 'Cerebellar_hemisphere_Hippocampus', 'Caudate_basal_ganglia_Substantia_nigra', 'Caudate_basal_ganglia_Spinal_cord_cervical_c1', 'Caudate_basal_ganglia_Putamen_basal_ganglia', 'Caudate_basal_ganglia_Nucleus_accumbens_basal_ganglia', 'Caudate_basal_ganglia_Hypothalamus', 'Caudate_basal_ganglia_Hippocampus', 'Caudate_basal_ganglia_Cortex', 'Anterior_cingulate_cortex_BA24_Substantia_nigra', 'Anterior_cingulate_cortex_BA24_Spinal_cord_cervical_c1', 'Anterior_cingulate_cortex_BA24_Putamen_basal_ganglia', 'Anterior_cingulate_cortex_BA24_Nucleus_accumbens_basal_ganglia', 'Anterior_cingulate_cortex_BA24_Hypothalamus', 'Anterior_cingulate_cortex_BA24_Hippocampus', 'Anterior_cingulate_cortex_BA24_Cortex', 'Anterior_cingulate_cortex_BA24_Cerebellar_hemisphere', 'Anterior_cingulate_cortex_BA24_Caudate_basal_ganglia', 'Amygdala_Substantia_nigra', 'Amygdala_Spinal_cord_cervical_c1', 'Amygdala_Putamen_basal_ganglia', 'Amygdala_Nucleus_accumbens_basal_ganglia', 'Amygdala_Hypothalamus', 'Amygdala_Hippocampus', 'Amygdala_Frontal_cortex', 'Anterior_cingulate_cortex_BA24_Frontal_cortex', 'Caudate_basal_ganglia_Frontal_cortex', 'Cortex_Frontal_cortex', 'Frontal_cortex_Hippocampus', 'Frontal_cortex_Hypothalamus', 'Frontal_cortex_Nucleus_accumbens_basal_ganglia', 'Frontal_cortex_Putamen_basal_ganglia', 'Frontal_cortex_Spinal_cord_cervical_c1', 'Frontal_cortex_Substantia_nigra', 'Anterior_cingulate_cortex_BA24_Cerebellum', 'Caudate_basal_ganglia_Cerebellar_hemisphere', 'Cerebellar_hemisphere_Frontal_cortex', 'Cerebellum_Frontal_cortex', 'Cerebellar_hemisphere_Cortex', 'Cerebellar_hemisphere_Nucleus_accumbens_basal_ganglia', 'Cerebellum_Cortex', 'Cerebellum_Hypothalamus', 'Caudate_basal_ganglia_Cerebellum', 'Cerebellar_hemisphere_Cerebellum', 'Cerebellum_Nucleus_accumbens_basal_ganglia']
chr_names = ['chr{}'.format(i) for i in range(1, 23)] + ['chrX', 'chrY']

###############################
# extract introns from mntjulip result, diff_intron.txt
mntjulip_intron_set = set()
mntjulip_intron_dict = defaultdict(list)
base_dir = Path('/home-2/gyang22@jhu.edu/work/projects/MntJULiP_brain_GTEx/MntJULiP_clean_splice_out')
for folder in folders:
    file = base_dir / folder / 'intron_data.txt'
    with open(file, 'r') as f:
        lines = f.readlines()

    cond1, cond2 = lines[0].strip().split()[-2:]
    cond1, cond2 = cond1[12:-1], cond2[12:-1]
    genes = set()

    # chrom   start   end     strand  gene_name       status  read_counts(Cerebellum) read_counts(Frontal_cortex)
    for line in lines[1:]:
        items = line.strip().split('\t')
        _chr, start, end, strand, gene_name, status, counts1, counts2 = items
        start, end = int(start), int(end)
        if status == 'OK' and _chr in chr_names:
            mntjulip_intron_set.add((_chr, strand, start, end))
            mntjulip_intron_dict[(_chr, strand, start, end)] += [cond1, cond2]

###############################
# novel intron in mntjulip but not in gencode
print(len(gencode_intron_set), len(mntjulip_intron_set), len(novel_intron_set))
novel_intron_set = set()
for intron in mntjulip_intron_set:
    if intron not in gencode_intron_set:
        novel_intron_set.add(intron)


seen = set()
intron_samples_dict = {}
tissue_dict = {'Amygdala':0, 'Cerebellar_hemisphere':1, 'Cerebellum':1, 'Caudate_basal_ganglia': 2, 'Nucleus_accumbens_basal_ganglia':2, 'Putamen_basal_ganglia':2, 'Anterior_cingulate_cortex_BA24':3, 'Cortex':3 , 'Frontal_cortex':3, 'Hippocampus':4, 'Hypothalamus':5, 'Spinal_cord_cervical_c1':6, 'Substantia_nigra':7}

# build the presence/absence matrix
for folder in folders:
    file = base_dir / folder / 'intron_data.txt'
    with open(file, 'r') as f:
        lines = f.readlines()

    # read_counts(Caudate_basal_ganglia)      read_counts(Frontal_cortex)
    cond1, cond2 = lines[0].strip().split()[-2:]
    cond1, cond2 = cond1[12:-1], cond2[12:-1]
    if cond1 in seen and cond2 in seen:
        continue

    for line in lines[1:]:
        items = line.strip().split('\t')
        _chr, start, end, strand, gene_name, status, counts1, counts2 = items
        start, end = int(start), int(end)
        if (_chr, strand, start, end) in novel_intron_set:
            if (_chr, strand, start, end) not in intron_samples_dict:
                intron_samples_dict[(_chr, strand, start, end)] = defaultdict(list)
            if cond1 not in seen:
                for count in counts1.split(','):
                    # value = 1 if int(count) > 1 else 0
                    intron_samples_dict[(_chr, strand, start, end)][tissue_dict[cond1]].append(int(count))
            if cond2 not in seen:
                for count in counts2.split(','):
                    # value = 1 if int(count) > 1 else 0
                    intron_samples_dict[(_chr, strand, start, end)][tissue_dict[cond2]].append(int(count))

    seen.add(cond1)
    seen.add(cond2)


pickle.dump(intron_samples_dict, open('intron_samples_dict.pkl', "wb"))

# significant_introns1 = []
# significant_introns2 = []

# for intron, result in intron_samples_dict.items():
#     lsts = list(result.values())
#     if sum(sum(lst) for lst in lsts) == 1398:
#         continue
#     if len(lsts) < 8:
#         significant_introns1.append(intron)
#         continue

#     _, pvalue = stats.kruskal(*lsts)
#     if pvalue < 0.001:
#         significant_introns2.append((intron, pvalue))
