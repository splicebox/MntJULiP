################################################################################################################
from collections import defaultdict
import numpy as np

file = f'/home-2/gyang22@jhu.edu/work/projects/HPVOP/Mnt_JULiP/diff_introns.txt'
with open(file, 'r') as f:
    lines = f.readlines()

gene_dict = defaultdict(lambda: (0, 0))
for line in lines[1:]:
    _chr, start, end, strand, gene_names_str, status, _, p_value, q_value, m1, m2 = line.strip().split('\t')
    if status == 'TEST' and gene_names_str != '.':
        start, end, p_value, q_value = int(start), int(end), float(p_value), float(q_value)
        m1, m2 = float(m1), float(m2)
        for name in gene_names_str.split(','):
            _m1, _m2 = gene_dict[name]
            gene_dict[name] = (_m1 + m1, _m2 + m2)

de_genes = set()
for name, (m1, m2) in gene_dict.items():
    if (abs(m1 - m2) > min(m1, m2)) and (m1 > 30 or m2 > 30):
        de_genes.add(name)


file = f'/home-2/gyang22@jhu.edu/work/projects/HPVOP/Mnt_JULiP/diff_spliced_groups.txt'
with open(file, 'r') as f:
    lines = f.readlines()

group_genes = {}
gene_q_values_dict = defaultdict(list)
for line in lines[1:]:
    group_id, _chr, _, strand, gene_names_str, _, _, p_value, q_value = line.strip().split('\t')
    if gene_names_str != '.' and len(gene_names_str.split(',')) == 1:
        gene_name = gene_names_str.split(',')[0]
        gene_q_values_dict[gene_name].append(float(q_value))

no_ds_genes = set()
for gene_name, _list in gene_q_values_dict.items():
    if np.all(np.array(_list) > 0.1):
        no_ds_genes.add(gene_name)


print(de_genes.intersection(no_ds_genes))
