# from scipy import stats
import numpy as np
from collections import defaultdict
import pickle
from scipy import stats


intron_samples_dict = pickle.load(open('/Users/gyang/Desktop/intron_samples_dict.pkl', 'rb'))

intron_matrix_dict = {}
intron_cutoff = 0.9
for intron, result in intron_samples_dict.items():
    intron_matrix_dict[intron] = defaultdict(list)
    for key, counts in result.items():
        for count in counts:
            val = 1 if count > intron_cutoff else 0
            intron_matrix_dict[intron][key].append(val)

ratio = 0.15
sum_array = [80, 262, 357, 349, 102, 102,  75,  71]
# calculate introns that only appear in one tissue
filtered_novel_introns = set()
intron_count_dict = defaultdict(int)
for intron, value_dict in intron_matrix_dict.items():
    result = [[0] * 2 for _ in range(8)]
    for key, vals in value_dict.items():
        for val in vals:
            result[key][val] += 1
    count = 0
    for i in range(len(result)):
        if result[i][1] >= sum_array[i] * ratio:
            count += 1
        intron_count_dict[intron] += result[i][0]
    if count == 1:
        filtered_novel_introns.add(intron)

detailed_outputs = []
intron_outputs = []
sum_array = np.array(sum_array)
for intron in filtered_novel_introns:
    result = [[0] * 3 for _ in range(8)]
    for key, vals in intron_matrix_dict[intron].items():
        for val in vals:
            result[key][1 - val] += 1
    result = np.array(result).T
    # result[0]: presence, result[1]: absence, result[2]: 85% total
    result[1] = sum_array - result[0]
    result[2] = sum_array * ratio
    if intron in filtered_novel_introns:
        detailed_outputs.append(f"intron: {intron}\n{result}\n\n")
        intron_outputs.append(intron)


file = '/Users/gyang/Desktop/novel_introns_1_tissue_info.txt'
with open(file, 'w') as f:
    for line in detailed_outputs:
        f.write(f'{line}')

file = '/Users/gyang/Desktop/novel_introns_1_tissue_list.txt'
with open(file, 'w') as f:
    for intron in intron_outputs:
        f.write(f'{intron}\n')
