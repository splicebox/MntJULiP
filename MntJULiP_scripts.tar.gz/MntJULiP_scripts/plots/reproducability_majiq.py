import matplotlib.pyplot as plt
from collections import defaultdict
import numpy as np

##################################################. MAJIQ  #########################################################

base_dir = '/ccb/salz3/florea/Hippocampus/'
file = base_dir + 'MAJIQ/dataset_A/voila_out/control_epileptic.deltapsi.tsv'
with open(file, 'r') as f:
    lines = f.readlines()

intron_dpsis_dict = defaultdict(list)
for line in lines[1:]:
    items = line.strip().split('\t')
    dpsis = [float(v) for v in items[3].split(';')]
    intron_coords = [v.split('-') for v in items[17].split(';')]
    _chr, strand = items[15], items[16]
    for dpsi, (start, end) in zip(dpsis, intron_coords):
        start, end = int(start), int(end)
        intron_dpsis_dict[(_chr, strand, start, end)].append(dpsi)

intron_dpsi_dict_A = {}
for intron, dpsi_list in intron_dpsis_dict.items():
    intron_dpsi_dict_A[intron] = max(dpsi_list, key=abs)

################################
file = base_dir + 'MAJIQ/dataset_D/voila_out/control_epileptic.deltapsi.tsv'
with open(file, 'r') as f:
    lines = f.readlines()

intron_dpsis_dict = defaultdict(list)
for line in lines[1:]:
    items = line.strip().split('\t')
    dpsis = [float(v) for v in items[3].split(';')]
    intron_coords = [v.split('-') for v in items[17].split(';')]
    _chr, strand = items[15], items[16]
    for dpsi, (start, end) in zip(dpsis, intron_coords):
        start, end = int(start), int(end)
        intron_dpsis_dict[(_chr, strand, start, end)].append(dpsi)

intron_dpsi_dict_D = {}
for intron, dpsi_list in intron_dpsis_dict.items():
    intron_dpsi_dict_D[intron] = max(dpsi_list, key=abs)


x = []
y = []

for intron, dpsi_A in intron_dpsi_dict_A.items():
    if intron in intron_dpsi_dict_D:
        dpsi_D = intron_dpsi_dict_D[intron]
        x.append(dpsi_A)
        y.append(dpsi_D)

plt.figure(num=None, figsize=(10, 8), dpi=86, facecolor='w', edgecolor='k')
plt.scatter(x, y, color='blue', s=5)
# legend = plt.legend(loc='upper left')
# legend.legendHandles[0]._sizes = [10]
plt.xlabel("dataset_A (dPSI)")
plt.ylabel("dataset_D (dPSI)")
plt.ylim((-0.5, 0.51))
plt.xlim((-0.5, 0.51))
plt.yticks(np.arange(-0.5, 0.51, 0.1))
plt.xticks(np.arange(-0.5, 0.51, 0.1))
plt.axhline(y=0.05, linestyle='dotted')
plt.axhline(y=-0.05, linestyle='dotted')
plt.axvline(x=0.05, linestyle='dotted')
plt.axvline(x=-0.05, linestyle='dotted')

file = '/ccb/salz3/florea/Hippocampus/results/reproducability_majiq.png'
plt.savefig(file)
plt.close()

###############################################################################
dpsis_A = []
dpsis_D = []
for intron, dpsi in intron_dpsi_dict_A.items():
    if intron in intron_dpsi_dict_D:
        dpsis_A.append(dpsi)
        dpsis_D.append(intron_dpsi_dict_D[intron])

print(np.corrcoef(dpsis_A, dpsis_D))


dpsis_A = np.array(dpsis_A)
dpsis_D = np.array(dpsis_D)
diff = dpsis_A - dpsis_D
print(diff.max(), diff.min())
