# dict tran and fpkm
from collections import defaultdict
from scipy import stats
import matplotlib.pyplot as plt

import numpy as np


def get_introns(exons):
    if len(exons) <= 1:
        return []
    else:
        introns = []
        _list = sorted(exons)
        start = _list[0][1]
        for i in range(1, len(_list)):
            end = _list[i][0]
            introns.append((start, end))
            start = _list[i][1]
        return introns


# read exon info from the file.
tran_exons_dict = defaultdict(list)
gtf_file = '/ccb/salz3/gyang/simulation3/gencode.v22.annotation'

gene_id_name_dict = {}
gene_name_id_dict = defaultdict(set)
tran_exons_dict = defaultdict(list)
with open(gtf_file, 'r') as f:
    for line in f:
        if line is not '\n':
            items = line.strip().split('\t')
            if items[2] == 'exon':
                _chr, strand = items[0], items[6]
                start, end = items[3: 5]
                _items = items[8].split('"')
                tran_id, gene_id = _items[3], _items[1]
                gene_id, gene_name = _items[1], _items[9]
                tran_exons_dict[(_chr, strand, tran_id)].append((int(start), int(end)))
                gene_id_name_dict[gene_id] = gene_name
                gene_name_id_dict[gene_name].add(gene_id)

# get intron info
tran_introns_dict = defaultdict(list)
intron_trans_dict = defaultdict(list)
tran_info_dict = {}
for (_chr, strand, tran_id), exons in tran_exons_dict.items():
    tran_info_dict[tran_id] = (_chr, strand, tran_id)
    introns = get_introns(exons)
    for intron in introns:
        tran_introns_dict[(_chr, strand, tran_id)].append((_chr, strand, *intron))
        intron_trans_dict[(_chr, strand, *intron)].append(tran_id)


###############################################################################
gene_file = '/Users/gyang/test/genes_info.txt'
tran_fpkm_control_dict = {}
tran_fpkm_case_dict = {}
chosen_tran_set = set()
gene_fpkm_control_dict = defaultdict(lambda: 0)
gene_fpkm_case_dict = defaultdict(lambda: 0)
tran_gene_dict = {}

with open(gene_file, 'r') as f:
    for line in f:
        items = line.strip().split('\t')
        gene_id = items[0]
        bool1, bool2, bool3 = [b == 'True' for b in items[3: 6]]
        if bool1 and not(bool2) and not(bool3):  # only swapped the top two trans' expr
            for item in items[6].split(', ')[:2]:
                tran_id, fpkm = item.strip().split(':')
                chosen_tran_set.add(tran_id)

        for item in items[6].split(', '):
            tran_id, fpkm = item.strip().split(':')
            tran_fpkm_control_dict[tran_id] = float(fpkm)
            gene_fpkm_control_dict[gene_id] += float(fpkm)
            tran_gene_dict[tran_id] = gene_id

        for item in items[7].split(','):
            tran_id, fpkm = item.strip().split(':')
            tran_fpkm_case_dict[tran_id] = float(fpkm)
            gene_fpkm_case_dict[gene_id] += float(fpkm)

########################################################. leafcutter  #######################################################
file = '/Users/gyang/test/leafcutter_star/leafcutter_ds_cluster_significance.txt'
with open(file, 'r') as f:
    lines = f.readlines()

cluster_pvalue_dict = {}
for line in lines[1:]:
    cluster, status, _, _, p_value, _, _ = line.strip().split('\t')
    if status == 'Success':
        _chr, cluster_id = cluster.split(':')
        cluster_pvalue_dict[cluster_id] = float(p_value)

#######
file = '/Users/gyang/test/leafcutter_star/leafcutter_ds_effect_sizes.txt'
with open(file, 'r') as f:
    lines = f.readlines()

leafcutter_intron_dpsi_dict = {}
leafcutter_intron_group_pvalue_dict = defaultdict(list)
for line in lines[1:]:
    # intron  logef   case    control deltapsi
    intron_info, _, _, _, dpsi = line.strip().split('\t')
    dpsi = float(dpsi)
    strand = 'NA'
    _chr, start, end, cluster_id = intron_info.split(':')
    start, end = int(start), int(end)
    for strand in ['-', '+']:
        leafcutter_intron_dpsi_dict[(_chr, strand, start, end)] = dpsi
        leafcutter_intron_group_pvalue_dict[(_chr, strand, start, end)] = cluster_pvalue_dict[cluster_id]


#######
intron_dpsi_dict = {}
_leafcutter_intron_dpsi_dict = {}
for intron, trans in intron_trans_dict.items():
    if intron not in leafcutter_intron_dpsi_dict:
        continue

    flag = False
    cntrl_sum = 0
    for tran_id in trans:
        if tran_id in chosen_tran_set:
            flag = True
        if tran_id in tran_fpkm_control_dict:
            cntrl_sum += tran_fpkm_control_dict[tran_id]

    case_sum = 0
    for tran_id in trans:
        if tran_id in tran_fpkm_case_dict:
            case_sum += tran_fpkm_case_dict[tran_id]

    gene_id = tran_gene_dict[tran_id]
    psi_cntrl = cntrl_sum / gene_fpkm_control_dict[gene_id]
    psi_case = case_sum / gene_fpkm_case_dict[gene_id]
    dpsi = psi_cntrl - psi_case

    if flag:
        intron_dpsi_dict[intron] = dpsi
        _leafcutter_intron_dpsi_dict[intron] = leafcutter_intron_dpsi_dict[intron]


#############
# x = []
# y = []
# for intron, dpsi in _leafcutter_intron_dpsi_dict.items():
#     if intron in intron_dpsi_dict:
#         x.append(dpsi)
#         y.append(intron_dpsi_dict[intron])

# plt.scatter(x, y)
# plt.ylabel("reference")
# plt.xlabel("new leafcutter")
# plt.show()


#############
x1 = []
x2 = []
x3 = []
y1 = []
y2 = []
y3 = []
for intron, dpsi in _leafcutter_intron_dpsi_dict.items():
    if intron in intron_dpsi_dict:
        p_value = leafcutter_intron_group_pvalue_dict[intron]
        if p_value <= 0.05 and abs(dpsi) >= 0.05:
            x1.append(dpsi)
            y1.append(intron_dpsi_dict[intron])
        elif 0.1 >= p_value > 0.05 and abs(dpsi) >= 0.05:
            x2.append(dpsi)
            y2.append(intron_dpsi_dict[intron])
        else:
            x3.append(dpsi)
            y3.append(intron_dpsi_dict[intron])


plt.figure(num=None, figsize=(10, 8), dpi=86, facecolor='w', edgecolor='k')
plt.scatter(x1, y1, color='red', label=r'$p\_value \leq 0.05, |dPSI| \geq 0.05$', s=10)
plt.scatter(x2, y2, color='blue', label=r'$0.1 > p\_value > 0.05, |dPSI| \geq 0.05$', s=10)
plt.scatter(x3, y3, color='green', label='Others', s=10)
legend = plt.legend(loc='upper left')
legend.legendHandles[0]._sizes = [10]
legend.legendHandles[1]._sizes = [10]
legend.legendHandles[2]._sizes = [10]
plt.ylabel("reference")
plt.xlabel("new leafcutter")
# plt.show()

file = '/Users/gyang/OneDrive/1-Florea Lab/New_JULiP_Paper/Figures/simulated_data/leafcutter_sim_dpsi.png'
plt.savefig(file)
plt.close()


#############
x1 = []
x2 = []
x3 = []
y1 = []
y2 = []
y3 = []
for intron, dpsi in _leafcutter_intron_dpsi_dict.items():
    if intron in intron_dpsi_dict:
        p_value = leafcutter_intron_group_pvalue_dict[intron]
        if p_value <= 0.05 and abs(dpsi) >= 0.05:
            x1.append(dpsi)
            y1.append(intron_dpsi_dict[intron])
        elif 0.1 >= p_value > 0.05 and abs(dpsi) >= 0.05:
            x2.append(dpsi)
            y2.append(intron_dpsi_dict[intron])
        else:
            x3.append(dpsi)
            y3.append(intron_dpsi_dict[intron])


plt.figure(num=None, figsize=(10, 8), dpi=86, facecolor='w', edgecolor='k')
plt.scatter(np.abs(x1), np.abs(y1), color='red', label=r'$p\_value \leq 0.05, |dPSI| \geq 0.05$', s=10)
plt.scatter(np.abs(x2), np.abs(y2), color='blue', label=r'$0.1 > p\_value > 0.05, |dPSI| \geq 0.05$', s=10)
plt.scatter(np.abs(x3), np.abs(y3), color='green', label='Others', s=10)
legend = plt.legend(loc='upper left')
legend.legendHandles[0]._sizes = [10]
legend.legendHandles[1]._sizes = [10]
legend.legendHandles[2]._sizes = [10]
plt.ylabel("reference")
plt.xlabel("new leafcutter")
# plt.show()

file = '/Users/gyang/OneDrive/1-Florea Lab/New_JULiP_Paper/Figures/simulated_data/leafcutter_sim_abs_dpsi.png'
plt.savefig(file)
plt.close()

