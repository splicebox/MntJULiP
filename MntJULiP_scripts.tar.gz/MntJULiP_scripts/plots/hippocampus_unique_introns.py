# dict tran and fpkm
from collections import defaultdict
from scipy import stats
import matplotlib.pyplot as plt

import numpy as np

import numpy as np
import matplotlib.mlab as mlab
import matplotlib.pyplot as plt
import pandas as pd


def get_introns(exons):
    if len(exons) <= 1:
        return []
    else:
        introns = []
        _list = sorted(exons)
        start = _list[0][1]
        for i in range(1, len(_list)):
            end = _list[i][0]
            introns.append((start, end))
            start = _list[i][1]
        return introns


# read exon info from the file.
tran_exons_dict = defaultdict(list)
base_dir = '/ccb/salz3/florea/Hippocampus/'
gtf_file = base_dir + 'gencode.vM17.annotation.gtf'
gene_id_name_dict = {}
tran_exons_dict = defaultdict(list)
tran_gene_id_dict = {}
with open(gtf_file, 'r') as f:
    for line in f:
        if line is not '\n' and not(line.startswith('#')):
            items = line.strip().split('\t')
            if items[2] == 'exon':
                _chr, strand = items[0], items[6]
                start, end = items[3: 5]
                _items = items[8].split('"')
                tran_id, gene_id = _items[3], _items[1]
                gene_id, gene_name = _items[1], _items[7]
                tran_exons_dict[(_chr, strand, tran_id)].append((int(start), int(end)))
                gene_id_name_dict[gene_id] = gene_name
                tran_gene_id_dict[tran_id] = gene_id


intron_count_dict = defaultdict(int)
for (_chr, strand, tran_id), exons in tran_exons_dict.items():
    introns = get_introns(exons)
    if introns:
        for intron in introns:
            intron_count_dict[(_chr, strand, *intron)] += 1

unique_introns = set()
for intron, count in intron_count_dict.items():
    if count == 1:
        unique_introns.add(intron)


file = base_dir + 'Mnt_JULiP/dataset_A/diff_introns.txt'
with open(file, 'r') as f:
    lines = f.readlines()


intron_output_buffer = lines[0]
for line in lines[1:]:
    # chrom start   end strand  gene_name   status  llr p_value q_value avg_read_counts(control)    avg_read_counts(epileptic)
    _chr, start, end, strand, gene_names_str, status, _, p_value, q_value, _, _ = line.strip().split('\t')
    if status == 'TEST':
        start, end, p_value, q_value = int(start), int(end), float(p_value), float(q_value)
        if p_value < 0.05 and (_chr, strand, start, end) in unique_introns:
            intron_output_buffer += line

file = base_dir + 'Mnt_JULiP/dataset_A/unique_introns.txt'
with open(file, 'w') as f:
    f.write(intron_output_buffer)
