#!/bin/bash

#SBATCH --time=2-0:0:0
#SBATCH -p parallel
#SBATCH --exclusive
#SBATCH --mail-type=end
#SBATCH --mail-user=gyang@jhu.edu

# work_dir='/home-2/gyang22@jhu.edu/work/Guangyu/brain_GTEx/MntJULiP'
work_dir='/home-2/gyang22@jhu.edu/work/projects/MntJULiP_brain_GTEx/MntJULiP_clean_splice_out'
gtf='/home-2/gyang22@jhu.edu/work/Guangyu/gencode.v36.annotation.gtf'
mntjulip='/home-2/gyang22@jhu.edu/MntJULiP/mntjulip'

module load python/3.7
module load gcc/6.4.0.lua

# note: the comparison name should be consistent with the ones generated in 'generate_splice_list_13_brain_tissue.py'
for comparison in Amygdala_Frontal_cortex Amygdala_Cortex Amygdala_Cerebellum Amygdala_Cerebellar_hemisphere Amygdala_Caudate_basal_ganglia Amygdala_Anterior_cingulate_cortex_BA24 Spinal_cord_cervical_c1_Substantia_nigra Putamen_basal_ganglia_Substantia_nigra Putamen_basal_ganglia_Spinal_cord_cervical_c1 Nucleus_accumbens_basal_ganglia_Substantia_nigra Nucleus_accumbens_basal_ganglia_Spinal_cord_cervical_c1 Nucleus_accumbens_basal_ganglia_Putamen_basal_ganglia Hypothalamus_Substantia_nigra Hypothalamus_Spinal_cord_cervical_c1 Hypothalamus_Putamen_basal_ganglia Hypothalamus_Nucleus_accumbens_basal_ganglia Hippocampus_Substantia_nigra Hippocampus_Spinal_cord_cervical_c1 Hippocampus_Putamen_basal_ganglia Hippocampus_Nucleus_accumbens_basal_ganglia Hippocampus_Hypothalamus Frontal_cortex_Substantia_nigra Frontal_cortex_Spinal_cord_cervical_c1 Frontal_cortex_Putamen_basal_ganglia Frontal_cortex_Nucleus_accumbens_basal_ganglia Frontal_cortex_Hypothalamus Frontal_cortex_Hippocampus Cortex_Substantia_nigra Cortex_Spinal_cord_cervical_c1 Cortex_Putamen_basal_ganglia Cortex_Nucleus_accumbens_basal_ganglia Cortex_Hypothalamus Cortex_Hippocampus Cortex_Frontal_cortex Cerebellum_Substantia_nigra Cerebellum_Spinal_cord_cervical_c1 Cerebellum_Putamen_basal_ganglia Cerebellum_Nucleus_accumbens_basal_ganglia Cerebellum_Hypothalamus Cerebellum_Hippocampus Cerebellum_Frontal_cortex Cerebellum_Cortex Cerebellar_hemisphere_Substantia_nigra Cerebellar_hemisphere_Spinal_cord_cervical_c1 Cerebellar_hemisphere_Putamen_basal_ganglia Cerebellar_hemisphere_Nucleus_accumbens_basal_ganglia Cerebellar_hemisphere_Hypothalamus Cerebellar_hemisphere_Hippocampus Cerebellar_hemisphere_Frontal_cortex Cerebellar_hemisphere_Cortex Cerebellar_hemisphere_Cerebellum Caudate_basal_ganglia_Substantia_nigra Caudate_basal_ganglia_Spinal_cord_cervical_c1 Caudate_basal_ganglia_Putamen_basal_ganglia Caudate_basal_ganglia_Nucleus_accumbens_basal_ganglia Caudate_basal_ganglia_Hypothalamus Caudate_basal_ganglia_Hippocampus Caudate_basal_ganglia_Frontal_cortex Caudate_basal_ganglia_Cortex Caudate_basal_ganglia_Cerebellum Caudate_basal_ganglia_Cerebellar_hemisphere Anterior_cingulate_cortex_BA24_Substantia_nigra Anterior_cingulate_cortex_BA24_Spinal_cord_cervical_c1 Anterior_cingulate_cortex_BA24_Putamen_basal_ganglia Anterior_cingulate_cortex_BA24_Nucleus_accumbens_basal_ganglia Anterior_cingulate_cortex_BA24_Hypothalamus Anterior_cingulate_cortex_BA24_Hippocampus Anterior_cingulate_cortex_BA24_Frontal_cortex Anterior_cingulate_cortex_BA24_Cortex Anterior_cingulate_cortex_BA24_Cerebellum Anterior_cingulate_cortex_BA24_Cerebellar_hemisphere Anterior_cingulate_cortex_BA24_Caudate_basal_ganglia Amygdala_Substantia_nigra Amygdala_Spinal_cord_cervical_c1 Amygdala_Putamen_basal_ganglia Amygdala_Nucleus_accumbens_basal_ganglia Amygdala_Hypothalamus Amygdala_Hippocampus
do
    out_dir="${work_dir}/${comparison}"
    ${mntjulip} --out-dir ${out_dir} \
                --splice-list ${out_dir}/splice_list.txt \
                --num-threads 24 \
                --min-count 5 \
                --batch-size 2000 \
                --anno-file ${gtf}
done


out_dir="${work_dir}/13_brain_tissues"
python3 /home-2/gyang22@jhu.edu/MntJULiP/run.py --out-dir ${out_dir} \
            --splice-list ${out_dir}/splice_list.txt \
            --num-threads 4 \
            --min-count 5 \
            --batch-size 2000 \
            --anno-file ${gtf}


# check if there are files that are empty listed in ${out_dir}/splice_list.txt
for i in `cut -f1 ${out_dir}/splice_list.txt`
do
    if [ ! -s $i ]
    then
        echo $i
    fi
done
