chrs = [f'chr{i}' for i in range (1, 20)] + ['chrX', 'chrY', 'chrM']
base_dir = '/ccb/salz3/florea/Hippocampus/'

#######################################################  Leafcutter #######################################################
file = base_dir + '/LeafCutter/results/leafcutter_ds_cluster_significance.txt'
with open(file, 'r') as f:
    lines = f.readlines()

cluster_pvalue_dict = {}
cluster_qvalue_dict = {}
for line in lines[1:]:
    cluster, status, _, _, p_value, q_value, gene_name = line.strip().split('\t')
    if status == 'Success':
        _chr, cluster_id = cluster.split(':')
        p_value, q_value = float(p_value), float(q_value)
        cluster_pvalue_dict[cluster_id] = p_value
        cluster_qvalue_dict[cluster_id] = q_value

###############################################################################
file = base_dir + 'LeafCutter/results/leafcutter_ds_effect_sizes.txt'
with open(file, 'r') as f:
    lines = f.readlines()

leafcutter_intron_set = set()
for line in lines[1:]:
    # intron  logef   case    control deltapsi
    intron_info, _, _, _, dpsi = line.strip().split('\t')
    dpsi = float(dpsi)
    _chr, start, end, cluster_id = intron_info.split(':')
    start, end = int(start), int(end)
    p_value = cluster_pvalue_dict[cluster_id]
    q_value = cluster_qvalue_dict[cluster_id]
    if p_value < 0.05 and abs(dpsi) > 0.05 and _chr in chrs:
        leafcutter_intron_set.add((_chr, start, end))

print(f"LeafCutter: {len(leafcutter_intron_set)}")

#######################################################  MAJIQ #######################################################
file = base_dir + 'MAJIQ/results/voila_out/control_epileptic.deltapsi.tsv'

with open(file, 'r') as f:
    lines = f.readlines()

majiq_intron_set = set()
for line in lines[1:]:
    items = line.strip().split('\t')
    _chr, strand = items[15: 17]
    if _chr in chrs:
        gene_id = items[1]
        gene_name = items[0]
        dpsis = [float(v) for v in items[3].split(';')]
        intron_coords = [v for v in items[17].split(';')]
        for intron_coord, dpsi in zip(intron_coords, dpsis):
            if abs(dpsi) > 0.05:
                start, end = [int(v) for v in intron_coord.split('-')]
                majiq_intron_set.add((_chr, start, end))

print(f"MAJIQ: {len(majiq_intron_set)}")

#######################################################  Mnt JULiP #######################################################
file = base_dir + 'Mnt_JULiP/all/diff_spliced_groups.txt'
with open(file, 'r') as f:
    lines = f.readlines()

group_q_values = {}
group_p_values = {}
group_genes = {}
for line in lines[1:]:
    group_id, _chr, _, strand, gene_names_str, _, _, p_value, q_value = line.strip().split('\t')
    group_q_values[group_id] = float(q_value)
    group_p_values[group_id] = float(p_value)
    if gene_names_str != '.':
        group_genes[group_id] = gene_names_str.split(',')
    else:
        group_genes[group_id] = []

file = base_dir + 'Mnt_JULiP/all/diff_spliced_introns.txt'
with open(file, 'r') as f:
    lines = f.readlines()

julip_intron_set = set()
for line in lines[1:]:
    group_id, _chr, start, end, strand, _, _, _, dpsi = line.strip().split('\t')
    start, end, dpsi = int(start), int(end), float(dpsi)
    q_value = group_q_values[group_id]
    p_value = group_p_values[group_id]
    if p_value < 0.05 and abs(dpsi) > 0.05 and _chr in chrs:
        julip_intron_set.add((_chr, start, end))

print(f"MntJULiP: {len(julip_intron_set)}")

#######################################################  Venn Diagram #######################################################
import venn
import matplotlib.pyplot as plt

labels = venn.get_labels([leafcutter_intron_set, majiq_intron_set, julip_intron_set], fill=['number'])
fig, ax = venn.venn3(labels, names=[f'LeafCutter({len(leafcutter_intron_set)})',
                                f'MAJIQ({len(majiq_intron_set)})', f'MntJULiP({len(julip_intron_set)})'])

file = '/ccb/salz3/florea/Hippocampus/results/hippocampi_venn3_intron_pvalues.png'
fig.savefig(file)
plt.close()

