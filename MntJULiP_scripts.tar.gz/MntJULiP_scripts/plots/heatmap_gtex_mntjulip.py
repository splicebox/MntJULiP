################################################################################################################
from pathlib import Path
from collections import defaultdict
import os

import numpy as np
import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt

subtype_color_dict = {'Cerebellum': 'orange', 'Cortex': 'blue', 'Frontalcortex': 'yellow'}

base_dir = Path('/Users/gyang/Desktop/GTEx_heatmaps')

os.makedirs(base_dir / 'with_z_score', exist_ok=True)
os.makedirs(base_dir / 'without_z_score', exist_ok=True)

## read sample names and conditions
data_folder = '/Users/gyang/Desktop/gtex/MntJulip_out/'
file = data_folder + 'GTEx.brain.splice.txt'
with open(file, 'r') as f:
    lines = f.readlines()

col_colors = []
sample_names = []
for line in lines[1:]:
    items = line.strip().split('\t')
    sample_name = items[0].split('/')[-1].split('_')[1]
    condition = items[1]
    sample_names.append(sample_name)
    col_colors.append(subtype_color_dict[condition])

##
file = data_folder + 'diff_introns.txt'
with open(file, 'r') as f:
    lines = f.readlines()

gene_dict = defaultdict(lambda: (0, 0, 0))
for line in lines[1:]:
    # Cerebellum, Cortex, Frontalcortex
    _chr, start, end, strand, gene_names_str, status, _, p_value, q_value, m1, m2, m3 = line.strip().split('\t')
    if status == 'TEST' and gene_names_str != '.':
        start, end, p_value, q_value = int(start), int(end), float(p_value), float(q_value)
        m1, m2, m3 = float(m1), float(m2), float(m3)
        for name in gene_names_str.split(','):
            _m1, _m2, _m3 = gene_dict[name]
            gene_dict[name] = (_m1 + m1, _m2 + m2, _m3 + m3)

gene_set = set()
for name, (m1, m2, m3) in gene_dict.items():
    if m1 > 30 or m2 > 30 or m3 > 30:
        gene_set.add(name)

## get diff spliced groups
file = data_folder + 'diff_spliced_groups.txt'
with open(file, 'r') as f:
    lines = f.readlines()

group_set = set()
group_name_dict = {}
for line in lines[1:]:
    group_id, _chr, loc, strand, gene_names_str, _, _, p_value, q_value = line.strip().split('\t')
    p_value, q_value = float(p_value), float(q_value)
    if gene_names_str != '.' and len(gene_names_str.split(',')) == 1:
        gene_name = gene_names_str.split(',')[0]
        if gene_name in gene_set and p_value < 0.05:
            group_set.add(group_id)
            group_name_dict[group_id] = f"{gene_name}_{_chr}_{loc}"

## select groups by
file = data_folder + 'diff_spliced_introns.txt'
with open(file, 'r') as f:
    lines = f.readlines()

selected_groups = set()
for line in lines[1:]:
    group_id, _chr, start, end, strand, gene_names_str, _, _, psi1, psi2, psi3 = line.strip().split('\t')
    start, end = int(start), int(end)
    psi1, psi2, psi3 = float(psi1), float(psi2), float(psi3)
    if group_id in group_set:
        selected_groups.add(group_id)

group_introns_all_dict = defaultdict(list)
group_introns_ctrl_dict = defaultdict(list)
intron_group_dict = {}
for line in lines[1:]:
    group_id, _chr, start, end, strand, gene_names_str, _, _, psi1, psi2, psi3 = line.strip().split('\t')
    start, end = int(start), int(end)
    psi1, psi2, psi3 = float(psi1), float(psi2), float(psi3)
    if group_id in selected_groups:
        group_introns_all_dict[group_id].append((_chr, strand, start, end))
        if dpsi > 0:
            group_introns_ctrl_dict[group_id].append((_chr, strand, start, end))

##
file = data_folder + 'intron_data.txt'
with open(file, 'r') as f:
    lines = f.readlines()

intron_counts_dict = {}
for line in lines[1:]:
    _chr, start, end, strand, gene_names_str, status, cond1, cond2, cond3 = line.strip().split('\t')
    if status == "OK":
        counts = []
        for cond in [cond1, cond2, cond3]:
            for count in cond.split(','):
                counts.append(int(count))
        intron_counts_dict[(_chr, strand, int(start), int(end))] = counts

cond_name1, cond_name2 = lines[0].strip().split('\t')[-2:]
columns = [cond_name1[12:-1]] * len(cond1.split(',')) + [cond_name2[12:-1]] * len(cond2.split(','))

intron_counts_df = pd.DataFrame.from_dict(intron_counts_dict, orient='index', columns=columns)

group_value_dict = {}
for group_id, intron_list in group_introns_all_dict.items():
    sum_all = intron_counts_df.loc[intron_list].sum(axis=0)
    intron = intron_counts_df.loc[intron_list]['Ctrl'].mean(axis=1).idxmax()
    group_value_dict[group_name_dict[group_id]] = (intron_counts_df.loc[[intron]] / sum_all).values.tolist()[0]


group_value_array = pd.DataFrame.from_dict(group_value_dict, orient='index', columns=columns)
mask = group_value_array.isnull()

length = len(cond1.split(','))
group_value_cond1 = group_value_array.iloc[:, :length]
group_value_cond2 = group_value_array.iloc[:, length:]

group_value_cond1 = group_value_cond1.T.fillna(group_value_cond1.mean(axis=1)).T
group_value_cond2 = group_value_cond2.T.fillna(group_value_cond2.mean(axis=1)).T
group_value_array_new = pd.concat([group_value_cond1, group_value_cond2], axis=1)

clustermapParams = {
    'square':False # Tried to set this to True before. Don't: the dendograms do not scale well with it.
}
figureWidth = group_value_array.shape[1] / 4
figureHeight= group_value_array.shape[0] / 4
if figureHeight < 15:
    figureHeight = 15
if figureWidth < 15:
    figureWidth = 15

method = 'average'
metric = 'cityblock'

# with z score, cluster row only
file = base_dir / f'with_z_score/clustermap_by_events.png'
figure = sns.clustermap(group_value_array_new, cmap="RdBu_r", col_cluster=False, z_score=0, vmin=-5, vmax=5, col_colors=col_colors,
                        metric=metric, method=method,
                        yticklabels=1, xticklabels=1, figsize=(figureWidth, figureHeight), **clustermapParams)

figure.ax_heatmap.set_facecolor("lightgray")
for tick_label in figure.ax_heatmap.axes.get_xticklabels():
    tick_text = tick_label.get_text()
    if tick_text == 'Case':
        tick_label.set_color('cyan')
    else:
        tick_label.set_color('magenta')

figure.savefig(file)
plt.close()

################################################
# with z score, cluster both
file = base_dir / f'with_z_score/clustermap.png'
figure = sns.clustermap(group_value_array_new, cmap="RdBu_r", z_score=0, vmin=-5, vmax=5, col_colors=col_colors,
                        metric=metric, method=method, mask=mask,
                        yticklabels=1, xticklabels=1, figsize=(figureWidth, figureHeight), **clustermapParams)
figure.ax_heatmap.set_facecolor("lightgray")
for tick_label in figure.ax_heatmap.axes.get_xticklabels():
    tick_text = tick_label.get_text()
    if tick_text == 'Case':
        tick_label.set_color('cyan')
    else:
        tick_label.set_color('magenta')

figure.savefig(file)
plt.close()

# without z score, cluster row only
file = base_dir / f'without_z_score/clustermap_by_events.png'
figure = sns.clustermap(group_value_array_new, cmap=sns.cm.rocket_r, col_cluster=False, col_colors=col_colors,
                        metric=metric, method=method, mask=mask,
                        yticklabels=1, xticklabels=1, figsize=(figureWidth, figureHeight), **clustermapParams)
figure.ax_heatmap.set_facecolor("lightgray")
for tick_label in figure.ax_heatmap.axes.get_xticklabels():
    tick_text = tick_label.get_text()
    if tick_text == 'Case':
        tick_label.set_color('cyan')
    else:
        tick_label.set_color('magenta')

figure.savefig(file)
plt.close()

# without z score, cluster both
file = base_dir / f'without_z_score/clustermap.png'
figure = sns.clustermap(group_value_array_new, cmap=sns.cm.rocket_r, col_colors=col_colors,
                        metric=metric, method=method, mask=mask,
                        yticklabels=1, xticklabels=1, figsize=(figureWidth, figureHeight), **clustermapParams)
figure.ax_heatmap.set_facecolor("lightgray")
for tick_label in figure.ax_heatmap.axes.get_xticklabels():
    tick_text = tick_label.get_text()
    if tick_text == 'Case':
        tick_label.set_color('cyan')
    else:
        tick_label.set_color('magenta')

figure.savefig(file)
plt.close()

