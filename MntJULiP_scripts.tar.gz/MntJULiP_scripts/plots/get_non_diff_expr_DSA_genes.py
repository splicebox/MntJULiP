base_dir = '/ccb/salz3/florea/Hippocampus/'
gtf_file = base_dir + 'gencode.vM17.annotation.gtf'
gene_id_name_dict = {}
with open(gtf_file, 'r') as f:
    for line in f:
        if line is not '\n' and not(line.startswith('#')):
            items = line.strip().split('\t')
            if items[2] == 'exon':
                _chr, strand = items[0], items[6]
                start, end = items[3: 5]
                _items = items[8].split('"')
                gene_id, gene_name = _items[1], _items[7]
                gene_id_name_dict[gene_id] = gene_name

###############################################################################
file = base_dir + 'DESeq/results_all.csv'
with open(file, 'r') as f:
    lines = f.readlines()

deseq_gene_names = set()
for line in lines[1:]:
    # "","baseMean","log2FoldChange","lfcSE","stat","pvalue","padj"
    gene_id, _, _, _, _, p_value, q_value = line.strip().split(',')
    if q_value != 'NA':
        gene_name, q_value = gene_id_name_dict[gene_id[1:-1]], float(q_value)
        if q_value > 0.05:
            deseq_gene_names.add(gene_name)

###############################################################################
file = base_dir + 'Mnt_JULiP/all/diff_introns.txt'
with open(file, 'r') as f:
    lines = f.readlines()


intron_output_buffer = 'gene_names\tchr\tstrand\tstart\tend\tp_value\tq_value\n'
sig_genes = set()
for line in lines[1:]:
    # chrom start   end strand  gene_name   status  llr p_value q_value avg_read_counts(control)    avg_read_counts(epileptic)
    _chr, start, end, strand, gene_names_str, status, _, p_value, q_value, _, _ = line.strip().split('\t')
    if status == 'TEST':
        start, end, p_value, q_value = int(start), int(end), float(p_value), float(q_value)
        gene_set = set(gene_names_str.split(','))
        if p_value < 0.05 and gene_set.intersection(deseq_gene_names):
            gene_names = ",".join(gene_set.intersection(deseq_gene_names))
            sig_genes.update(gene_set.intersection(deseq_gene_names))
            intron_output_buffer += f'{gene_names}\t{_chr}\t{strand}\t{start}\t{end}\t{p_value}\t{q_value}\n'

file = base_dir + 'Mnt_JULiP/all/DSA_introns_in_non_diff_expr_genes.txt'
with open(file, 'w') as f:
    f.write(intron_output_buffer)


file = base_dir + 'Mnt_JULiP/all/non_diff_expr_DSA_genes.txt'
with open(file, 'w') as f:
    for gene in sig_genes:
        f.write(f'{gene}\n')
