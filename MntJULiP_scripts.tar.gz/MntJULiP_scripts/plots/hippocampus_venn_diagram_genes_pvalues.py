## mode1: |dPSI| > 0.05 and p-value <. 0.05 applies to all the programs
## mode2: |dPSI| > 0.05 applies to all the program, but Leafcutter & rmat choose q-value, MntJULiP use p-value.


chrs = [f'chr{i}' for i in range (1, 20)] + ['chrX', 'chrY', 'chrM']
base_dir = '/ccb/salz3/florea/Hippocampus/'

#######################################################  Leafcutter #######################################################
file = base_dir + 'LeafCutter/results/leafcutter_ds_cluster_significance.txt'
with open(file, 'r') as f:
    lines = f.readlines()

cluster_pvalue_dict = {}
cluster_qvalue_dict = {}
cluster_gene_name_dict = {}
for line in lines[1:]:
    cluster, status, _, _, p_value, q_value, gene_name = line.strip().split('\t')
    if status == 'Success':
        _chr, cluster_id = cluster.split(':')
        p_value, q_value = float(p_value), float(q_value)
        cluster_pvalue_dict[cluster_id] = p_value
        cluster_qvalue_dict[cluster_id] = q_value
        cluster_gene_name_dict[cluster_id] = gene_name

######### diff genes
file = base_dir + 'LeafCutter/results/leafcutter_ds_effect_sizes.txt'
with open(file, 'r') as f:
    lines = f.readlines()

leafcutter_gene_set = set()
for line in lines[1:]:
    # intron  logef   case    control deltapsi
    intron_info, _, _, _, dpsi = line.strip().split('\t')
    dpsi = float(dpsi)
    _chr, start, end, cluster_id = intron_info.split(':')
    p_value = cluster_pvalue_dict[cluster_id]
    q_value = cluster_qvalue_dict[cluster_id]
    gene_names = cluster_gene_name_dict[cluster_id]
    if p_value < 0.05 and abs(dpsi) > 0.05 and _chr in chrs:
        for gene_name in gene_names.split(','):
            leafcutter_gene_set.add(gene_name)

print(f"LeafCutter: {len(leafcutter_gene_set)}")

#######################################################  MAJIQ #######################################################
file = base_dir + 'MAJIQ/results/voila_out/control_epileptic.deltapsi.tsv'
# file = '/Users/gyang/test/voila_out_tophat/control_case.deltapsi.tsv'
with open(file, 'r') as f:
    lines = f.readlines()

majiq_gene_set = set()
for line in lines[1:]:
    items = line.strip().split('\t')
    _chr, strand = items[15: 17]
    if _chr in chrs:
        gene_id = items[1]
        gene_name = items[0]
        dpsis = [float(v) for v in items[3].split(';')]
        for dpsi in dpsis:
            if abs(dpsi) > 0.05:
                majiq_gene_set.add(gene_name)

print(f"MAJIQ: {len(majiq_gene_set)}")

#######################################################  rMATS #######################################################
results_dir = base_dir + 'rMATS.3.2.5/out/MATS_output/'

files = []
numbers = []
files.append(results_dir + 'SE.MATS.ReadsOnTargetAndJunctionCounts.txt')
files.append(results_dir + 'MXE.MATS.ReadsOnTargetAndJunctionCounts.txt')
files.append(results_dir + 'A5SS.MATS.ReadsOnTargetAndJunctionCounts.txt')
files.append(results_dir + 'A3SS.MATS.ReadsOnTargetAndJunctionCounts.txt')
files.append(results_dir + 'RI.MATS.ReadsOnTargetAndJunctionCounts.txt')

# # p_values
numbers.append(18)
numbers.append(20)
numbers.append(18)
numbers.append(18)
numbers.append(18)

# # q_values
# numbers.append(19)
# numbers.append(21)
# numbers.append(19)
# numbers.append(19)
# numbers.append(19)

rmats_gene_set = set()
tp_diff_spliced_genes = {}
tp_diff_present_genes = {}
for file, num in zip(files, numbers):
    with open(file, 'r') as f:
        lines = f.readlines()
    for line in lines[1:]:
        items = line.strip().split('\t')
        gene_id, gene_name, value = items[1][1:-1], items[2][1:-1], float(items[num])
        _chr, strand = items[3], items[4]
        dpsi = float(items[-1])
        if value <= 0.05 and abs(dpsi) > 0.05 and _chr in chrs:
            rmats_gene_set.add(gene_name)

print(f"rMATS: {len(rmats_gene_set)}")

#######################################################  Mnt JULiP #######################################################
file = base_dir + 'Mnt_JULiP/all/diff_spliced_groups.txt'
with open(file, 'r') as f:
    lines = f.readlines()

group_q_values = {}
group_p_values = {}
group_genes = {}
for line in lines[1:]:
    group_id, _chr, _, strand, gene_names_str, _, _, p_value, q_value = line.strip().split('\t')
    group_q_values[group_id] = float(q_value)
    group_p_values[group_id] = float(p_value)
    if gene_names_str != '.':
        group_genes[group_id] = gene_names_str.split(',')
    else:
        group_genes[group_id] = []

file = base_dir + 'Mnt_JULiP/all/diff_spliced_introns.txt'
with open(file, 'r') as f:
    lines = f.readlines()

julip_gene_set = set()
for line in lines[1:]:
    group_id, _chr, start, end, strand, _, _, _, dpsi = line.strip().split('\t')
    start, end, dpsi = int(start), int(end), float(dpsi)
    q_value = group_q_values[group_id]
    p_value = group_p_values[group_id]
    if p_value < 0.05 and abs(dpsi) > 0.05 and _chr in chrs:
        julip_gene_set.update(group_genes[group_id])

print(f"MntJULiP: {len(julip_gene_set)}")

##########################################################################################################################
print(f"LeafCutter & MAJIQ: {len(leafcutter_gene_set.intersection(majiq_gene_set))}")
print(f"LeafCutter & rMATS: {len(leafcutter_gene_set.intersection(rmats_gene_set))}")
print(f"LeafCutter & MntJULiP: {len(leafcutter_gene_set.intersection(julip_gene_set))}")

print(f"MAJIQ & rMATS: {len(majiq_gene_set.intersection(rmats_gene_set))}")
print(f"MAJIQ & MntJULiP: {len(majiq_gene_set.intersection(julip_gene_set))}")

print(f"rMATS & MntJULiP: {len(rmats_gene_set.intersection(julip_gene_set))}")


#######################################################  Venn Diagram #######################################################
import venn
import matplotlib.pyplot as plt

labels = venn.get_labels([leafcutter_gene_set, majiq_gene_set, rmats_gene_set, julip_gene_set], fill=['number'])
fig, ax = venn.venn4(labels, names=[f'LeafCutter({len(leafcutter_gene_set)})', f'MAJIQ({len(majiq_gene_set)})',
                                f'rMATS({len(rmats_gene_set)})', f'MntJULiP(DSR)({len(julip_gene_set)})'])

file = '/ccb/salz3/florea/Hippocampus/results/hippocampi_venn4_genes_pvalues.png'
fig.savefig(file)
plt.close()

