# dict tran and fpkm
from collections import defaultdict
from scipy import stats
import matplotlib.pyplot as plt

import numpy as np

import numpy as np
import matplotlib.mlab as mlab
import matplotlib.pyplot as plt
import pandas as pd


def get_introns(exons):
    if len(exons) <= 1:
        return []
    else:
        introns = []
        _list = sorted(exons)
        start = _list[0][1]
        for i in range(1, len(_list)):
            end = _list[i][0]
            introns.append((start, end))
            start = _list[i][1]
        return introns


# read exon info from the file.
tran_exons_dict = defaultdict(list)
gtf_file = '/ccb/salz3/florea/Hippocampus/gencode.vM17.annotation.gtf'
gene_id_name_dict = {}
tran_exons_dict = defaultdict(list)
tran_gene_id_dict = {}
with open(gtf_file, 'r') as f:
    for line in f:
        if line is not '\n' and not(line.startswith('#')):
            items = line.strip().split('\t')
            if items[2] == 'exon':
                _chr, strand = items[0], items[6]
                start, end = items[3: 5]
                _items = items[8].split('"')
                tran_id, gene_id = _items[3], _items[1]
                gene_id, gene_name = _items[1], _items[7]
                tran_exons_dict[(_chr, strand, tran_id)].append((int(start), int(end)))
                gene_id_name_dict[gene_id] = gene_name
                tran_gene_id_dict[tran_id] = gene_id

###############################################################################
file = '/ccb/salz3/florea/Hippocampus/Mnt_JULiP/all/diff_introns.txt'
with open(file, 'r') as f:
    lines = f.readlines()

intron_values_dict = {}
gene_dict = defaultdict(lambda: np.zeros(2))
for line in lines[1:]:
    items = line.strip().split('\t')
    _chr, start, end, strand, gene_names_str, status, _, p_value, q_value, c1, c2 = line.strip().split('\t')
    if status == 'TEST' and gene_names_str != '.':
        start, end, p_value, q_value = int(start), int(end), float(p_value), float(q_value)
        c1, c2 = float(c1), float(c2)
        if c1 > 1 or c2 > 1:
            intron_values_dict[(_chr, strand, start, end)] = (c1, c2, p_value)

###############################################################################
# assign introns to gene
gene_introns_dict = defaultdict(set)
start_site_introns_dict = defaultdict(set)
end_site_introns_dict = defaultdict(set)
intron_set = set()
for (_chr, strand, tran_id), exons in tran_exons_dict.items():
    introns = get_introns(exons)
    if introns:
        gene_id = tran_gene_id_dict[tran_id]
        for intron in introns:
            start, end = intron
            start_site_introns_dict[(_chr, strand, start)].add((_chr, strand, *intron))
            end_site_introns_dict[(_chr, strand, end)].add((_chr, strand, *intron))
            gene_introns_dict[gene_id].add((_chr, strand, *intron))
            intron_set.add((_chr, strand, *intron))

# filter out introns that share endpoints with other introns
selected_intron_set = set()
for intron in intron_set:
    _chr, strand, start, end = intron
    if len(start_site_introns_dict[(_chr, strand, start)]) == 1 and len(end_site_introns_dict[(_chr, strand, end)]) == 1:
        selected_intron_set.add(intron)

###############################################################################
file = '/ccb/salz3/florea/Hippocampus/Mnt_JULiP/all/sig_DS_overlaping_introns_new_2.txt'
with open(file, 'w') as f:
    f.write("gene_name\tchromosome\tstrand\tstart\tend\tc1\tc2\n")
    for gene_id, introns in gene_introns_dict.items():
        selected_introns = []
        for intron in introns:
            if intron in selected_intron_set:
                selected_introns.append(intron)
        intron_infos = []
        for intron in selected_introns:
            c1, c2, p_value = 0, 0, 1
            if intron in intron_values_dict:
                c1, c2, p_value = intron_values_dict[intron]
            intron_infos.append((*intron, c1, c2, p_value))
        if len(intron_infos) > 1:
            df = pd.DataFrame(intron_infos, columns=['chromosome', 'strand', 'start', 'end', 'c1', 'c2', 'p-value'])
            df = df.sort_values(['start', 'end'])
            df['group'] = ((df['end'].rolling(window=2, min_periods=1).min()
                          - df['start'].rolling(window=2, min_periods=1).max()) < 0).cumsum()
            df1 = df.groupby('group').filter(lambda x: len(x.index) > 1)
            # df2 = df1[df1['p-value'] < 0.05]
            for l in df1.values.tolist():
                # print(f"{gene_id_name_dict[gene_id]}\t{l[0]}\t{l[1]}\t{l[2]}\t{l[3]}\t{l[4]}\t{l[5]}\t{l[6]}\n")
                f.write(f"{gene_id_name_dict[gene_id]}\t{l[0]}\t{l[1]}\t{l[2]}\t{l[3]}\t{l[4]}\t{l[5]}\t{l[6]}\n")


# https://stackoverflow.com/questions/48243507/group-rows-by-overlapping-ranges
