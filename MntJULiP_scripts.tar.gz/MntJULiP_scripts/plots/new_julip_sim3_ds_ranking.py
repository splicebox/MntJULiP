# dict tran and fpkm
from collections import defaultdict
from scipy import stats
import matplotlib.pyplot as plt

import numpy as np


def get_introns(exons):
    if len(exons) <= 1:
        return []
    else:
        introns = []
        _list = sorted(exons)
        start = _list[0][1]
        for i in range(1, len(_list)):
            end = _list[i][0]
            introns.append((start, end))
            start = _list[i][1]
        return introns

######################
gtf_file = '/Users/gyang/test/annotation.gtf'
tran_exons_dict = defaultdict(list)
tran_chr_strand_dict = {}
with open(gtf_file, 'r') as f:
    for line in f:
        if line is not '\n':
            items = line.strip().split('\t')
            if items[2] == 'exon':
                _chr, strand = items[0], items[6]
                start, end = int(items[3]), int(items[4])
                _items = items[8].split('"')
                tran_id, gene_id = _items[3], _items[1]
                tran_exons_dict[tran_id].append((start, end))
                tran_chr_strand_dict[tran_id] = (_chr, strand)

intron_trans_dict = defaultdict(list)
for tran_id, exons in tran_exons_dict.items():
    introns = get_introns(exons)
    _chr, strand = tran_chr_strand_dict[tran_id]
    for intron in introns:
        intron_trans_dict[(_chr, strand, *intron)].append(tran_id)


######################
gene_file = '/Users/gyang/test/genes_info.txt'
tran_fpkm_control_dict = {}
tran_fpkm_case_dict = {}
gene_fpkm_control_dict = defaultdict(lambda: 0)
gene_fpkm_case_dict = defaultdict(lambda: 0)
tran_gene_dict = {}

DSR_chosen_trans = set()
DSA_chosen_trans = set()


with open(gene_file, 'r') as f:
    for line in f:
        items = line.strip().split('\t')
        gene_id = items[0]
        bool1, bool2, bool3 = [b == 'True' for b in items[3: 6]]
        if bool1 or bool2 or bool3:
            for item in items[6].split(', ')[:2]:
                tran_id, fpkm = item.strip().split(':')
                DSA_chosen_trans.add(tran_id)
        if bool1:
            for item in items[6].split(', ')[:2]:
                tran_id, fpkm = item.strip().split(':')
                DSR_chosen_trans.add(tran_id)

        for item in items[6].split(', '):
            tran_id, fpkm = item.strip().split(':')
            tran_fpkm_control_dict[tran_id] = float(fpkm)
            gene_fpkm_control_dict[gene_id] += float(fpkm)
            tran_gene_dict[tran_id] = gene_id

        for item in items[7].split(','):
            tran_id, fpkm = item.strip().split(':')
            tran_fpkm_case_dict[tran_id] = float(fpkm)
            gene_fpkm_case_dict[gene_id] += float(fpkm)

#######################################################  JULIP(DSR)  ######################################################
base_dir = '/Users/gyang/test/simulation_3_out/simulated_genes/'

file = base_dir + 'diff_spliced_groups.txt'
with open(file, 'r') as f:
    lines = f.readlines()

group_pvalue_dict = {}
for line in lines[1:]:
    group_id, _chr, _, strand, gene_name_str, _, _, p_value, q_value = line.strip().split('\t')
    group_pvalue_dict[group_id] = float(p_value)

file = base_dir + 'diff_spliced_introns.txt'
with open(file, 'r') as f:
    lines = f.readlines()

julip_intron_dpsis_dict = defaultdict(list)
julip_intron_pvalues_dict = defaultdict(list)
for line in lines[1:]:
    group_id, _chr, start, end, strand, _, _, _, dpsi = line.strip().split('\t')
    start, end, dpsi = int(start), int(end), float(dpsi)
    julip_intron_dpsis_dict[(_chr, strand, start, end)].append(dpsi)
    julip_intron_pvalues_dict[(_chr, strand, start, end)].append(group_pvalue_dict[group_id])

julip_intron_dpsi_dict = {}
julip_intron_pvalue_dict = {}
for intron, _list in julip_intron_dpsis_dict.items():
    julip_intron_dpsi_dict[intron] = max(julip_intron_dpsis_dict[intron], key=abs)
    julip_intron_pvalue_dict[intron] = np.min(julip_intron_pvalues_dict[intron])


###############################################################################
ref_intron_dpsi_dict = {}
_julip_intron_dpsi_dict = {}
for intron, trans in intron_trans_dict.items():
    # only consider the introns in common
    if intron not in julip_intron_dpsi_dict:
        continue

    cntrl_sum = 0
    case_sum = 0
    flag = False
    for tran_id in trans:
        if tran_id in DSR_chosen_trans:
            flag = True

        if tran_id in tran_fpkm_control_dict:
            cntrl_sum += tran_fpkm_control_dict[tran_id]

        if tran_id in tran_fpkm_case_dict:
            case_sum += tran_fpkm_case_dict[tran_id]

    if flag:
        gene_id = tran_gene_dict[tran_id]
        psi_cntrl = cntrl_sum / gene_fpkm_control_dict[gene_id]
        psi_case = case_sum / gene_fpkm_case_dict[gene_id]
        ref_intron_dpsi_dict[intron] = psi_cntrl - psi_case
        _julip_intron_dpsi_dict[intron] = julip_intron_dpsi_dict[intron]

ref_ranked_introns = sorted(ref_intron_dpsi_dict.items(), key=lambda kv: abs(kv[1]), reverse=True)
ref_intron_rank_dict = {}
for i, (intron, dpsi) in enumerate(ref_ranked_introns):
    ref_intron_rank_dict[intron] = i + 1

julip_ranked_introns = sorted(_julip_intron_dpsi_dict.items(), key=lambda kv: abs(kv[1]), reverse=True)
julip_intron_rank_dict = {}
for i, (intron, dpsi) in enumerate(julip_ranked_introns):
    julip_intron_rank_dict[intron] = i + 1

###############################################################################
x1 = []
x2 = []
y1 = []
y2 = []
x = []
y = []

for intron, ref_rank in ref_intron_rank_dict.items():
    p_value = julip_intron_pvalue_dict[intron]
    dpsi = julip_intron_dpsi_dict[intron]
    julip_rank = julip_intron_rank_dict[intron]
    x.append(julip_rank)
    y.append(ref_rank)
    if p_value <= 0.1 and abs(dpsi) >= 0.05:
        x1.append(julip_rank)
        y1.append(ref_rank)
    else:
        x2.append(julip_rank)
        y2.append(ref_rank)

plt.figure(num=None, figsize=(10, 8), dpi=86, facecolor='w', edgecolor='k')
plt.scatter(x1, y1, color='red', label=r'$p\_value \leq 0.1, |dPSI| \geq 0.05$', s=10)
plt.scatter(x2, y2, color='blue', label='Others', s=10)
legend = plt.legend(loc='upper left')
legend.legendHandles[0]._sizes = [10]
legend.legendHandles[1]._sizes = [10]
plt.ylabel("Reference (rank)")
plt.xlabel("MntJULiP (rank)")

out_dir = '/Users/gyang/OneDrive/1-Florea Lab/New_JULiP_Paper/Figures/simulated_data/'
file = out_dir + 'julip_sim_DSR_ranking.png'
plt.savefig(file)
plt.close()

###############################################################################
from scipy.stats import wilcoxon
T, pval = wilcoxon(x, y)
print(pval)

#######################################################  JULIP(DSA)  ######################################################
base_dir = '/Users/gyang/test/simulation_3_out/simulated_genes/'
file = base_dir + 'diff_introns.txt'
with open(file, 'r') as f:
    lines = f.readlines()


julip_log2_change_dict = {}
julip_intron_log2_change_dict = {}
for line in lines[1:]:
    _chr, start, end, strand, gene_name, status, _, p_value, q_value, case, cntrl = line.strip().split('\t')
    if status == 'TEST':
        start, end, p_value, q_value = int(start), int(end), float(p_value), float(q_value)
        case, cntrl = float(case), float(cntrl)
        if case == 0 or cntrl == 0:
            continue
        julip_intron_log2_change_dict[(_chr, strand, start, end)] = np.log2(case / cntrl)
        julip_intron_pvalue_dict[(_chr, strand, start, end)] = p_value


###############################################################################
ref_intron_log2_change_dict = {}
_julip_intron_log2_change_dict = {}
for intron, trans in intron_trans_dict.items():
    if intron not in julip_intron_log2_change_dict:
        continue

    cntrl_sum = 0
    case_sum = 0
    flag = False
    for tran_id in trans:
        if tran_id in DSA_chosen_trans:
            flag = True

        if tran_id in tran_fpkm_control_dict:
            cntrl_sum += tran_fpkm_control_dict[tran_id]

        if tran_id in tran_fpkm_case_dict:
            case_sum += tran_fpkm_case_dict[tran_id]

    if flag:
        ref_intron_log2_change_dict[intron] = np.log2(case_sum / cntrl_sum)
        _julip_intron_log2_change_dict[intron] = julip_intron_log2_change_dict[intron]


ref_ranked_introns = sorted(ref_intron_log2_change_dict.items(), key=lambda kv: abs(kv[1]), reverse=True)
ref_intron_rank_dict = {}
for i, (intron, dpsi) in enumerate(ref_ranked_introns):
    ref_intron_rank_dict[intron] = i + 1

julip_ranked_introns = sorted(_julip_intron_log2_change_dict.items(), key=lambda kv: abs(kv[1]), reverse=True)
julip_intron_rank_dict = {}
for i, (intron, dpsi) in enumerate(julip_ranked_introns):
    julip_intron_rank_dict[intron] = i + 1

###############################################################################
x1 = []
x2 = []
y1 = []
y2 = []
x = []
y = []

for intron, ref_rank in ref_intron_rank_dict.items():
    p_value = julip_intron_pvalue_dict[intron]
    julip_rank = julip_intron_rank_dict[intron]
    x.append(julip_rank)
    y.append(ref_rank)
    if p_value <= 0.1:
        x1.append(julip_rank)
        y1.append(ref_rank)
    else:
        x2.append(julip_rank)
        y2.append(ref_rank)

plt.figure(num=None, figsize=(10, 8), dpi=86, facecolor='w', edgecolor='k')
plt.scatter(x1, y1, color='red', label=r'$p\_value \leq 0.1$', s=10)
plt.scatter(x2, y2, color='blue', label='Others', s=10)
legend = plt.legend(loc='upper left')
legend.legendHandles[0]._sizes = [10]
legend.legendHandles[1]._sizes = [10]
plt.ylabel("Reference (rank)")
plt.xlabel("MntJULiP (rank)")

out_dir = '/Users/gyang/OneDrive/1-Florea Lab/New_JULiP_Paper/Figures/simulated_data/'
file = out_dir + 'julip_sim_DSA_ranking.png'
plt.savefig(file)
plt.close()

###############################################################################
from scipy.stats import wilcoxon
T, pval = wilcoxon(x, y)
print(pval)
