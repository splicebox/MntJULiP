library( "DESeq2" )
library( "GenomicFeatures" )
library( "Rsamtools" )
library( "GenomicAlignments" )

fls <- list.files( "/ccb/salz3/florea/Hippocampus/bams", pattern="bam$", full=TRUE )  ##

hse <- makeTxDbFromGFF( "/ccb/salz3/florea/Hippocampus/gencode.vM17.annotation.gtf", format="gtf" ) ##
exonsByGene <- exonsBy( hse, by="gene" )
fls_subset <- fls[c(1:42)] ##

bamLst <- BamFileList( fls_subset, yieldSize=100000 )

se <- summarizeOverlaps(features=exonsByGene, reads=bamLst, mode="Union", singleEnd=FALSE, ignore.strand=TRUE, fragments=TRUE)

sampleInfo <- read.csv( "pheno_all.csv" ) ##

seIdx <- match(colnames(se), sampleInfo$sample)
head( cbind( colData(se), sampleInfo[ seIdx, ] ) )
colData(se) <- cbind( colData(se), sampleInfo[ seIdx, ] )

dds <- DESeqDataSet( se, design = ~ condition)
dds$condition <- relevel( dds$condition, "control" )
dds <- DESeq(dds)
res <- results(dds)

res_pval0.05 <-res[ which(res$pvalue <= 0.05 ), ]
res_qval0.05 <-res[ which(res$padj <= 0.05 ), ]

write.csv( as.data.frame(res), file="results_all.csv" ) ##
write.csv( as.data.frame(res_pval0.05), file="results_all.pval05.csv" ) ##
write.csv( as.data.frame(res_qval0.05), file="results_all.qval05.csv" ) ##
