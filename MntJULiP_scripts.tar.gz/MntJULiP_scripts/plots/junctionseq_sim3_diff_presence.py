# dict tran and fpkm
from collections import defaultdict
from scipy import stats
import matplotlib.pyplot as plt

import numpy as np


def get_introns(exons):
    if len(exons) <= 1:
        return []
    else:
        introns = []
        _list = sorted(exons)
        start = _list[0][1]
        for i in range(1, len(_list)):
            end = _list[i][0]
            introns.append((start, end))
            start = _list[i][1]
        return introns

######################
gtf_file = '/Users/gyang/test/annotation.gtf'
tran_exons_dict = defaultdict(list)
tran_chr_strand_dict = {}
gene_id_chr_strand = {}
with open(gtf_file, 'r') as f:
    for line in f:
        if line is not '\n':
            items = line.strip().split('\t')
            if items[2] == 'exon':
                _chr, strand = items[0], items[6]
                start, end = int(items[3]), int(items[4])
                _items = items[8].split('"')
                tran_id, gene_id = _items[3], _items[1]
                tran_exons_dict[tran_id].append((start, end))
                tran_chr_strand_dict[tran_id] = (_chr, strand)
                gene_id_chr_strand[gene_id] = (_chr, strand)

intron_trans_dict = defaultdict(list)
for tran_id, exons in tran_exons_dict.items():
    introns = get_introns(exons)
    _chr, strand = tran_chr_strand_dict[tran_id]
    for intron in introns:
        intron_trans_dict[(_chr, strand, *intron)].append(tran_id)


######################
gene_file = '/Users/gyang/test/genes_info.txt'
tran_fpkm_control_dict = {}
tran_fpkm_case_dict = {}
gene_fpkm_control_dict = defaultdict(lambda: 0)
gene_fpkm_case_dict = defaultdict(lambda: 0)
tran_gene_dict = {}

with open(gene_file, 'r') as f:
    for line in f:
        items = line.strip().split('\t')
        gene_id = items[0]
        # bool1, bool2, bool3 = [b == 'True' for b in items[3: 6]]
        for item in items[6].split(', '):
            tran_id, fpkm = item.strip().split(':')
            tran_fpkm_control_dict[tran_id] = float(fpkm)
            tran_gene_dict[tran_id] = gene_id

        for item in items[7].split(','):
            tran_id, fpkm = item.strip().split(':')
            tran_fpkm_case_dict[tran_id] = float(fpkm)


########################################################  JunctionSeq  #######################################################
import gzip

file = '/Users/gyang/test/JunctionSeq/allGenes.results.txt.gz'
with gzip.open(file, 'rb') as f:
    lines = f.readlines()

junctionseq_log2_change_dict = {}
junctionseq_pvalue_dict = {}
for line in lines[1:]:
    items = line.decode('utf8').strip().split('\t')
    gene_id, bin_id, status = items[1], items[2], items[4]
    if bin_id.startswith('J') and status == 'OK':
        p_value, q_value = float(items[11]), float(items[12])
        start, end = int(items[14]), int(items[15]) + 1
        case, cntrl = float(items[22]), float(items[23])
        if case == 0 or cntrl == 0:
            continue
        _chr, strand = gene_id_chr_strand[gene_id]
        junctionseq_log2_change_dict[(_chr, strand, start, end)] = np.log2(case / cntrl)
        junctionseq_pvalue_dict[(_chr, strand, start, end)] = p_value

ref_log2_change_dict = {}
for intron, trans in intron_trans_dict.items():
    if intron not in junctionseq_log2_change_dict:
        continue

    cntrl_sum = 0
    case_sum = 0
    for tran_id in trans:
        if tran_id in tran_fpkm_control_dict:
            cntrl_sum += tran_fpkm_control_dict[tran_id]

        if tran_id in tran_fpkm_case_dict:
            case_sum += tran_fpkm_case_dict[tran_id]

    # this works because a intron only belong to one gene in our annotation.
    gene_id = tran_gene_dict[tran_id]
    if case_sum == 0 or cntrl_sum == 0:
        continue
    ref_log2_change_dict[intron] = np.log2(case_sum / cntrl_sum)

#############
x = []
y = []
for intron, ref_change in ref_log2_change_dict.items():
    change = junctionseq_log2_change_dict[intron]
    p_value = junctionseq_pvalue_dict[intron]
    if p_value < 1e-16:
        p_value = 1e-16
    x.append(ref_change)
    y.append(-np.log2(p_value))

plt.figure(num=None, figsize=(10, 8), dpi=86, facecolor='w', edgecolor='k')
plt.scatter(x, y, color='red', s=5)
plt.xlabel(r"Reference ($log_2$ fold change)")
plt.ylabel(r"JunctionSeq ($-log_2$(p_value))")
plt.ylim((0, 59))
plt.xlim((-5, 5.1))
plt.xticks(np.arange(-5, 5.1, 1))
plt.yticks(np.arange(0, 55.1, 5))
plt.axhline(y=-np.log(0.1), linestyle='dotted', label='p_value=0.1')
legend = plt.legend(loc='upper right')
legend.legendHandles[0]._sizes = [10]
# plt.show()

fiout_dir = '/Users/gyang/OneDrive/1-Florea Lab/New_JULiP_Paper/Figures/simulated_data/'
le = out_dir + 'junctionseq_sim_presence_pvalue.png'
plt.savefig(file)
plt.close()

#############
x1 = []
y1 = []
x2 = []
y2 = []
for intron, ref_change in ref_log2_change_dict.items():
    change = junctionseq_log2_change_dict[intron]
    p_value = junctionseq_pvalue_dict[intron]
    if p_value < 0.1:
        x1.append(change)
        y1.append(ref_change)
    else:
        x2.append(change)
        y2.append(ref_change)

plt.figure(num=None, figsize=(10, 8), dpi=86, facecolor='w', edgecolor='k')
plt.scatter(x1, y1, color='red', label=r'$p\_value \leq 0.1$', s=5)
plt.scatter(x2, y2, color='blue', label='Others', s=5)
plt.ylabel(r"Reference ($log_2$ fold change)")
plt.xlabel(r"JunctionSeq ($log_2$ fold change)")
legend = plt.legend(loc='upper left')
legend.legendHandles[0]._sizes = [10]
legend.legendHandles[1]._sizes = [10]
plt.ylim((-5, 5.1))
plt.xlim((-5, 5.1))
plt.yticks(np.arange(-5, 5.1, 1))
plt.xticks(np.arange(-5, 5.1, 1))
# plt.show()

file = out_dir + 'junctionseq_sim_presence.png'
plt.savefig(file)
plt.close()
