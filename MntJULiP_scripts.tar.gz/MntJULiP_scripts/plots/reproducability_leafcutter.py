import matplotlib.pyplot as plt
from collections import defaultdict
import numpy as np


##################################################. LeafCutter  #########################################################
base_dir = '/ccb/salz3/florea/Hippocampus/'
file = base_dir + 'LeafCutter/results_dataset_A/leafcutter_ds_cluster_significance.txt'
with open(file, 'r') as f:
    lines = f.readlines()

cluster_pvalue_dict = {}
cluster_qvalue_dict = {}
for line in lines[1:]:
    cluster, status, _, _, p_value, q_value, gene_name = line.strip().split('\t')
    if status == 'Success':
        _chr, cluster_id = cluster.split(':')
        p_value, q_value = float(p_value), float(q_value)
        cluster_pvalue_dict[cluster_id] = p_value
        cluster_qvalue_dict[cluster_id] = q_value

######### diff genes
file = base_dir + 'LeafCutter/results_dataset_A/leafcutter_ds_effect_sizes.txt'
with open(file, 'r') as f:
    lines = f.readlines()

intron_dpsis_dict = defaultdict(list)
for line in lines[1:]:
    # intron  logef   case    control deltapsi
    intron_info, _, _, _, dpsi = line.strip().split('\t')
    dpsi = float(dpsi)
    _chr, start, end, cluster_id = intron_info.split(':')
    p_value = cluster_pvalue_dict[cluster_id]
    intron_dpsis_dict[(_chr, start, end)].append(dpsi)

intron_dpsi_dict_A = {}
for intron, dpsi_list in intron_dpsis_dict.items():
    intron_dpsi_dict_A[intron] = max(dpsi_list, key=abs)

###################
file = base_dir + 'LeafCutter/results_dataset_D/leafcutter_ds_cluster_significance.txt'
with open(file, 'r') as f:
    lines = f.readlines()

cluster_pvalue_dict = {}
cluster_qvalue_dict = {}
for line in lines[1:]:
    cluster, status, _, _, p_value, q_value, gene_name = line.strip().split('\t')
    if status == 'Success':
        _chr, cluster_id = cluster.split(':')
        p_value, q_value = float(p_value), float(q_value)
        cluster_pvalue_dict[cluster_id] = p_value
        cluster_qvalue_dict[cluster_id] = q_value

######### diff genes
file = base_dir + 'LeafCutter/results_dataset_D/leafcutter_ds_effect_sizes.txt'
with open(file, 'r') as f:
    lines = f.readlines()

intron_dpsis_dict = defaultdict(list)
for line in lines[1:]:
    # intron  logef   case    control deltapsi
    intron_info, _, _, _, dpsi = line.strip().split('\t')
    dpsi = float(dpsi)
    _chr, start, end, cluster_id = intron_info.split(':')
    p_value = cluster_pvalue_dict[cluster_id]
    intron_dpsis_dict[(_chr, start, end)].append(dpsi)

intron_dpsi_dict_D = {}
for intron, dpsi_list in intron_dpsis_dict.items():
    intron_dpsi_dict_D[intron] = max(dpsi_list, key=abs)


x = []
y = []

for intron, dpsi_A in intron_dpsi_dict_A.items():
    if intron in intron_dpsi_dict_D:
        dpsi_D = intron_dpsi_dict_D[intron]
        x.append(dpsi_A)
        y.append(dpsi_D)

plt.figure(num=None, figsize=(10, 8), dpi=86, facecolor='w', edgecolor='k')
plt.scatter(x, y, color='blue', s=5)
# legend = plt.legend(loc='upper left')
# legend.legendHandles[0]._sizes = [10]
plt.xlabel("dataset_A (dPSI)")
plt.ylabel("dataset_D (dPSI)")
plt.ylim((-0.5, 0.51))
plt.xlim((-0.5, 0.51))
plt.yticks(np.arange(-0.5, 0.51, 0.1))
plt.xticks(np.arange(-0.5, 0.51, 0.1))
plt.axhline(y=0.05, linestyle='dotted')
plt.axhline(y=-0.05, linestyle='dotted')
plt.axvline(x=0.05, linestyle='dotted')
plt.axvline(x=-0.05, linestyle='dotted')
# plt.show()

file = '/ccb/salz3/florea/Hippocampus/results/reproducability_leafcutter.png'
plt.savefig(file)
plt.close()

###############################################################################
dpsis_A = []
dpsis_D = []
for intron, dpsi in intron_dpsi_dict_A.items():
    if intron in intron_dpsi_dict_D:
        dpsis_A.append(dpsi)
        dpsis_D.append(intron_dpsi_dict_D[intron])

print(np.corrcoef(dpsis_A, dpsis_D))
