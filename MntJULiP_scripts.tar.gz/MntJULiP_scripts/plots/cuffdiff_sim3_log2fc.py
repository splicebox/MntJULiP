# dict tran and fpkm
from collections import defaultdict
from scipy import stats
import matplotlib.pyplot as plt

import numpy as np

base_dir = '/ccb/salz3/gyang/simulation3/'
gene_file = base_dir + 'meta_info/genes_info.txt'
ref_tran_fpkm_control_dict = {}
ref_tran_fpkm_case_dict = {}

diff_trans = set()

with open(gene_file, 'r') as f:
    for line in f:
        items = line.strip().split('\t')
        gene_id = items[0]
        bool1, bool2, bool3 = [b == 'True' for b in items[3: 6]]


        for item in items[6].split(', '):
            tran_id, fpkm = item.strip().split(':')
            ref_tran_fpkm_control_dict[tran_id] = float(fpkm)

        for item in items[7].split(','):
            tran_id, fpkm = item.strip().split(':')
            ref_tran_fpkm_case_dict[tran_id] = float(fpkm)

########################################################  CuffDiff  #######################################################
# file = base_dir + 'Cuffdiff/annotation/isoform_exp.diff'
file = base_dir + 'Cuffdiff/stmerged/isoform_exp.diff'

with open(file, 'r') as f:
    lines = f.readlines()

pairs = []
ref_log2fcs = []
cuffdiff_log2fscs = []

ref_diff_log2fcs = []
cuffdiff_diff_log2fscs = []

for line in lines[1:]:
    # test_id   gene_id gene locus sample_1    sample_2    status  value_1 value_2 log2(fold_change)   test_stat   p_value q_value significant
    tran_id, gene_id, gene_name, locus, _, _, status, v1, v2, log2fc, _, p_value, q_value, _ = line.strip().split('\t')
    if status == 'OK' and tran_id in ref_tran_fpkm_control_dict:
        log2fc, p_value = float(log2fc), float(p_value)
        ref_log2fc = float('inf')
        if ref_tran_fpkm_control_dict[tran_id] != 0:
            ref_log2fc = np.log2(ref_tran_fpkm_case_dict[tran_id] / ref_tran_fpkm_control_dict[tran_id])

        pairs.append((ref_log2fc, log2fc, p_value))

        if ref_log2fc != float('inf') and abs(log2fc) != float('inf'):
            ref_log2fcs.append(ref_log2fc)
            cuffdiff_log2fscs.append(log2fc)


#############
x1 = []
x2 = []
y1 = []
y2 = []

for ref_log2fc, log2fc, p_value in pairs:
    if p_value > 0.1:
        x1.append(log2fc)
        y1.append(ref_log2fc)
    else:
        x2.append(log2fc)
        y2.append(ref_log2fc)

plt.figure(num=None, figsize=(10, 8), dpi=86, facecolor='w', edgecolor='k')
plt.scatter(x1, y1, color='blue', label=r'$p-value \geq 0.1$', s=10)
plt.scatter(x2, y2, color='red', label=r'$p-value < 0.1 $', s=10)
legend = plt.legend(loc='upper left')
legend.legendHandles[0]._sizes = [10]
legend.legendHandles[1]._sizes = [10]
plt.ylabel("Reference (log2fc)")
plt.xlabel("Cuffdiff2 (log2fc)")
plt.ylim((-5, 5))
plt.xlim((-5, 5))
# plt.yticks(np.arange(-1, 1.01, 0.1))
# plt.xticks(np.arange(-1, 1.01, 0.1))
# plt.show()

# file = '/ccb/salz3/gyang/cuffdiff_log2fc_isoforms.png'
file = '/ccb/salz3/gyang/simulation3/stmerged_figures/cuffdiff_log2fc_isoforms.png'

plt.savefig(file)
plt.close()


np.corrcoef(np.array(ref_log2fcs), np.array(cuffdiff_log2fscs))
