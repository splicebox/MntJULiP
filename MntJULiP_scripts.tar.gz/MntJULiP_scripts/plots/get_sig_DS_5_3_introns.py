# dict tran and fpkm
from collections import defaultdict
from scipy import stats
import matplotlib.pyplot as plt

import numpy as np

import numpy as np
import matplotlib.mlab as mlab
import matplotlib.pyplot as plt


def get_introns(exons):
    if len(exons) <= 1:
        return []
    else:
        introns = []
        _list = sorted(exons)
        start = _list[0][1]
        for i in range(1, len(_list)):
            end = _list[i][0]
            introns.append((start, end))
            start = _list[i][1]
        return introns


# read exon info from the file.
tran_exons_dict = defaultdict(list)
gtf_file = '/ccb/salz3/florea/Hippocampus/gencode.vM17.annotation.gtf'
gene_id_name_dict = {}
tran_exons_dict = defaultdict(list)
tran_gene_id_dict = {}
with open(gtf_file, 'r') as f:
    for line in f:
        if line is not '\n' and not(line.startswith('#')):
            items = line.strip().split('\t')
            if items[2] == 'exon':
                _chr, strand = items[0], items[6]
                start, end = items[3: 5]
                _items = items[8].split('"')
                tran_id, gene_id = _items[3], _items[1]
                gene_id, gene_name = _items[1], _items[7]
                tran_exons_dict[(_chr, strand, tran_id)].append((int(start), int(end)))
                gene_id_name_dict[gene_id] = gene_name
                tran_gene_id_dict[tran_id] = gene_id

###############################################################################
file = '/ccb/salz3/florea/Hippocampus/Mnt_JULiP/all/diff_introns.txt'
with open(file, 'r') as f:
    lines = f.readlines()

intron_values_dict = {}
gene_dict = defaultdict(lambda: np.zeros(2))
for line in lines[1:]:
    items = line.strip().split('\t')
    _chr, start, end, strand, gene_names_str, status, _, p_value, q_value, c1, c2 = line.strip().split('\t')
    if status == 'TEST' and gene_names_str != '.':
        start, end, p_value, q_value = int(start), int(end), float(p_value), float(q_value)
        c1, c2 = float(c1), float(c2)
        if c1 > 1 or c2 > 1:
            intron_values_dict[(_chr, strand, start, end)] = (c1, c2, p_value)

###############################################################################
# note: only consider the expressed introns
gene_first_introns_dict = defaultdict(set)
gene_last_introns_dict = defaultdict(set)
gene_introns_dict = defaultdict(set)
start_site_introns_dict = defaultdict(set)
end_site_introns_dict = defaultdict(set)
for (_chr, strand, tran_id), exons in tran_exons_dict.items():
    introns = get_introns(exons)
    if introns:
        gene_id = tran_gene_id_dict[tran_id]

        start_intron = (_chr, strand, *(introns[0]))
        if start_intron in intron_values_dict:
            gene_first_introns_dict[gene_id].add(start_intron)

        end_intron = (_chr, strand, *(introns[-1]))
        if end_intron in intron_values_dict:
            gene_last_introns_dict[gene_id].add(end_intron)

        for intron in introns:
            if (_chr, strand, *intron) in intron_values_dict:
                start, end = intron
                start_site_introns_dict[(_chr, strand, start)].add((_chr, strand, *intron))
                end_site_introns_dict[(_chr, strand, end)].add((_chr, strand, *intron))
                gene_introns_dict[gene_id].add((_chr, strand, *intron))

###############################################################################

gene_uniq_first_introns_dict = defaultdict(set)
for gene_id, introns in gene_first_introns_dict.items():
    for intron in sorted(list(introns), key=lambda x: x[-2])[:-1]:
        _chr, strand, start, end = intron
        flag1 = len(end_site_introns_dict[(_chr, strand, end)]) == 1
        flag2 = len(start_site_introns_dict[(_chr, strand, start)]) == 1
        if flag1 and flag2:
            gene_uniq_first_introns_dict[gene_id].add(intron)


gene_uniq_last_introns_dict = defaultdict(set)
for gene_id, introns in gene_last_introns_dict.items():
    for intron in sorted(list(introns),reverse=True, key=lambda x: x[-1])[:-1]:
        _chr, strand, start, end = intron
        flag1 = len(end_site_introns_dict[(_chr, strand, end)]) == 1
        flag2 = len(start_site_introns_dict[(_chr, strand, start)]) == 1
        if flag1 and flag2:
            gene_uniq_last_introns_dict[gene_id].add(intron)

###############################################################################
from scipy.stats import chi2_contingency

gene_id_introns_dict = defaultdict(set)
for gene_id, introns in gene_introns_dict.items():
    values1 = []
    values2 = []
    for intron in introns:
        if intron in intron_values_dict:
            (c1, c2, p_value) = intron_values_dict[intron]
            if values1 and (values1[-1] == 0 or values2[-1] == 0) == 0:
                values1[-1] += c1
                values2[-1] += c2
            else:
                values1.append(c1)
                values2.append(c2)
    if len(values1) > 1 and (values1[-1] == 0 or values2[-1]) == 0:
        values1[-2] += values1[-1]
        values2[-2] += values2[-1]
        del values1[-1]
        del values2[-1]

    if len(values1) > 0 and values1[-1] > 0 and values2[-1] > 0:
        obs = np.array([values1, values2])
        chi2, p, dof, ex = chi2_contingency(obs, correction=False)
        if p > 0.1:
            for intron in gene_uniq_first_introns_dict[gene_id]:
                if intron in intron_values_dict and intron_values_dict[intron][2] < 0.05:
                    gene_id_introns_dict[gene_id].add(intron)
            for intron in gene_uniq_last_introns_dict[gene_id]:
                if intron in intron_values_dict and intron_values_dict[intron][2] < 0.05:
                    gene_id_introns_dict[gene_id].add(intron)

# for gene_id, introns in gene_id_introns_dict.items():
#     print(gene_id, len(introns))

# print(len(gene_id_introns_dict))

###############################################################################
file = '/ccb/salz3/florea/Hippocampus/Mnt_JULiP/all/sig_DS_5_3_introns_with_genename_new.txt'
with open(file, 'w') as f:
    f.write("gene_id\tchromosome\tstrand\tstart\tend\tc1\tc2\n")
    for gene_id, introns in gene_id_introns_dict.items():
        for intron in introns:
            _chr, strand, start, end = intron
            (c1, c2, p_value) = intron_values_dict[intron]
            f.write(f"{gene_id_name_dict[gene_id]}\t{_chr}\t{strand}\t{start}\t{end}\t{c1}\t{c2}\n")

###############################################################################
file = '/ccb/salz3/florea/Hippocampus/DESeq/results_all.csv'
with open(file, 'r') as f:
    lines = f.readlines()

deseq_gene_dict = {}
for line in lines[1:]:
    items = line.strip().split(',')
    gene_id, pvalue = items[0], items[-2]
    if pvalue != 'NA' and float(pvalue) > 0.1:
        deseq_gene_dict[gene_id[1:-1]] = float(pvalue)

file = '/ccb/salz3/florea/Hippocampus/Mnt_JULiP/all/sig_DS_5_3_introns_with_genename_new_deseq.txt'
with open(file, 'w') as f:
    f.write("gene_id\tchromosome\tstrand\tstart\tend\tc1\tc2\tdeseq_pvalue\n")
    for gene_id, introns in gene_id_introns_dict.items():
        if gene_id not in deseq_gene_dict:
            continue

        deseq_pvalue = deseq_gene_dict[gene_id]
        for intron in introns:
            _chr, strand, start, end = intron
            (c1, c2, p_value) = intron_values_dict[intron]
            f.write(f"{gene_id_name_dict[gene_id]}\t{_chr}\t{strand}\t{start}\t{end}\t{c1}\t{c2}\t{deseq_pvalue}\n")
