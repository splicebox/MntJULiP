# dict tran and fpkm
from collections import defaultdict
from scipy import stats
import matplotlib.pyplot as plt

import numpy as np


tran_exons_dict = defaultdict(list)
gtf_file = '/Users/gyang/test/annotation.gtf'
chr_strand_tran_exons_dict = defaultdict(lambda: defaultdict(lambda: defaultdict(list)))
gene_chr_strand_dict = {}
with open(gtf_file, 'r') as f:
    for line in f:
        if line is not '\n':
            items = line.strip().split('\t')
            if items[2] == 'exon':
                _chr, strand = items[0], items[6]
                start, end = items[3: 5]
                _items = items[8].split('"')
                tran_id, gene_id = _items[3], _items[1]
                chr_strand_tran_exons_dict[_chr][strand][tran_id].append((int(start), int(end)))
                gene_chr_strand_dict[gene_id] = (_chr, strand)

chrs = list(chr_strand_tran_exons_dict.keys())


def get_introns(exons):
    if len(exons) <= 1:
        return []
    else:
        introns = []
        _list = sorted(exons)
        start = _list[0][1]
        for i in range(1, len(_list)):
            end = _list[i][0]
            introns.append((start, end))
            start = _list[i][1]
        return introns


chr_strand_tran_introns_dict = defaultdict(lambda: defaultdict(lambda: defaultdict(list)))
chr_strand_intron_trans_dict = defaultdict(lambda: defaultdict(lambda: defaultdict(list)))
for _chr in chrs:
    for strand in ['-', '+']:
        for tran_id, exons in chr_strand_tran_exons_dict[_chr][strand].items():
            introns = get_introns(exons)
            chr_strand_tran_introns_dict[_chr][strand][tran_id] = introns
            for intron in introns:
                chr_strand_intron_trans_dict[_chr][strand][intron].append(tran_id)


gene_file = '/Users/gyang/test/genes_info.txt'
tran_fpkm_control_dict = {}
tran_fpkm_case_dict = {}
chosen_tran_set = set()
gene_fpkm_control_dict = defaultdict(lambda: 0)
gene_fpkm_case_dict = defaultdict(lambda: 0)
tran_gene_dict = {}

with open(gene_file, 'r') as f:
    for line in f:
        items = line.strip().split('\t')
        gene_id = items[0]
        _chr, strand = gene_chr_strand_dict[gene_id]
        bool1, bool2, bool3 = [b == 'True' for b in items[3: 6]]
        if bool1 and not(bool2) and not(bool3):  # only swapped the top two trans' expr
            for item in items[6].split(', ')[:1]:
                tran_id, fpkm = item.strip().split(':')
                # tran_fpkm_control_dict[tran_id] = float(fpkm)
                chosen_tran_set.add(tran_id)

        for item in items[6].split(', '):
            tran_id, fpkm = item.strip().split(':')
            tran_fpkm_control_dict[tran_id] = float(fpkm)
            gene_fpkm_control_dict[gene_id] += float(fpkm)
            tran_gene_dict[tran_id] = gene_id

        for item in items[7].split(','):
            tran_id, fpkm = item.strip().split(':')
            tran_fpkm_case_dict[tran_id] = float(fpkm)
            gene_fpkm_case_dict[gene_id] += float(fpkm)

########################################################. JULIP  #######################################################

base_dir = '/Users/gyang/test/simulation_3_out/'
file = base_dir + 'diff_spliced_groups.txt'
with open(file, 'r') as f:
    lines = f.readlines()

group_pvalue_dict = {}
for line in lines[1:]:
    group_id, _chr, _, strand, gene_name_str, _, _, p_value, q_value = line.strip().split('\t')
    group_pvalue_dict[group_id] = float(p_value)

file = base_dir + 'diff_spliced_introns.txt'
with open(file, 'r') as f:
    lines = f.readlines()

_julip_intron_dpsi_dict = defaultdict(list)
for line in lines[1:]:
    group_id, _chr, start, end, strand, gene_name_str, _, _, dpsi = line.strip().split('\t')
    start, end, dpsi = int(start), int(end), float(dpsi)
    _julip_intron_dpsi_dict[(_chr, strand, start, end)].append(abs(dpsi))

julip_intron_dpsi_dict = {}
for intron, _list in _julip_intron_dpsi_dict.items():
    julip_intron_dpsi_dict[intron] = max(_list)

intron_dpsi_dict = {}
_julip_intron_dpsi_dict = {}
for _chr in chrs:
    for strand in ['-', '+']:
        for intron, trans in chr_strand_intron_trans_dict[_chr][strand].items():
            if (_chr, strand, *intron) not in julip_intron_dpsi_dict:
                continue

            flag = False
            cntrl_sum = 0
            for tran_id in trans:
                if tran_id in chosen_tran_set:
                    flag = True
                if tran_id in tran_fpkm_control_dict:
                    cntrl_sum += tran_fpkm_control_dict[tran_id]

            case_sum = 0
            for tran_id in trans:
                if tran_id in tran_fpkm_case_dict:
                    case_sum += tran_fpkm_case_dict[tran_id]

            gene_id = tran_gene_dict[tran_id]
            psi_cntrl = cntrl_sum / gene_fpkm_control_dict[gene_id]
            psi_case = case_sum / gene_fpkm_case_dict[gene_id]
            dpsi = psi_cntrl - psi_case
            # dpsi = abs(psi_cntrl - psi_case)

            if flag:
                intron_dpsi_dict[(_chr, strand, *intron)] = dpsi
                _julip_intron_dpsi_dict[(_chr, strand, *intron)] = julip_intron_dpsi_dict[(_chr, strand, *intron)]

ranked_introns = sorted(intron_dpsi_dict.items(), key=lambda kv: kv[1])
length = len(ranked_introns)
intron_rank_dict = {}
for i, (intron, dpsi) in enumerate(ranked_introns):
    intron_rank_dict[intron] = length - i + 1

julip_ranked_introns = sorted(_julip_intron_dpsi_dict.items(), key=lambda kv: kv[1])
length = len(julip_ranked_introns)
julip_intron_rank_dict = {}
for i, (intron, dpsi) in enumerate(julip_ranked_introns):
    julip_intron_rank_dict[intron] = length - i + 1


diff_list = []
diff_dict = {}
x = []
y = []
for intron, rank in julip_intron_rank_dict.items():
    if intron in intron_rank_dict:
        diff_list.append(intron_rank_dict[intron] - rank)
        diff_dict[intron] = abs(intron_rank_dict[intron] - rank)
        x.append(rank)
        y.append(intron_rank_dict[intron])

plt.scatter(x, y)
plt.ylabel("reference")
plt.xlabel("new julip")
plt.show()

