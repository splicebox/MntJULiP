import matplotlib.pyplot as plt
from collections import defaultdict
import numpy as np

base_dir = '/ccb/salz3/florea/Hippocampus/'

##################################################  Mnt JULiP(DSA)  ########################################################
file = base_dir + 'Mnt_JULiP/dataset_A/diff_introns.txt'
with open(file, 'r') as f:
    lines = f.readlines()

intron_fcs_dict = defaultdict(list)
for line in lines[1:]:
    _chr, start, end, strand, gene_names_str, status, _, p_value, q_value, count1, count2 = line.strip().split('\t')
    if status == 'TEST':
        start, end, p_value = int(start), int(end), float(p_value)
        count1, count2 = float(count1), float(count2)
        intron_fcs_dict[(_chr, strand, start, end)].append(np.log2(count2+0.5)-np.log2(count1+0.5))

intron_fc_dict_A = {}
for intron, fc_list in intron_fcs_dict.items():
    intron_fc_dict_A[intron] = max(fc_list, key=abs)

################################
file = base_dir + 'Mnt_JULiP/dataset_D/diff_introns.txt'
with open(file, 'r') as f:
    lines = f.readlines()

intron_fcs_dict = defaultdict(list)
for line in lines[1:]:
    _chr, start, end, strand, gene_names_str, status, _, p_value, q_value, count1, count2 = line.strip().split('\t')
    if status == 'TEST':
        start, end, p_value = int(start), int(end), float(p_value)
        count1, count2 = float(count1), float(count2)
        intron_fcs_dict[(_chr, strand, start, end)].append(np.log2(count2+0.5)-np.log2(count1+0.5))

intron_fc_dict_D = {}
for intron, fc_list in intron_fcs_dict.items():
    intron_fc_dict_D[intron] = max(fc_list, key=abs)


x = []
y = []

for intron, fc_A in intron_fc_dict_A.items():
    if intron in intron_fc_dict_D:
        fc_D = intron_fc_dict_D[intron]
        x.append(fc_A)
        y.append(fc_D)

plt.figure(num=None, figsize=(10, 8), dpi=86, facecolor='w', edgecolor='k')
plt.scatter(x, y, color='blue', s=5)
# legend = plt.legend(loc='upper left')
# legend.legendHandles[0]._sizes = [10]
plt.xlabel("dataset_A (log2fc)")
plt.ylabel("dataset_D (log2fc)")
plt.ylim((-7, 7))
plt.xlim((-7, 7))
# plt.yticks(np.arange(-0.5, 0.51, 0.1))
# plt.xticks(np.arange(-0.5, 0.51, 0.1))
# plt.axhline(y=0.05, linestyle='dotted')
# plt.axhline(y=-0.05, linestyle='dotted')
# plt.axvline(x=0.05, linestyle='dotted')
# plt.axvline(x=-0.05, linestyle='dotted')
# plt.show()

file = '/ccb/salz3/florea/Hippocampus/results/reproducability_julip_DSA.png'
plt.savefig(file)
plt.close()

###############################################################################
fcs_A = []
fcs_D = []
for intron, fc in intron_fc_dict_A.items():
    if intron in intron_fc_dict_D:
        fcs_A.append(fc)
        fcs_D.append(intron_fc_dict_D[intron])

print(np.corrcoef(fcs_A, fcs_D))
