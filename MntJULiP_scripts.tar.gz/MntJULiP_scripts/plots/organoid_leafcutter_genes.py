from collections import defaultdict
import gzip
import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt

base_dir = "/ccb/salz3/gyang/DRA005238/LeafCutter"
sig_introns = set()
sig_genes = set()
cutoff = 0.05 ##############
for folder in ["2D_4D", "2D_6D", "2D_8D", "2D_10D", "2D_12D", "2D_14D", "4D_6D", "4D_8D", "4D_10D", "4D_12D", "4D_14D", "6D_8D", "6D_10D", "6D_12D", "6D_14D", "8D_10D", "8D_12D", "8D_14D", "10D_12D", "10D_14D", "12D_14D"]:
    file = f'{base_dir}/{folder}/leafcutter_ds_cluster_significance.txt'
    with open(file, 'r') as f:
        lines = f.readlines()

    cluster_pvalue_dict = {}
    cluster_gene_dict = {}
    for line in lines[1:]:
        cluster, status, _, _, p_value, q_value, gene_name_str = line.strip().split('\t')
        if status == 'Success':
            _chr, cluster_id = cluster.split(':')
            cluster_pvalue_dict[cluster_id] = float(p_value)
            cluster_gene_dict[cluster_id] = gene_name_str.split(',')

    #######
    file = f'{base_dir}/{folder}/leafcutter_ds_effect_sizes.txt'
    with open(file, 'r') as f:
        lines = f.readlines()

    for line in lines[1:]:
        # intron  logef   case    control deltapsi
        intron_info, _, _, _, dpsi = line.strip().split('\t')
        dpsi = float(dpsi)
        _chr, start, end, cluster_id = intron_info.split(':')
        start, end = int(start), int(end)
        if cluster_pvalue_dict[cluster_id] < 0.05 and dpsi > cutoff:
            sig_introns.add((_chr, start, end))
            sig_genes.update(cluster_gene_dict[cluster_id])

print(f"leafcutter :{len(sig_introns)} introns, {len(sig_genes)} genes")


def func(v):
    d1, d2 = v.split('/')
    d1, d2 = float(d1), float(d2)
    return None if d2 == 0 else d1 / d2


def custom_max(v1, v2):
    if not(v1) or not(v2):
        return v1 or v2
    return max(v1, v2)


sample_intron_dict = defaultdict(list)
for folder in ["2D_4D", "2D_6D", "2D_8D", "2D_10D", "2D_12D", "2D_14D", "4D_6D", "4D_8D", "4D_10D", "4D_12D", "4D_14D", "6D_8D", "6D_10D", "6D_12D", "6D_14D", "8D_10D", "8D_12D", "8D_14D", "10D_12D", "10D_14D", "12D_14D"]:
    file = f'{base_dir}/{folder}/results_perind.counts.gz'
    with gzip.open(file, 'rb') as f:
        lines = f.readlines()

    _, s1, s2, s3, s4 = lines[0].decode('UTF-8').strip().split(' ')
    intron_sample_dict = defaultdict(dict)
    for line in lines[1:]:
        _str, v1, v2, v3, v4 = line.decode('UTF-8').strip().split(' ')
        _chr, start, end, _  = _str.split(':')
        start, end = int(start), int(end)
        if (_chr, start, end) in sig_introns:
            if (_chr, start, end) in intron_sample_dict:
                _v1 = intron_sample_dict[(_chr, start, end)][s1]
                _v2 = intron_sample_dict[(_chr, start, end)][s2]
                _v3 = intron_sample_dict[(_chr, start, end)][s3]
                _v4 = intron_sample_dict[(_chr, start, end)][s4]
                intron_sample_dict[(_chr, start, end)][s1] = custom_max(_v1, v1)
                intron_sample_dict[(_chr, start, end)][s2] = custom_max(_v2, v2)
                intron_sample_dict[(_chr, start, end)][s3] = custom_max(_v3, v3)
                intron_sample_dict[(_chr, start, end)][s4] = custom_max(_v4, v4)
            else:
                intron_sample_dict[(_chr, start, end)] = {s1: func(v1), s2: func(v2), s3: func(v3), s4: func(v4)}

    for (_chr, start, end), _dict in intron_sample_dict.items():
        for s, v in _dict.items():
            sample_intron_dict[(s, _chr, start, end)].append(v)


def custom_mean(_list):
    _sum = count = 0
    for v in _list:
        if v:
            _sum += v
            count += 1
    return _sum / count if count else 0


intron_sample_dict = defaultdict(dict)
for (s, _chr, start, end), _list in sample_intron_dict.items():
    intron_sample_dict[(f'{_chr}_{start}_{end}')][s] = custom_mean(_list)


data_df = pd.DataFrame.from_dict(intron_sample_dict, orient='index')
data_df = data_df.rename(columns={'DRR075852.bam': '2D', 'DRR075859.bam': '2D', 'DRR075853.bam': '4D', 'DRR075860.bam': '4D', 'DRR075854.bam': '6D', 'DRR075861.bam': '6D', 'DRR075862.bam': '8D', 'DRR075855.bam': '8D', 'DRR075856.bam': '10D', 'DRR075863.bam': '10D', 'DRR075864.bam': '12D', 'DRR075857.bam': '12D', 'DRR075865.bam': '14D', 'DRR075858.bam': '14D'})

mask = data_df.isnull()
method = 'average'
metric = 'cityblock'
# file = '/ccb/salz3/gyang/DRA005238/LeafCutter/leafcutter_clustermap_0.5.png'
# figure = sns.clustermap(data_df.fillna(0.5), cmap="YlOrBr",
#                         metric=metric, method=method, mask=mask,
#                         yticklabels=False, xticklabels=True)
# figure.ax_heatmap.set_facecolor("lightgray")
# figure.savefig(file)
# plt.close()


file = f'/ccb/salz3/gyang/DRA005238/LeafCutter/leafcutter_clustermap_na0_dpsi{cutoff}.png'
figure = sns.clustermap(data_df.fillna(0), cmap="YlOrBr",
                        metric=metric, method=method, mask=mask,
                        yticklabels=False, xticklabels=True)
figure.ax_heatmap.set_facecolor("lightgray")
figure.savefig(file)
plt.close()
