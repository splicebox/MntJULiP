# dict tran and fpkm
from collections import defaultdict
from scipy import stats
import matplotlib.pyplot as plt

import numpy as np

import numpy as np
import matplotlib.mlab as mlab
import matplotlib.pyplot as plt
import pandas as pd


def get_introns(exons):
    if len(exons) <= 1:
        return []
    else:
        introns = []
        _list = sorted(exons)
        start = _list[0][1]
        for i in range(1, len(_list)):
            end = _list[i][0]
            introns.append((start, end))
            start = _list[i][1]
        return introns


# read exon info from the file.
tran_exons_dict = defaultdict(list)
base_dir = '/ccb/salz3/florea/Hippocampus/'
gtf_file = base_dir + 'gencode.vM17.annotation.gtf'
gene_id_name_dict = {}
tran_exons_dict = defaultdict(list)
tran_gene_id_dict = {}
with open(gtf_file, 'r') as f:
    for line in f:
        if line is not '\n' and not(line.startswith('#')):
            items = line.strip().split('\t')
            if items[2] == 'exon':
                _chr, strand = items[0], items[6]
                start, end = items[3: 5]
                _items = items[8].split('"')
                tran_id, gene_id = _items[3], _items[1]
                gene_id, gene_name = _items[1], _items[7]
                tran_exons_dict[(_chr, strand, tran_id)].append((int(start), int(end)))
                gene_id_name_dict[gene_id] = gene_name
                tran_gene_id_dict[tran_id] = gene_id

###############################################################################
file = base_dir + 'Mnt_JULiP/all/diff_introns.txt'
with open(file, 'r') as f:
    lines = f.readlines()

intron_values_dict = {}
gene_dict = defaultdict(lambda: np.zeros(2))
for line in lines[1:]:
    items = line.strip().split('\t')
    _chr, start, end, strand, gene_names_str, status, _, p_value, q_value, c1, c2 = line.strip().split('\t')
    if status == 'TEST' and gene_names_str != '.':
        start, end, p_value, q_value = int(start), int(end), float(p_value), float(q_value)
        c1, c2 = float(c1), float(c2)
        if c1 > 1 or c2 > 1:
            intron_values_dict[(_chr, strand, start, end)] = (c1, c2)

###############################################################################
# assign expressed introns to gene
gene_introns_dict = defaultdict(set)
for (_chr, strand, tran_id), exons in tran_exons_dict.items():
    introns = get_introns(exons)
    if introns:
        gene_id = tran_gene_id_dict[tran_id]
        for intron in introns:
            if (_chr, strand, *intron) in intron_values_dict:
                gene_introns_dict[gene_id].add((_chr, strand, *intron))


###############################################################################
file = base_dir + 'Mnt_JULiP/all/diff_introns.txt'
with open(file, 'r') as f:
    lines = f.readlines()

julip_DSA_introns = set()
intron_pvalue_dict = {}
for line in lines[1:]:
    # chrom start   end strand  gene_name   status  llr p_value q_value avg_read_counts(control)    avg_read_counts(epileptic)
    _chr, start, end, strand, gene_names_str, status, _, p_value, q_value, _, _ = line.strip().split('\t')
    if status == 'TEST':
        start, end, p_value, q_value = int(start), int(end), float(p_value), float(q_value)
        intron_pvalue_dict[(_chr, strand, start, end)] = p_value
        if p_value < 0.05:
            julip_DSA_introns.add((_chr, strand, start, end))


###############################################################################
from scipy import stats
def get_intron_paired(introns):
    for i in range(len(introns)-1):
        for j in range(i+1, len(introns)):
            (_, _, s1, e1), (_, _, s2, e2) = introns[i], introns[j]
            if s1 != s2 and e1 != e2 and s2 <= e1:
                yield (introns[i], introns[j])

sig_out_buffer = 'id\tgene_name\tchr\tstrand\tstart\tend\tc1\tc2\tchi_square_pvalue\tDSA_pvalue\n'
all_out_buffer = 'id\tgene_name\tchr\tstrand\tstart\tend\tc1\tc2\n'
i = 0
for gene_id, introns in gene_introns_dict.items():
    for (intron1, intron2) in get_intron_paired(sorted(introns)):
        i += 1
        _chr, strand, s1, e1 = intron1
        _chr, strand, s2, e2 = intron2
        c11, c12 = intron_values_dict[intron1]
        c21, c22 = intron_values_dict[intron2]
        all_out_buffer += f'{i}\t{gene_id_name_dict[gene_id]}\t{_chr}\t{strand}\t{s1}\t{e1}\t{c11}\t{c12}\n'
        all_out_buffer += f'{i}\t{gene_id_name_dict[gene_id]}\t{_chr}\t{strand}\t{s2}\t{e2}\t{c21}\t{c22}\n'

        oddsratio, p = stats.fisher_exact([[c11, c21], [c12, c22]])
        if p <= 0.05 and (intron1 in julip_DSA_introns or intron2 in julip_DSA_introns):
            v1 = intron_pvalue_dict[intron1] if intron1 in intron_pvalue_dict else 'NA'
            v2 = intron_pvalue_dict[intron2] if intron2 in intron_pvalue_dict else 'NA'
            sig_out_buffer += f'{i}\t{gene_id_name_dict[gene_id]}\t{_chr}\t{strand}\t{s1}\t{e1}\t{c11}\t{c12}\t{p}\t{v1}\n'
            sig_out_buffer += f'{i}\t{gene_id_name_dict[gene_id]}\t{_chr}\t{strand}\t{s2}\t{e2}\t{c21}\t{c22}\t{p}\t{v2}\n'


with open(base_dir + 'Mnt_JULiP/all/sig_paired_introns_with_DSA.txt', 'w') as f:
    f.write(sig_out_buffer)

with open(base_dir + 'Mnt_JULiP/all/all_paired_introns_with_DSA.txt', 'w') as f:
    f.write(all_out_buffer)
