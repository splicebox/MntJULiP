# dict tran and fpkm
from collections import defaultdict
from scipy import stats
import matplotlib.pyplot as plt

import numpy as np


def get_introns(exons):
    if len(exons) <= 1:
        return []
    else:
        introns = []
        _list = sorted(exons)
        start = _list[0][1]
        for i in range(1, len(_list)):
            end = _list[i][0]
            introns.append((start, end))
            start = _list[i][1]
        return introns

######################
gtf_file = '/Users/gyang/test/annotation.gtf'
tran_exons_dict = defaultdict(list)
tran_chr_strand_dict = {}
with open(gtf_file, 'r') as f:
    for line in f:
        if line is not '\n':
            items = line.strip().split('\t')
            if items[2] == 'exon':
                _chr, strand = items[0], items[6]
                start, end = int(items[3]), int(items[4])
                _items = items[8].split('"')
                tran_id, gene_id = _items[3], _items[1]
                tran_exons_dict[tran_id].append((start, end))
                tran_chr_strand_dict[tran_id] = (_chr, strand)

intron_trans_dict = defaultdict(list)
for tran_id, exons in tran_exons_dict.items():
    introns = get_introns(exons)
    _chr, strand = tran_chr_strand_dict[tran_id]
    for intron in introns:
        intron_trans_dict[(_chr, strand, *intron)].append(tran_id)

######################
gene_file = '/Users/gyang/test/genes_info.txt'
tran_fpkm_control_dict = {}
tran_fpkm_case_dict = {}
chosen_trans = set()
gene_fpkm_control_dict = defaultdict(lambda: 0)
gene_fpkm_case_dict = defaultdict(lambda: 0)
tran_gene_dict = {}

with open(gene_file, 'r') as f:
    for line in f:
        items = line.strip().split('\t')
        gene_id = items[0]
        bool1, bool2, bool3 = [b == 'True' for b in items[3: 6]]
        if bool1:
            for item in items[6].split(', ')[:2]:
                tran_id, fpkm = item.strip().split(':')
                chosen_trans.add(tran_id)

        for item in items[6].split(', '):
            tran_id, fpkm = item.strip().split(':')
            tran_fpkm_control_dict[tran_id] = float(fpkm)
            gene_fpkm_control_dict[gene_id] += float(fpkm)
            tran_gene_dict[tran_id] = gene_id

        for item in items[7].split(','):
            tran_id, fpkm = item.strip().split(':')
            tran_fpkm_case_dict[tran_id] = float(fpkm)
            gene_fpkm_case_dict[gene_id] += float(fpkm)


########################################################  MAJIQ  #######################################################

file = '/Users/gyang/test/voila_out_star/control_case.deltapsi.tsv'
with open(file, 'r') as f:
    lines = f.readlines()

majiq_intron_dpsi_dict = {}
majiq_intron_pvalue_dict = defaultdict(list)
for line in lines[1:]:
    items = line.strip().split('\t')
    dpsis = [float(v) for v in items[3].split(';')]
    intron_coords = [v.split('-') for v in items[17].split(';')]
    _chr, strand = items[15], items[16]
    for dpsi, (start, end) in zip(dpsis, intron_coords):
        start, end = int(start), int(end)
        majiq_intron_dpsi_dict[(_chr, strand, start, end)] = -dpsi

###############################################################################
ref_intron_dpsi_dict = {}
_majiq_intron_dpsi_dict = {}
for intron, trans in intron_trans_dict.items():
    # only consider the introns in common
    if intron not in majiq_intron_dpsi_dict:
        continue

    cntrl_sum = 0
    case_sum = 0
    flag = False
    for tran_id in trans:
        if tran_id in chosen_trans:
            flag = True

        if tran_id in tran_fpkm_control_dict:
            cntrl_sum += tran_fpkm_control_dict[tran_id]

        if tran_id in tran_fpkm_case_dict:
            case_sum += tran_fpkm_case_dict[tran_id]

    if flag:
        gene_id = tran_gene_dict[tran_id]
        psi_cntrl = cntrl_sum / gene_fpkm_control_dict[gene_id]
        psi_case = case_sum / gene_fpkm_case_dict[gene_id]
        ref_intron_dpsi_dict[intron] = psi_cntrl - psi_case
        _majiq_intron_dpsi_dict[intron] = majiq_intron_dpsi_dict[intron]

ref_ranked_introns = sorted(ref_intron_dpsi_dict.items(), key=lambda kv: abs(kv[1]), reverse=True)
ref_intron_rank_dict = {}
for i, (intron, dpsi) in enumerate(ref_ranked_introns):
    ref_intron_rank_dict[intron] = i + 1

majiq_ranked_introns = sorted(_majiq_intron_dpsi_dict.items(), key=lambda kv: abs(kv[1]), reverse=True)
majiq_intron_rank_dict = {}
for i, (intron, dpsi) in enumerate(majiq_ranked_introns):
    majiq_intron_rank_dict[intron] = i + 1

###############################################################################
x1 = []
x2 = []
y1 = []
y2 = []
x = []
y = []
for intron, ref_rank in ref_intron_rank_dict.items():
    dpsi = majiq_intron_dpsi_dict[intron]
    majiq_rank = majiq_intron_rank_dict[intron]
    x.append(majiq_rank)
    y.append(ref_rank)

    if abs(dpsi) >= 0.05:
        x1.append(majiq_rank)
        y1.append(ref_rank)
    else:
        x2.append(majiq_rank)
        y2.append(ref_rank)

plt.figure(num=None, figsize=(10, 8), dpi=86, facecolor='w', edgecolor='k')
plt.scatter(x1, y1, color='red', label=r'$|dPSI| \geq 0.05$', s=10)
plt.scatter(x2, y2, color='blue', label='Others', s=10)
legend = plt.legend(loc='upper left')
legend.legendHandles[0]._sizes = [10]
legend.legendHandles[1]._sizes = [10]
plt.ylabel("Reference (rank)")
plt.xlabel("MAJIQ (rank)")

file = '/Users/gyang/OneDrive/1-Florea Lab/New_JULiP_Paper/Figures/simulated_data/majiq_sim_ranking.png'
plt.savefig(file)
plt.close()

###############################################################################
from scipy.stats import wilcoxon
T, pval = wilcoxon(x, y)
print(pval)
