import matplotlib.pyplot as plt
from collections import defaultdict
import numpy as np

base_dir = '/ccb/salz3/florea/Hippocampus/'

##################################################  Mnt JULiP(DSR)  ########################################################
file = base_dir + 'Mnt_JULiP/dataset_A/diff_spliced_groups.txt'
with open(file, 'r') as f:
    lines = f.readlines()

group_p_values = {}
for line in lines[1:]:
    group_id, _chr, _, strand, gene_names_str, _, _, p_value, q_value = line.strip().split('\t')
    group_p_values[group_id] = float(p_value)

file = base_dir + 'Mnt_JULiP/dataset_A/diff_spliced_introns.txt'
with open(file, 'r') as f:
    lines = f.readlines()

intron_dpsis_dict = defaultdict(list)
for line in lines[1:]:
    group_id, _chr, start, end, strand, _, _, _, dpsi = line.strip().split('\t')
    start, end, dpsi = int(start), int(end), float(dpsi)
    p_value = group_p_values[group_id]
    intron_dpsis_dict[(_chr, strand, start, end)].append(dpsi)

intron_dpsi_dict_A = {}
for intron, dpsi_list in intron_dpsis_dict.items():
    intron_dpsi_dict_A[intron] = max(dpsi_list, key=abs)


################################
file = base_dir + 'Mnt_JULiP/dataset_D/diff_spliced_groups.txt'
with open(file, 'r') as f:
    lines = f.readlines()

group_p_values = {}
for line in lines[1:]:
    group_id, _chr, _, strand, gene_names_str, _, _, p_value, q_value = line.strip().split('\t')
    group_p_values[group_id] = float(p_value)

file = base_dir + f'Mnt_JULiP/dataset_D/diff_spliced_introns.txt'
with open(file, 'r') as f:
    lines = f.readlines()

intron_dpsis_dict = defaultdict(list)
for line in lines[1:]:
    group_id, _chr, start, end, strand, _, _, _, dpsi = line.strip().split('\t')
    start, end, dpsi = int(start), int(end), float(dpsi)
    p_value = group_p_values[group_id]
    intron_dpsis_dict[(_chr, strand, start, end)].append(dpsi)

intron_dpsi_dict_D = {}
for intron, dpsi_list in intron_dpsis_dict.items():
    intron_dpsi_dict_D[intron] = max(dpsi_list, key=abs)


x = []
y = []

for intron, dpsi_A in intron_dpsi_dict_A.items():
    if intron in intron_dpsi_dict_D:
        dpsi_D = intron_dpsi_dict_D[intron]
        x.append(dpsi_A)
        y.append(dpsi_D)

plt.figure(num=None, figsize=(10, 8), dpi=86, facecolor='w', edgecolor='k')
plt.scatter(x, y, color='blue', s=5)
# legend = plt.legend(loc='upper left')
# legend.legendHandles[0]._sizes = [10]
plt.xlabel("dataset_A (dPSI)")
plt.ylabel("dataset_D (dPSI)")
plt.ylim((-0.5, 0.51))
plt.xlim((-0.5, 0.51))
plt.yticks(np.arange(-0.5, 0.51, 0.1))
plt.xticks(np.arange(-0.5, 0.51, 0.1))
plt.axhline(y=0.05, linestyle='dotted')
plt.axhline(y=-0.05, linestyle='dotted')
plt.axvline(x=0.05, linestyle='dotted')
plt.axvline(x=-0.05, linestyle='dotted')
# plt.show()

file = '/ccb/salz3/florea/Hippocampus/results/reproducability_julip_DSR.png'
plt.savefig(file)
plt.close()

###############################################################################
dpsis_A = []
dpsis_D = []
for intron, dpsi in intron_dpsi_dict_A.items():
    if intron in intron_dpsi_dict_D:
        dpsis_A.append(dpsi)
        dpsis_D.append(intron_dpsi_dict_D[intron])

print(np.corrcoef(dpsis_A, dpsis_D))
