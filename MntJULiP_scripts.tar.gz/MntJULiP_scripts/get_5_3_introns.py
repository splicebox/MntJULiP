# dict tran and fpkm
from collections import defaultdict
from scipy import stats
import matplotlib.pyplot as plt

import numpy as np

import numpy as np
import matplotlib.mlab as mlab
import matplotlib.pyplot as plt

def get_introns(exons):
    if len(exons) <= 1:
        return []
    else:
        introns = []
        _list = sorted(exons)
        start = _list[0][1]
        for i in range(1, len(_list)):
            end = _list[i][0]
            introns.append((start, end))
            start = _list[i][1]
        return introns


# read exon info from the file.
tran_exons_dict = defaultdict(list)
gtf_file = '/Users/gyang/test/gencode.v22.annotation.gtf'

gene_id_name_dict = {}
gene_id_chr_strand = {}
gene_name_id_dict = defaultdict(set)
tran_exons_dict = defaultdict(list)
gene_tran_dict = defaultdict(set)
with open(gtf_file, 'r') as f:
    for line in f:
        if line is not '\n' and not(line.startswith('#')):
            items = line.strip().split('\t')
            if items[2] == 'exon':
                _chr, strand = items[0], items[6]
                start, end = items[3: 5]
                _items = items[8].split('"')
                tran_id, gene_id = _items[3], _items[1]
                gene_id, gene_name = _items[1], _items[9]
                tran_exons_dict[(_chr, strand, tran_id)].append((int(start), int(end)))
                gene_id_name_dict[gene_id] = gene_name
                gene_name_id_dict[gene_name].add(gene_id)
                gene_id_chr_strand[gene_id] = (_chr, strand)
                gene_tran_dict[gene_id].add(tran_id)

num_introns_dict = defaultdict(set)
start_site_introns_dict = defaultdict(set)
end_site_introns_dict = defaultdict(set)
for (_chr, strand, tran_id), exons in tran_exons_dict.items():
    introns = get_introns(exons)
    if introns:
        first_intron = (_chr, strand, *(introns[0]))
        last_intron = (_chr, strand, *(introns[-1]))
        num_introns_dict[0].add(first_intron)
        num_introns_dict[1].add(last_intron)
        for intron in introns:
            start, end = intron
            start_site_introns_dict[(_chr, strand, start)].add((_chr, strand, *intron))
            end_site_introns_dict[(_chr, strand, end)].add((_chr, strand, *intron))

set0 = set()
set1 = set()
for num, introns in num_introns_dict.items():
    if num == 0:
        for intron in introns:
            _chr, strand, start, end = intron
            if len(end_site_introns_dict[(_chr, strand, end)]) == 1 and len(start_site_introns_dict[(_chr, strand, start)]) == 1:
                set0.add(intron)
    if num == 1:
        for intron in introns:
            _chr, strand, start, end = intron
            if len(end_site_introns_dict[(_chr, strand, end)]) == 1 and len(start_site_introns_dict[(_chr, strand, start)]) == 1:
                set1.add(intron)

###################################################
file = '/Users/gyang/Desktop/hpvop/diff_introns.txt'
with open(file, 'r') as f:
    lines = f.readlines()

gene_dict = defaultdict(lambda: np.zeros(2))
for line in lines[1:]:
    items = line.strip().split('\t')
    _chr, start, end, strand, gene_names_str, status, _, p_value, q_value = items[:9]
    if status == 'TEST' and gene_names_str != '.':
        start, end, p_value, q_value = int(start), int(end), float(p_value), float(q_value)
        means = np.array([float(m) for m in items[9:]])
        for name in gene_names_str.split(','):
            gene_dict[name] = gene_dict[name] + means

gene_set = set()
for name, means in gene_dict.items():
    if np.any(gene_dict[name] > 30):
        gene_set.add(name)


###################################################
file = '/Users/gyang/Desktop/hpvop/diff_introns.txt'
with open(file, 'r') as f:
    lines = f.readlines()

selected_introns = []
selected_lines = []
pred_diff_present_introns_dict = {}
q_values = []
genes = set()
for line in lines[1:]:
    _chr, start, end, strand, gene_names_str, status, _, p_value, q_value, _, _ = line.strip().split('\t')
    if status == 'TEST':
        start, end, p_value, q_value = int(start), int(end), float(p_value), float(q_value)
        intron = (_chr, strand, start, end)
        if q_value < 0.01 and ((intron in set0) or (intron in set1)):
            selected_introns.append(intron)
            selected_lines.append(line.strip())
            for gene in gene_names_str.split(','):
                if gene in gene_set:
                    genes.add(gene)

        if q_value < 0.1 and ((intron in set0) or (intron in set1)):
            q_values.append(q_value)

with open('diff_5_3_introns.txt', 'w') as f:
    f.write(lines[0])
    for line in selected_lines:
        f.write(line + '\n')
