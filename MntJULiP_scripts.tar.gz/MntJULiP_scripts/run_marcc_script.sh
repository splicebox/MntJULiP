#!/bin/zsh -l

#SBATCH
#SBATCH --job-name=s-task
#SBATCH --time=3-00:00:00
#SBATCH --nodes=1
#SBATCH --exclusive
#SBATCH --partition=parallel
#SBATCH --mail-type=end
#SBATCH --mail-user=gyang22@jhu.edu

bash run_star_on_hpvop.sh &> star.log
