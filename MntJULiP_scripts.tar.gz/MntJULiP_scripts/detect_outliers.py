from pathlib import Path
import argparse

import numpy as np
import pandas as pd

import matplotlib.pyplot as plt


def warn(*args, **kwargs):
    pass


import warnings
warnings.warn = warn

from sklearn.preprocessing import StandardScaler
from sklearn.decomposition import PCA
from sklearn.neighbors import LocalOutlierFactor


def get_arguments():
    parser = argparse.ArgumentParser(description='details',
                                    usage='use "%(prog)s --help" for more information',
                                    formatter_class=argparse.RawTextHelpFormatter)
    parser.add_argument('--out-dir', type=str, default='.', help='Output dir for the results')
    parser.add_argument('--in-file', type=str, help='Input file that contains the expressions')

    return parser.parse_args()


def main():
    args = get_arguments()
    out_dir = Path(args.out_dir)

    df = pd.read_csv(args.in_file, sep='\t')
    samples = df['Unnamed: 0'].tolist()
    columns = df.columns.tolist()[1:-1]
    X = df.loc[:, columns].values

    # Standardizing the features
    X = StandardScaler().fit_transform(X)

    # Apply PCA
    pca = PCA(n_components=3)
    X = pca.fit_transform(X)

    # Apply Local Outlier Factor (LOF)
    # by default: n_neighbors=20, contamination=0.22
    clf = LocalOutlierFactor(algorithm='auto')
    y_pred = clf.fit_predict(X)

    # Generate predicted inliers and outliers
    Y_inliers = np.asarray([X[i, :] for i in range(X.shape[0]) if y_pred[i] == 1])
    Y_outliers = np.asarray([X[i, :] for i in range(X.shape[0]) if y_pred[i] == -1])

    # show component 1 & 2
    plt.figure(0)
    plt.title("Principal Component Analysis (PCA) + Local Outlier Factor (LOF)")
    plt.scatter(Y_inliers[:, 0], Y_inliers[:, 1], color='orange', label='Inliers')
    plt.scatter(Y_outliers[:, 0], Y_outliers[:, 1], color='blue', label='Outliers')

    plt.axis('tight')
    plt.xlabel('Principal Component 1')
    plt.ylabel('Principal Component 2')
    # plt.xlim((-10, 10))
    # plt.ylim((-10, 10))
    legend = plt.legend(loc='upper left')
    legend.legendHandles[0]._sizes = [10]
    legend.legendHandles[1]._sizes = [10]
    plt.savefig(out_dir / 'pca_plot_1_to_2.png')

    # show component 1 & 3
    plt.figure(1)
    plt.title("Principal Component Analysis (PCA) + Local Outlier Factor (LOF)")
    plt.scatter(Y_inliers[:, 0], Y_inliers[:, 2], color='orange', label='Inliers')
    plt.scatter(Y_outliers[:, 0], Y_outliers[:, 2], color='blue', label='Outliers')

    plt.xlabel('Principal Component 1')
    plt.ylabel('Principal Component 3')
    legend = plt.legend(loc='upper left')
    legend.legendHandles[0]._sizes = [10]
    legend.legendHandles[1]._sizes = [10]
    plt.savefig(out_dir / 'pca_plot_1_to_3.png')

    # show component 2 & 3
    plt.figure(2)
    plt.title("Principal Component Analysis (PCA) + Local Outlier Factor (LOF)")
    plt.scatter(Y_inliers[:, 1], Y_inliers[:, 2], color='orange', label='Inliers')
    plt.scatter(Y_outliers[:, 1], Y_outliers[:, 2], color='blue', label='Outliers')

    plt.xlabel('Principal Component 2')
    plt.ylabel('Principal Component 3')
    legend = plt.legend(loc='upper left')
    legend.legendHandles[0]._sizes = [10]
    legend.legendHandles[1]._sizes = [10]
    plt.savefig(out_dir / 'pca_plot_2_to_3.png')

    out_columns = ['principal_component_1', 'principal_component_2', 'principal_component_3']
    df_out = pd.DataFrame(data=X, columns=out_columns)
    df_out.insert(0, "samples", samples)
    df_out["LOF_score"] = np.abs(clf.negative_outlier_factor_)
    df_out[f"label(threshold:{abs(clf.offset_):.2f})"] = y_pred
    df_out.to_csv(out_dir / 'results.txt', sep='\t', index=None, header=True, float_format='%.6f')

    print('Explained variance ratio:')
    for i, (v1, v2) in enumerate(zip(pca.explained_variance_ratio_, pca.explained_variance_)):
        print(f'Component {i+1}: {v1} ({v2})')


if __name__ == "__main__":
    main()


# reference
# https://towardsdatascience.com/pca-using-python-scikit-learn-e653f8989e60
# https://scikit-learn.org/stable/modules/generated/sklearn.preprocessing.StandardScaler.html
# https://scikit-learn.org/stable/modules/generated/sklearn.decomposition.PCA.html
# https://scikit-learn.org/stable/modules/outlier_detection.html
# https://scikit-learn.org/stable/modules/generated/sklearn.neighbors.LocalOutlierFactor.html
# https://scikit-learn.org/stable/auto_examples/neighbors/plot_lof_outlier_detection.html#sphx-glr-auto-examples-neighbors-plot-lof-outlier-detection-py
