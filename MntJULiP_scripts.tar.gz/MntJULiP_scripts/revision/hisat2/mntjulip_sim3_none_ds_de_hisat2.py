from pathlib import Path
from collections import defaultdict


def get_introns(exons):
    if len(exons) <= 1:
        return []
    else:
        introns = []
        _list = sorted(exons)
        start = _list[0][1]
        for i in range(1, len(_list)):
            end = _list[i][0]
            introns.append((start, end))
            start = _list[i][1]
        return introns

###############################################################################
gene_file = '/ccb/salz3/gyang/simulation3/meta_info/genes_info.txt'
ds_gene_ids = set()
de_gene_ids = set()
ds_de_gene_ids = set()
none_gene_ids = set()
all_gene_ids = set()

with open(gene_file, 'r') as f:
    for line in f:
        items = line.strip().split('\t')
        gene_id = items[0]
        bool1, bool2, bool3 = [b == 'True' for b in items[3: 6]]
        all_gene_ids.add(gene_id)
        if bool1 and not(bool2) and not(bool3):  # DS
            ds_gene_ids.add(gene_id)

        if not(bool1) and (bool2 or bool3):  # DE
            de_gene_ids.add(gene_id)

        if bool1 and (bool2 or bool3):  # DE & DS
            ds_de_gene_ids.add(gene_id)

        if not(bool1 or bool2 or bool3):
            none_gene_ids.add(gene_id)

###############################################################################
# gtf_file = '/ccb/salz3/gyang/simulation3/meta_info/annotation.gtf'
# gtf_file = '/ccb/salz3/gyang/simulation3/gencode.v22.annotation.gtf'
gtf_file = '/ccb/salz3/gyang/simulation3/stringtie/sim.stmerged.modified.gtf'

gene_id_name_dict = {}
gene_name_ids_dict = defaultdict(list)
tran_exons_dict = defaultdict(list)
with open(gtf_file, 'r') as f:
    for line in f:
        if line != '\n' and not(line.startswith('#')):
            items = line.strip().split('\t')
            if items[2] == 'exon':
                _chr, strand = items[0], items[6]
                start, end = items[3: 5]
                str_list = items[8].strip(';').split('; ')
                item_dict = {}
                for string in str_list:
                    key, value = string.split(' ')
                    item_dict[key] = value[1: -1]
                if 'gene_name' not in item_dict: # ignore custom gene.
                    continue
                tran_id, gene_id = item_dict['transcript_id'], item_dict['gene_id']
                gene_name = item_dict['gene_name']
                # rename gene name (from U2AF1 to A2AF1L5) for ENSG00000275895.3 to reduce confusion
                if gene_id == 'ENSG00000275895.3':
                    gene_name = 'A2AF1L5'
                    chr_A2AF1L5 = _chr
                    strand_A2AF1L5 = strand
                    tran_exons_dict[(_chr, strand, tran_id)].append((int(start), int(end)))
                gene_id_name_dict[gene_id] = gene_name
                gene_name_ids_dict[gene_name].append(gene_id)

introns_A2AF1L5 = set()
for _, exons in tran_exons_dict.items():
    introns = get_introns(exons)
    for intron in introns:
        introns_A2AF1L5.add((chr_A2AF1L5, strand_A2AF1L5, *intron))

gene_name_id_dict = {}
for gene_name, gene_ids in gene_name_ids_dict.items():
    gene_name_id_dict[gene_name] = gene_ids[0]
    if len(gene_ids) > 1:
        for gene_id in gene_ids:
            if gene_id in all_gene_ids:
                gene_name_id_dict[gene_name] = gene_id

########################################################  DSR  #######################################################
base_dir = '/ccb/salz3/gyang/simulation3/hisat2/mntjulip/'
# base_dir = '/ccb/salz3/gyang/simulation3/minCount/sim3.m1/Clean/'
# base_dir = '/ccb/salz3/gyang/simulation3/minCount/sim3.m3/Clean/'
# base_dir = '/ccb/salz3/gyang/simulation3/minCount/sim3.m5/Clean/'
# base_dir = '/ccb/salz3/gyang/simulation3/minCount/sim3.m8/Clean/'
# base_dir = '/ccb/salz3/gyang/simulation3/minCount/sim3.m10/Clean/'
# base_dir = '/ccb/salz3/gyang/simulation3/minCount/sim3.m15/Clean/'
# base_dir = '/ccb/salz3/gyang/simulation3/minCount/sim3.m20/Clean/'


file = base_dir + 'diff_spliced_groups.txt'

with open(file, 'r') as f:
    lines = f.readlines()

group_pvalue_dict = {}
group_gene_dict = {}
for line in lines[1:]:
    group_id, _chr, _, strand, gene_names_str, _, _, p_value, q_value = line.strip().split('\t')
    group_pvalue_dict[group_id] = float(p_value)
    group_gene_dict[group_id] = gene_names_str.split(',')

file = base_dir + 'diff_spliced_introns.txt'
with open(file, 'r') as f:
    lines = f.readlines()

predicted_gene_ids = set()
for line in lines[1:]:
    group_id, _chr, start, end, strand, gene_names_str, _, _, dpsi = line.strip().split('\t')
    start, end, dpsi = int(start), int(end), float(dpsi)
    p_value = group_pvalue_dict[group_id]
    if p_value < 0.1 and abs(dpsi) > 0.05 and gene_names_str != '.':
        for gene_name in group_gene_dict[group_id]:
            if gene_name == 'U2AF1' and (_chr, strand, start, end) in introns_A2AF1L5:
                gene_name = 'A2AF1L5'
            if gene_name in gene_name_id_dict:
                predicted_gene_ids.add(gene_name_id_dict[gene_name])


print(f"MntJULiP(DSR) None: {len(predicted_gene_ids.intersection(none_gene_ids))}")
print(f"MntJULiP(DSR) TP DS: {len(predicted_gene_ids.intersection(ds_gene_ids))}")
print(f"MntJULiP(DSR) TP DE: {len(predicted_gene_ids.intersection(de_gene_ids))}")
print(f"MntJULiP(DSR) TP DS&DE: {len(predicted_gene_ids.intersection(ds_de_gene_ids))}")
print(f"MntJULiP(DSR) ALL: {len(predicted_gene_ids)}")
print(f"MntJULiP(DSR) others: {len(predicted_gene_ids.difference(none_gene_ids.union(ds_gene_ids).union(de_gene_ids).union(ds_de_gene_ids)))}")

print('\n')
DSR_gene_ids = ds_gene_ids | ds_de_gene_ids
print(f"MntJULiP TP DSR:", len(DSR_gene_ids & predicted_gene_ids))
print(f"MntJULiP FP DSR:", len(predicted_gene_ids - DSR_gene_ids))
print(f"MntJULiP FN DSR:", len(DSR_gene_ids - predicted_gene_ids))

print('\n')
DSA_gene_ids = de_gene_ids | ds_gene_ids | ds_de_gene_ids
print(f"MntJULiP TP DSA:", len(DSA_gene_ids & predicted_gene_ids))
print(f"MntJULiP FP DSA:", len(predicted_gene_ids - DSA_gene_ids))
print(f"MntJULiP FN DSA:", len(DSA_gene_ids - predicted_gene_ids))
print('\n')

# for gene_id in predicted_gene_ids.difference(none_gene_ids.union(ds_gene_ids).union(de_gene_ids).union(ds_de_gene_ids)):
    # print(gene_id_name_dict[gene_id])

########################################################  DSA  #######################################################

file = base_dir + 'diff_introns.txt'
with open(file, 'r') as f:
    lines = f.readlines()

predicted_gene_ids = set()
for line in lines[1:]:
    _chr, start, end, strand, gene_names_str, status, _, p_value, q_value, _, _ = line.strip().split('\t')
    start, end = int(start), int(end)
    if status == 'TEST':
        p_value, q_value = float(p_value), float(q_value)
        if p_value < 0.1 and gene_names_str != '.':
            for gene_name in gene_names_str.split(','):
                if gene_name == 'U2AF1' and (_chr, strand, start, end) in introns_A2AF1L5:
                    gene_name = 'A2AF1L5'
                if gene_name in gene_name_id_dict:
                    predicted_gene_ids.add(gene_name_id_dict[gene_name])

print(f"MntJULiP(DSA) None: {len(predicted_gene_ids.intersection(none_gene_ids))}")
print(f"MntJULiP(DSA) TP DS: {len(predicted_gene_ids.intersection(ds_gene_ids))}")
print(f"MntJULiP(DSA) TP DE: {len(predicted_gene_ids.intersection(de_gene_ids))}")
print(f"MntJULiP(DSA) TP DS&DE: {len(predicted_gene_ids.intersection(ds_de_gene_ids))}")
print(f"MntJULiP(DSA) ALL: {len(predicted_gene_ids)}")
print(f"MntJULiP(DSA) others: {len(predicted_gene_ids.difference(none_gene_ids.union(ds_gene_ids).union(de_gene_ids).union(ds_de_gene_ids)))}")


print('\n')
DSR_gene_ids = ds_gene_ids | ds_de_gene_ids
print(f"MntJULiP TP DSR:", len(DSR_gene_ids & predicted_gene_ids))
print(f"MntJULiP FP DSR:", len(predicted_gene_ids - DSR_gene_ids))
print(f"MntJULiP FN DSR:", len(DSR_gene_ids - predicted_gene_ids))

print('\n')
DSA_gene_ids = de_gene_ids | ds_gene_ids | ds_de_gene_ids
print(f"MntJULiP TP DSA:", len(DSA_gene_ids & predicted_gene_ids))
print(f"MntJULiP FP DSA:", len(predicted_gene_ids - DSA_gene_ids))
print(f"MntJULiP FN DSA:", len(DSA_gene_ids - predicted_gene_ids))

# for gene_id in predicted_gene_ids.difference(none_gene_ids.union(ds_gene_ids).union(de_gene_ids).union(ds_de_gene_ids)):
    # print(gene_id_name_dict[gene_id])
