BASE_DIR="/ccb/salz3/gyang/simulation3"
CNTRL_DIR="${BASE_DIR}/hisat2/control"
CASE_DIR="${BASE_DIR}/hisat2/case"
SOFTWARE_DIR="/ccb/salz3/gyang/softwares"
RMATS="/ccb/salz3/gyang/softwares/rMATS.3.2.5/RNASeq-MATS.py"
GTF="/ccb/salz3/gyang/simulation3/stringtie/sim.stmerged.modified.gtf"


WORK_DIR="${BASE_DIR}/hisat2/rMATS.3.2.5"
mkdir -p ${WORK_DIR}
cd ${WORK_DIR}

control_bams="${CNTRL_DIR}/sample_01/sample_01.bam"
case_bams="${CASE_DIR}/sample_01/sample_01.bam"
for i in {02..25}
do
    control_bams="${control_bams},${CNTRL_DIR}/sample_${i}/sample_${i}.bam"
    case_bams="${case_bams},${CASE_DIR}/sample_${i}/sample_${i}.bam"
done

time python ${RMATS} \
       -b1 ${control_bams} \
       -b2 ${case_bams} \
       -gtf ${GTF} \
       -o out -t paired -len 101

wait

# tar zxfv Python-2.7.18.tgz
# export PATH=/ccb/salz3/gyang/softwares/Python-2.7.18/bin/:$PATH
# export PYTHONPATH=/ccb/salz3/gyang/softwares/Python-2.7.18
# ./configure --prefix=/ccb/salz3/gyang/softwares/Python-2.7.18
# make; make install
# python -m ensurepip --upgrade
# python -m pip install --user numpy scipy matplotlib pysam enum34 Cython
