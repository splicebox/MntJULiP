# unset PYTHONPATH
SOFTWARE_DIR='/ccb/salz3/gyang/softwares/'
BASE_DIR='/ccb/salz3/gyang/simulation3'
DATA_DIR="${BASE_DIR}/hisat2"

export PATH="/home/dyang/.local/bin:$PATH"
export PATH="${SOFTWARE_DIR}/python-3.6.8/bin:$PATH"
export PYTHONPATH="${SOFTWARE_DIR}/python-3.6.8"

cd ${SOFTWARE_DIR}/MntJULiP


WORK_DIR="${BASE_DIR}/hisat2/mntjulip/"
mkdir -p ${WORK_DIR}

rm -rf ${WORK_DIR}/bam_list.txt
echo -e "sample\tcondition" > ${WORK_DIR}/bam_list.txt
for d in 'case' 'control'
do
    for i in {01..25}
    do
        echo -e "${DATA_DIR}/${d}/sample_${i}/sample_${i}.bam\t${d}" >> ${WORK_DIR}/bam_list.txt
    done
done

gtf="/ccb/salz3/gyang/simulation3/stringtie/sim.stmerged.modified.gtf"
python3 run.py --out-dir ${WORK_DIR} \
               --bam-list ${WORK_DIR}/bam_list.txt \
               --num-threads 10 \
               --batch-size 2000 \
               --anno-file ${gtf}
