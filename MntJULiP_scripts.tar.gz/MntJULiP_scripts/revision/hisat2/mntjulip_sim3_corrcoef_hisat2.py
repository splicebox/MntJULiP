# dict tran and fpkm
from collections import defaultdict
from scipy import stats
import matplotlib.pyplot as plt

import numpy as np


def get_introns(exons):
    if len(exons) <= 1:
        return []
    else:
        introns = []
        _list = sorted(exons)
        start = _list[0][1]
        for i in range(1, len(_list)):
            end = _list[i][0]
            introns.append((start, end))
            start = _list[i][1]
        return introns

######################
gtf_file = '/ccb/salz3/gyang/simulation3/meta_info/annotation.gtf'
tran_exons_dict = defaultdict(list)
tran_chr_strand_dict = {}
with open(gtf_file, 'r') as f:
    for line in f:
        if line is not '\n':
            items = line.strip().split('\t')
            if items[2] == 'exon':
                _chr, strand = items[0], items[6]
                start, end = int(items[3]), int(items[4])
                _items = items[8].split('"')
                tran_id, gene_id = _items[3], _items[1]
                tran_exons_dict[tran_id].append((start, end))
                tran_chr_strand_dict[tran_id] = (_chr, strand)

intron_trans_dict = defaultdict(list)
for tran_id, exons in tran_exons_dict.items():
    introns = get_introns(exons)
    _chr, strand = tran_chr_strand_dict[tran_id]
    for intron in introns:
        intron_trans_dict[(_chr, strand, *intron)].append(tran_id)


######################
gene_file = '/ccb/salz3/gyang/simulation3/meta_info/genes_info.txt'
tran_fpkm_control_dict = {}
tran_fpkm_case_dict = {}
gene_fpkm_control_dict = defaultdict(lambda: 0)
gene_fpkm_case_dict = defaultdict(lambda: 0)
tran_gene_dict = {}

DSR_chosen_trans = set()
DSA_chosen_trans = set()


with open(gene_file, 'r') as f:
    for line in f:
        items = line.strip().split('\t')
        gene_id = items[0]
        bool1, bool2, bool3 = [b == 'True' for b in items[3: 6]]
        if bool1 or bool2 or bool3:
            for item in items[6].split(', ')[:2]:
                tran_id, fpkm = item.strip().split(':')
                DSA_chosen_trans.add(tran_id)
        if bool1:
            for item in items[6].split(', ')[:2]:
                tran_id, fpkm = item.strip().split(':')
                DSR_chosen_trans.add(tran_id)

        for item in items[6].split(', '):
            tran_id, fpkm = item.strip().split(':')
            tran_fpkm_control_dict[tran_id] = float(fpkm)
            gene_fpkm_control_dict[gene_id] += float(fpkm)
            tran_gene_dict[tran_id] = gene_id

        for item in items[7].split(','):
            tran_id, fpkm = item.strip().split(':')
            tran_fpkm_case_dict[tran_id] = float(fpkm)
            gene_fpkm_case_dict[gene_id] += float(fpkm)


#######################################################  JULIP(DSR)  ######################################################
base_dir = '/ccb/salz3/gyang/simulation3/hisat2/mntjulip/'
file = base_dir + 'diff_spliced_groups.txt'
with open(file, 'r') as f:
    lines = f.readlines()

group_pvalue_dict = {}
for line in lines[1:]:
    group_id, _chr, _, strand, gene_name_str, _, _, p_value, q_value = line.strip().split('\t')
    group_pvalue_dict[group_id] = float(p_value)

file = base_dir + 'diff_spliced_introns.txt'
with open(file, 'r') as f:
    lines = f.readlines()

julip_intron_dpsis_dict = defaultdict(list)
julip_intron_pvalues_dict = defaultdict(list)
for line in lines[1:]:
    group_id, _chr, start, end, strand, _, _, _, dpsi = line.strip().split('\t')
    start, end, dpsi = int(start), int(end), float(dpsi)
    julip_intron_dpsis_dict[(_chr, strand, start, end)].append(dpsi)

julip_intron_dpsi_dict = {}
for intron, _list in julip_intron_dpsis_dict.items():
    julip_intron_dpsi_dict[intron] = max(julip_intron_dpsis_dict[intron], key=abs)

#################################### all ######################################
ref_intron_dpsis = []
julip_intron_dpsis = []
for intron, trans in intron_trans_dict.items():
    # only consider the introns in common
    if intron not in julip_intron_dpsi_dict:
        continue

    cntrl_sum = 0
    case_sum = 0
    for tran_id in trans:
        if tran_id in tran_fpkm_control_dict:
            cntrl_sum += tran_fpkm_control_dict[tran_id]

        if tran_id in tran_fpkm_case_dict:
            case_sum += tran_fpkm_case_dict[tran_id]

    # this works because a intron only belong to one gene in our annotation.
    gene_id = tran_gene_dict[tran_id]
    psi_cntrl = cntrl_sum / gene_fpkm_control_dict[gene_id]
    psi_case = case_sum / gene_fpkm_case_dict[gene_id]
    ref_intron_dpsis.append(psi_cntrl - psi_case)
    julip_intron_dpsis.append(julip_intron_dpsi_dict[intron])

print(np.corrcoef(ref_intron_dpsis, julip_intron_dpsis))


#################################### DSR ######################################
ref_intron_dpsis = []
julip_intron_dpsis = []
for intron, trans in intron_trans_dict.items():
    # only consider the introns in common
    if intron not in julip_intron_dpsi_dict:
        continue

    cntrl_sum = 0
    case_sum = 0
    flag = False
    for tran_id in trans:
        if tran_id in DSR_chosen_trans:
            flag = True

        if tran_id in tran_fpkm_control_dict:
            cntrl_sum += tran_fpkm_control_dict[tran_id]

        if tran_id in tran_fpkm_case_dict:
            case_sum += tran_fpkm_case_dict[tran_id]

    if flag:
        gene_id = tran_gene_dict[tran_id]
        psi_cntrl = cntrl_sum / gene_fpkm_control_dict[gene_id]
        psi_case = case_sum / gene_fpkm_case_dict[gene_id]
        ref_intron_dpsis.append(psi_cntrl - psi_case)
        julip_intron_dpsis.append(julip_intron_dpsi_dict[intron])

print(np.corrcoef(ref_intron_dpsis, julip_intron_dpsis))


#######################################################  JULIP(DSA)  ######################################################
base_dir = '/ccb/salz3/gyang/simulation3/hisat2/mntjulip/'
file = base_dir + 'diff_introns.txt'
with open(file, 'r') as f:
    lines = f.readlines()


julip_log2_change_dict = {}
julip_pvalue_dict = {}
for line in lines[1:]:
    _chr, start, end, strand, gene_name, status, _, p_value, q_value, case, cntrl = line.strip().split('\t')
    if status == 'TEST':
        start, end, p_value, q_value = int(start), int(end), float(p_value), float(q_value)
        case, cntrl = float(case), float(cntrl)
        if case == 0 or cntrl == 0:
            continue
        julip_log2_change_dict[(_chr, strand, start, end)] = np.log2(case / cntrl)
        julip_pvalue_dict[(_chr, strand, start, end)] = p_value

#################################### all ######################################
ref_intron_log2_changes = []
julip_intron_log2_changes = []
for intron, trans in intron_trans_dict.items():
    if intron not in julip_log2_change_dict:
        continue

    cntrl_sum = 0
    case_sum = 0
    for tran_id in trans:
        if tran_id in tran_fpkm_control_dict:
            cntrl_sum += tran_fpkm_control_dict[tran_id]

        if tran_id in tran_fpkm_case_dict:
            case_sum += tran_fpkm_case_dict[tran_id]

    ref_intron_log2_changes.append(np.log2(case_sum / cntrl_sum))
    julip_intron_log2_changes.append(julip_log2_change_dict[intron])

print(np.corrcoef(ref_intron_log2_changes, julip_intron_log2_changes))


#################################### DSA ######################################
ref_intron_log2_changes = []
julip_intron_log2_changes = []
for intron, trans in intron_trans_dict.items():
    if intron not in julip_log2_change_dict:
        continue

    cntrl_sum = 0
    case_sum = 0
    flag = False
    for tran_id in trans:
        if tran_id in DSA_chosen_trans:
            flag = True
        if tran_id in tran_fpkm_control_dict:
            cntrl_sum += tran_fpkm_control_dict[tran_id]

        if tran_id in tran_fpkm_case_dict:
            case_sum += tran_fpkm_case_dict[tran_id]

    if flag:
        ref_intron_log2_changes.append(np.log2(case_sum / cntrl_sum))
        julip_intron_log2_changes.append(julip_log2_change_dict[intron])

print(np.corrcoef(ref_intron_log2_changes, julip_intron_log2_changes))

