# dict tran and fpkm
from collections import defaultdict
from scipy import stats
import matplotlib.pyplot as plt

import numpy as np


def get_introns(exons):
    if len(exons) <= 1:
        return []
    else:
        introns = []
        _list = sorted(exons)
        start = _list[0][1]
        for i in range(1, len(_list)):
            end = _list[i][0]
            introns.append((start, end))
            start = _list[i][1]
        return introns

######################
gtf_file = '/ccb/salz3/gyang/simulation3/meta_info/annotation.gtf'

tran_exons_dict = defaultdict(list)
tran_chr_strand_dict = {}
with open(gtf_file, 'r') as f:
    for line in f:
        if line != '\n' and not(line.startswith("#")):
            items = line.strip().split('\t')
            if items[2] == 'exon':
                _chr, strand = items[0], items[6]
                start, end = int(items[3]), int(items[4])
                _items = items[8].split('"')
                tran_id, gene_id = _items[3], _items[1]
                tran_exons_dict[tran_id].append((start, end))
                tran_chr_strand_dict[tran_id] = (_chr, strand)

intron_trans_dict = defaultdict(list)
for tran_id, exons in tran_exons_dict.items():
    introns = get_introns(exons)
    _chr, strand = tran_chr_strand_dict[tran_id]
    for intron in introns:
        intron_trans_dict[(_chr, strand, *intron)].append(tran_id)


######################
gene_file = '/ccb/salz3/gyang/simulation3/meta_info/genes_info.txt'
tran_fpkm_control_dict = {}
tran_fpkm_case_dict = {}
gene_fpkm_control_dict = defaultdict(lambda: 0)
gene_fpkm_case_dict = defaultdict(lambda: 0)
tran_gene_dict = {}

with open(gene_file, 'r') as f:
    for line in f:
        items = line.strip().split('\t')
        gene_id = items[0]
        # bool1, bool2, bool3 = [b == 'True' for b in items[3: 6]]
        for item in items[6].split(', '):
            tran_id, fpkm = item.strip().split(':')
            tran_fpkm_control_dict[tran_id] = float(fpkm)
            gene_fpkm_control_dict[gene_id] += float(fpkm)
            tran_gene_dict[tran_id] = gene_id

        for item in items[7].split(','):
            tran_id, fpkm = item.strip().split(':')
            tran_fpkm_case_dict[tran_id] = float(fpkm)
            gene_fpkm_case_dict[gene_id] += float(fpkm)

#########################################################. JULIP  #########################################################
base_dir = '/ccb/salz3/gyang/simulation3/hisat2/mntjulip/'

file = base_dir + 'diff_spliced_groups.txt'
with open(file, 'r') as f:
    lines = f.readlines()

group_pvalue_dict = {}
for line in lines[1:]:
    group_id, _chr, _, strand, gene_name_str, _, _, p_value, q_value = line.strip().split('\t')
    group_pvalue_dict[group_id] = float(p_value)

file = base_dir + 'diff_spliced_introns.txt'
with open(file, 'r') as f:
    lines = f.readlines()

julip_intron_dpsis_dict = defaultdict(list)
julip_intron_pvalues_dict = defaultdict(list)
for line in lines[1:]:
    group_id, _chr, start, end, strand, _, _, _, dpsi = line.strip().split('\t')
    start, end, dpsi = int(start), int(end), float(dpsi)
    julip_intron_dpsis_dict[(_chr, strand, start, end)].append(dpsi)
    julip_intron_pvalues_dict[(_chr, strand, start, end)].append(group_pvalue_dict[group_id])

julip_intron_dpsi_dict = {}
julip_intron_pvalue_dict = {}
for intron, _list in julip_intron_dpsis_dict.items():
    julip_intron_dpsi_dict[intron] = max(julip_intron_dpsis_dict[intron], key=abs)
    julip_intron_pvalue_dict[intron] = np.min(julip_intron_pvalues_dict[intron])

ref_intron_dpsi_dict = {}
for intron, trans in intron_trans_dict.items():
    # only consider the introns in common
    if intron not in julip_intron_dpsi_dict:
        continue

    cntrl_sum = 0
    case_sum = 0
    for tran_id in trans:
        if tran_id in tran_fpkm_control_dict:
            cntrl_sum += tran_fpkm_control_dict[tran_id]

        if tran_id in tran_fpkm_case_dict:
            case_sum += tran_fpkm_case_dict[tran_id]

    # this works because a intron only belong to one gene in our annotation.
    gene_id = tran_gene_dict[tran_id]
    psi_cntrl = cntrl_sum / gene_fpkm_control_dict[gene_id]
    psi_case = case_sum / gene_fpkm_case_dict[gene_id]
    ref_intron_dpsi_dict[intron] = psi_cntrl - psi_case

###############################################################################
x1 = []
x2 = []
y1 = []
y2 = []

for intron, ref_dpsi in ref_intron_dpsi_dict.items():
    p_value = julip_intron_pvalue_dict[intron]
    dpsi = julip_intron_dpsi_dict[intron]
    if p_value <= 0.1 and abs(dpsi) >= 0.05:
        x1.append(dpsi)
        y1.append(ref_dpsi)
    else:
        x2.append(dpsi)
        y2.append(ref_dpsi)

plt.figure(num=None, figsize=(10, 8), dpi=86, facecolor='w', edgecolor='k')
plt.scatter(x1, y1, color='red', label=r'$p\_value \leq 0.1, |dPSI| \geq 0.05$', s=10)
plt.scatter(x2, y2, color='blue', label='Others', s=10)
legend = plt.legend(loc='upper left')
legend.legendHandles[0]._sizes = [10]
legend.legendHandles[1]._sizes = [10]
plt.ylabel("Reference (dPSI)")
plt.xlabel("MntJULiP (dPSI)")
plt.ylim((-1, 1.01))
plt.xlim((-1, 1.01))
plt.yticks(np.arange(-1, 1.01, 0.1))
plt.xticks(np.arange(-1, 1.01, 0.1))
# plt.show()

out_dir = '/ccb/salz3/gyang/simulation3/hisat2/mntjulip/'
file = out_dir + 'julip_sim_dpsi.png'
plt.savefig(file)
plt.close()


#############
x1 = []
x2 = []
y1 = []
y2 = []

for intron, ref_dpsi in ref_intron_dpsi_dict.items():
    p_value = julip_intron_pvalue_dict[intron]
    dpsi = julip_intron_dpsi_dict[intron]
    if p_value <= 0.1 and abs(dpsi) >= 0.05:
        x1.append(abs(dpsi))
        y1.append(abs(ref_dpsi))
    else:
        x2.append(abs(dpsi))
        y2.append(abs(ref_dpsi))

plt.figure(num=None, figsize=(10, 8), dpi=86, facecolor='w', edgecolor='k')
plt.scatter(np.abs(x1), np.abs(y1), color='red', label=r'$p\_value \leq 0.1, |dPSI| \geq 0.05$', s=10)
plt.scatter(np.abs(x2), np.abs(y2), color='blue', label='Others', s=10)
legend = plt.legend(loc='upper left')
legend.legendHandles[0]._sizes = [10]
legend.legendHandles[1]._sizes = [10]
plt.ylabel("Reference (|dPSI|)")
plt.xlabel("MntJULiP (|dPSI|)")
plt.ylim((0, 1.01))
plt.xlim((0, 1.01))
plt.yticks(np.arange(0, 1.01, 0.1))
plt.xticks(np.arange(0, 1.01, 0.1))
# plt.show()

file = out_dir + 'julip_sim_abs_dpsi.png'
plt.savefig(file)
plt.close()

