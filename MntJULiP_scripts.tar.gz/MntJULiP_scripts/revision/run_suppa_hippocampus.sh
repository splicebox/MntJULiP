
# python3 -m pip install --user SUPPA==2.3
module load python/3.6.lua
workdir="/home-2/gyang22@jhu.edu/work/Guangyu/hippocampus/"
mkdir -p ${workdir}; cd ${workdir}
SUPPA="/home-2/gyang22@jhu.edu/work/Guangyu/SUPPA/suppa.py"
gtf="/home-2/gyang22@jhu.edu/work/Guangyu/hippocampus/gencode.vM17.annotation.gtf"

# generate the splicing events from the annotation file
python3 ${SUPPA} generateEvents -i ${gtf} -o ${workdir}/suppa/suppa -f ioe -e SE &
python3 ${SUPPA} generateEvents -i ${gtf} -o ${workdir}/suppa/suppa -f ioe -e SS &
python3 ${SUPPA} generateEvents -i ${gtf} -o ${workdir}/suppa/suppa -f ioe -e MX &
python3 ${SUPPA} generateEvents -i ${gtf} -o ${workdir}/suppa/suppa -f ioe -e RI &
python3 ${SUPPA} generateEvents -i ${gtf} -o ${workdir}/suppa/suppa -f ioe -e FL &
python3 ${SUPPA} generateEvents -i ${gtf} -o ${workdir}/suppa/suppa -f ioi

# n=24
# k=0
# for group in case control
# do
#     for i in {01..25}
#     do
#         for type in SE RI MX AL AF A5 A3
#         do
#             mkdir -p ${workdir}/suppa/${type}_events/${group}_sample_${i}
#             python3 ${SUPPA} psiPerIsoform -g ${gtf} \
#                                            -e ${workdir}/sailfish/out/${group}_sample_${i}/quant.sf \
#                                            -o ${workdir}/suppa/${type}_events/${group}_sample_${i}/${group}_sample_${i} &
#             k=$(($k+1))
#             if [ $k -eq $n ]; then
#                 wait
#                 k=0
#             fi
#         done
#     done
# done


mkdir -p ${workdir}/suppa/tpms
for sample in ERR1779513 ERR1779503 ERR1779502 ERR1779500 ERR1779491 ERR1779489 ERR1779487 ERR1779457 ERR1779452 ERR1779451 ERR1779449 ERR1779444 ERR1779443 ERR1779435 ERR1779432 ERR1779430 ERR1779422 ERR1779420 ERR1779417 ERR1779414 ERR1779382 ERR1779379 ERR1779372 ERR1779370 ERR1779367 ERR1779363 ERR1779355 ERR1779353 ERR1779351 ERR1779350 ERR1779349 ERR1779346 ERR1779344 ERR1779343 ERR1779334 ERR1779333 ERR1779332 ERR1779327 ERR1779321 ERR1779320 ERR1779317 ERR1779309 ERR1779301 ERR1779300
do
    python3 ${workdir}/suppa/filter_tpm_4_suppa.py -i ${workdir}/salmon/${sample}/quant.sf \
                                                   -o ${workdir}/suppa/tpms/${sample}.tpm \
                                                   -s ${sample}
done


n=24
k=0
for sample in ERR1779513 ERR1779503 ERR1779502 ERR1779500 ERR1779491 ERR1779489 ERR1779487 ERR1779457 ERR1779452 ERR1779451 ERR1779449 ERR1779444 ERR1779443 ERR1779435 ERR1779432 ERR1779430 ERR1779422 ERR1779420 ERR1779417 ERR1779414 ERR1779382 ERR1779379 ERR1779372 ERR1779370 ERR1779367 ERR1779363 ERR1779355 ERR1779353 ERR1779351 ERR1779350 ERR1779349 ERR1779346 ERR1779344 ERR1779343 ERR1779334 ERR1779333 ERR1779332 ERR1779327 ERR1779321 ERR1779320 ERR1779317 ERR1779309 ERR1779301 ERR1779300
do
    for type in SE RI MX AL AF A5 A3
    do
        mkdir -p ${workdir}/suppa/${type}_events/
        python3 ${SUPPA} psiPerEvent -i ${workdir}/suppa/suppa_${type}_strict.ioe \
                                     -e ${workdir}/suppa/tpms/${sample}.tpm \
                                     -o ${workdir}/suppa/${type}_events/${sample} &
        k=$(($k+1))
        if [ $k -eq $n ]; then
            wait
            k=0
        fi
    done
done


cd ${workdir}/suppa/tpms
for group in case control
do
    input_files=""
    for i in {01..25}
    do
        input_files="${input_files} ${workdir}/suppa/tpms/${group}_sample_${i}.tpm"
    done

    python3 ${SUPPA} joinFiles -i `echo ${input_files}` \
                               -f tpm \
                               -o ${group}_tpms
done

cd ${workdir}/suppa/tpms
input_files=""
group='control'
for sample in ERR1779355 ERR1779332 ERR1779372 ERR1779317 ERR1779333 ERR1779382 ERR1779363 ERR1779327 ERR1779353 ERR1779300 ERR1779349 ERR1779367 ERR1779344 ERR1779346 ERR1779350 ERR1779334 ERR1779379 ERR1779320 ERR1779309 ERR1779321 ERR1779370 ERR1779351 ERR1779301 ERR1779343
do
    input_files="${input_files} ${workdir}/suppa/tpms/${sample}.tpm"
done
python3 ${SUPPA} joinFiles -i `echo ${input_files}` \
                           -f tpm \
                           -o ${group}_tpms

input_files=""
group='epileptic'
for sample in ERR1779449 ERR1779513 ERR1779451 ERR1779414 ERR1779444 ERR1779452 ERR1779491 ERR1779420 ERR1779435 ERR1779430 ERR1779502 ERR1779500 ERR1779457 ERR1779432 ERR1779487 ERR1779489 ERR1779417 ERR1779443 ERR1779503 ERR1779422
do
    input_files="${input_files} ${workdir}/suppa/tpms/${sample}.tpm"
done
python3 ${SUPPA} joinFiles -i `echo ${input_files}` \
                           -f tpm \
                           -o ${group}_tpms

cd ${workdir}/suppa/tpms
input_files=""
group='control'
for type in SE RI MX AL AF A5 A3
do
    cd ${workdir}/suppa/${type}_events
    for sample in ERR1779355 ERR1779332 ERR1779372 ERR1779317 ERR1779333 ERR1779382 ERR1779363 ERR1779327 ERR1779353 ERR1779300 ERR1779349 ERR1779367 ERR1779344 ERR1779346 ERR1779350 ERR1779334 ERR1779379 ERR1779320 ERR1779309 ERR1779321 ERR1779370 ERR1779351 ERR1779301 ERR1779343
    do
        input_files="${input_files} ${workdir}/suppa/${type}_events/${sample}.psi"
    done
    python3 ${SUPPA} joinFiles -i `echo ${input_files}` \
                               -f psi \
                               -o ${group}_psis
done

input_files=""
group='epileptic'
for type in SE RI MX AL AF A5 A3
do
    cd ${workdir}/suppa/${type}_events
    for sample in ERR1779449 ERR1779513 ERR1779451 ERR1779414 ERR1779444 ERR1779452 ERR1779491 ERR1779420 ERR1779435 ERR1779430 ERR1779502 ERR1779500 ERR1779457 ERR1779432 ERR1779487 ERR1779489 ERR1779417 ERR1779443 ERR1779503 ERR1779422
    do
        input_files="${input_files} ${workdir}/suppa/${type}_events/${sample}.psi"
    done
    python3 ${SUPPA} joinFiles -i `echo ${input_files}` \
                               -f psi \
                               -o ${group}_psis
done


for type in SE RI MX AL AF A5 A3
do 
    for method in classical empirical
    do
        cd ${workdir}/suppa/${type}_events
        python3 ${SUPPA} diffSplice --method ${method} \
                                      --input ${workdir}/suppa/suppa_${type}_strict.ioe \
                                      --psi ${workdir}/suppa/${type}_events/control_psis.psi ${workdir}/suppa/${type}_events/epileptic_psis.psi \
                                      --tpm ${workdir}/suppa/tpms/control_tpms.tpm ${workdir}/suppa/tpms/epileptic_tpms.tpm \
                                      -gc \
                                      -o ${type}_${method}_dpsis
    done
done
