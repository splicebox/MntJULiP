
## install sleuth by conda R
# conda create -n r-environment r-essentials r-base
# conda activate r-environment
# conda install --channel bioconda r-sleuth
# ~/work/Guangyu/miniconda3/envs/r-environment/bin/R
# conda create -n r-environment r-essentials r-base
# install.packages('cowplot')
# if (!require("BiocManager", quietly = TRUE))
#    install.packages("BiocManager")

suppressMessages({
  library("sleuth")
})


file <- "/home-2/gyang22@jhu.edu/work/Guangyu/simulation3/kallisto/metadata.txt"
s2c <- read.table(file, header=TRUE, stringsAsFactors=FALSE)
# colnames(s2c)

custom_filter <- function(row, min_reads=1, min_prop=0.001) {
  mean(row >= min_reads) >= min_prop
}

so <- sleuth_prep(s2c, num_cores=10, filter_fun=custom_filter)
so <- sleuth_fit(so, ~condition, 'full')
so <- sleuth_fit(so, ~1, 'reduced')
so <- sleuth_lrt(so, 'reduced', 'full')
sleuth_table <- sleuth_results(so, 'reduced:full', 'lrt', show_all = FALSE)
# sleuth_significant <- dplyr::filter(sleuth_table, qval <= 0.05)
head(sleuth_table, 20)

file <- "/home-2/gyang22@jhu.edu/work/Guangyu/simulation3/kallisto/kallisto_out.csv"
ret <- write.csv(x=sleuth_table, file=file)
