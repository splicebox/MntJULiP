
module load salmon/0.13.0.lua
basedir="/home-2/gyang22@jhu.edu/work/Guangyu/"
workdir="${basedir}/hippocampus/salmon"
datadir="${basedir}/hippocampus/data"

gtf="${basedir}/hippocampus/gencode.vM17.annotation.gtf"
fa_file="${basedir}/hippocampus/gencode.vM17.annotation.fa"
SIDX="${workdir}/transcripts_index"


mkdir ${workdir}; cd ${workdir}

core=24
salmon index -p ${core} -t ${fa_file} -i transcripts_index --gencode

mkdir -p ${workdir}/logs

for sample in ERR1779513 ERR1779503 ERR1779502 ERR1779500 ERR1779491 ERR1779489 ERR1779487 ERR1779457 ERR1779452 ERR1779451 ERR1779449 ERR1779444 ERR1779443 ERR1779435 ERR1779432 ERR1779430 ERR1779422 ERR1779420 ERR1779417 ERR1779414 ERR1779382 ERR1779379 ERR1779372 ERR1779370 ERR1779367 ERR1779363 ERR1779355 ERR1779353 ERR1779351 ERR1779350 ERR1779349 ERR1779346 ERR1779344 ERR1779343 ERR1779334 ERR1779333 ERR1779332 ERR1779327 ERR1779321 ERR1779320 ERR1779317 ERR1779309 ERR1779301 ERR1779300
do
    rm -rf ${workdir}/${sample} ${workdir}/logs/${sample}.salmon.log
    mkdir -p ${workdir}/${sample}
    salmon quant -i $SIDX -l A -p ${core} \
                 -1 ${datadir}/${sample}_1.fastq.gz \
                 -2 ${datadir}/${sample}_2.fastq.gz \
                 -o ${workdir}/${sample} -g ${gtf} -c 2> ${workdir}/logs/${sample}.salmon.log
done



# gffread -w gencode.vM17.annotation.fa \
#         -g /ccb/salz7-data/genomes/mouse/mm10.fa \
#         /ccb/salz3/florea/Hippocampus/gencode.vM17.annotation.gtf





