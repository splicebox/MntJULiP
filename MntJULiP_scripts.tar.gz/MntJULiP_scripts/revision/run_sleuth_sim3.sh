
# insttall sleuth by condaR
# conda create -n r-environment r-essentials r-base
# conda activate r-environment
# conda install --channel bioconda r-sleuth

library('sleuth')


