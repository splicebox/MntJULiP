
module load salmon/0.13.0.lua
basedir="/home-2/gyang22@jhu.edu/work/Guangyu/"
workdir="${basedir}/simulation3/salmon"
datadir="${basedir}/simulation3/FASTQ"

gtf="${basedir}/simulation3/sim.stmerged.modified.gtf"
fa_file="${basedir}/simulation3/sim.stmerged.modified.clean.fa"
SIDX="${workdir}/stmerged_index"

mkdir ${workdir}; cd ${workdir}

core=24
salmon index -p ${core} -t ${fa_file} -i stmerged_index --gencode

mkdir -p ${workdir}/logs

for group in case control
do
    for i in {01..25}
    do
        mkdir -p ${workdir}/${group}_sample_${i}
        fastq1_prefix="${datadir}/${group}/sample_${i}/sample_${i}_R1"
        fastq2_prefix="${datadir}/${group}/sample_${i}/sample_${i}_R2"
        salmon quant -i $SIDX -l A -p ${core} \
                     -1 ${fastq1_prefix}.fastq \
                     -2 ${fastq2_prefix}.fastq \
                     -o ${workdir}/${group}_sample_${i} -g ${gtf} -c 2> ${workdir}/logs/${group}_sample_${i}.salmon.log
    done
done

