# conda create -n kallisto-env
# conda activate kallisto-env
# conda install --channel bioconda kallisto

basedir="/home-2/gyang22@jhu.edu/work/Guangyu/"
workdir="${basedir}/simulation3/kallisto"
datadir="${basedir}/simulation3/FASTQ"
gtf="${basedir}/simulation3/sim.stmerged.modified.gtf"
mkdir -p ${workdir}; cd ${workdir}

fa_file="${basedir}/simulation3/sim.stmerged.modified.clean.fa"
kallisto index -i index ${fa_file}


n=24
k=0
for group in case control
do
    for i in {01..25}
    do
        fastq1="${datadir}/${group}/sample_${i}/sample_${i}_R1.fastq"
        fastq2="${datadir}/${group}/sample_${i}/sample_${i}_R2.fastq"
        kallisto quant -i index -o ${group}_sample_${i} -b 10 \
                       -t 24 -g ${gtf} \
                       ${fastq1} ${fastq2} &
        k=$(($k+1))
        if [ $k -eq $n ]; then
            wait
            k=0
        fi
    done 
done




echo "sample\tcondition\tpath" > metadata.txt
for group in case control
do
    for i in {01..25}
    do
        echo "${group}_sample_${i}\t${group}\t${workdir}/${group}_sample_${i}\n" >> metadata.txt
    done
done
