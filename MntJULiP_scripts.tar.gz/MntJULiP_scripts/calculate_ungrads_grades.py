import math
from collections import defaultdict

import pandas as pd
import numpy as np

########################################  read student info from the roster file  ########################################
roster_file = '/Users/gyang/Documents/EN.601.633/rosters/roster.xlsx'

ungrads_df = pd.read_excel(roster_file, sheetname='ungrads')
ungrad_emails = ungrads_df['Email'].tolist()
ungrad_names = ungrads_df['Full Name'].tolist()

emails = set(ungrad_emails)

email_name_dict = {}
df = ungrads_df[['Full Name', 'Email']]
for i, row in df.iterrows():
    email_name_dict[row['Email']] = row['Full Name']

## scores
email_score_dict = defaultdict(list)
email_optional_score_dict = defaultdict(list)

########################################  extract and calculate scores for hw1  ########################################
scores_file = '/Users/gyang/Documents/EN.601.633/hw1/Homework_1_scores.xlsx'
score_df = pd.read_excel(scores_file, sheetname='Assignment Grades')
score_df = score_df[['Email', 'Total Score']]
score_df = score_df.fillna(0)

for i, row in score_df.iterrows():
    if row['Email'] in emails:
        email_score_dict[row['Email']].append(row['Total Score'] / 63. * 100)

########################################  extract and calculate scores for hw2  ########################################
scores_file = '/Users/gyang/Documents/EN.601.633/hw2/Homework_2_scores.xlsx'
score_df = pd.read_excel(scores_file, sheetname='Assignment Grades')
score_df = score_df[['Email', 'Total Score']]
score_df = score_df.fillna(0)

for i, row in score_df.iterrows():
    if row['Email'] in emails:
        email_score_dict[row['Email']].append(row['Total Score'] / 60. * 100)

########################################  extract and calculate scores for hw3  ########################################
scores_file = '/Users/gyang/Documents/EN.601.633/hw3/Homework_3_scores.xlsx'
score_df = pd.read_excel(scores_file, sheetname='Assignment Grades')
score_df = score_df[['Email', 'Total Score', '4: 4 (0.0 pts)']]
score_df = score_df.fillna(0)

for i, row in score_df.iterrows():
    if row['Email'] in emails:
        email_score_dict[row['Email']].append((row['Total Score'] - row['4: 4 (0.0 pts)']) / 60. * 100)
        email_optional_score_dict[row['Email']].append(row['4: 4 (0.0 pts)'])


########################################  extract and calculate scores for hw4  ########################################
scores_file = '/Users/gyang/Documents/EN.601.633/hw4/Homework_4_scores.xlsx'
score_df = pd.read_excel(scores_file, sheetname='Assignment Grades')
score_df = score_df[['Email', 'Total Score']]
score_df = score_df.fillna(0)

for i, row in score_df.iterrows():
    if row['Email'] in emails:
        email_score_dict[row['Email']].append(row['Total Score'] / 100. * 100)


########################################  extract and calculate scores for hw5  ########################################
scores_file = '/Users/gyang/Documents/EN.601.633/hw5/Homework_5_scores.xlsx'
score_df = pd.read_excel(scores_file, sheetname='Assignment Grades')
score_df = score_df[['Email', 'Total Score', '2: 2 (0.0 pts)']]
score_df = score_df.fillna(0)

for i, row in score_df.iterrows():
    if row['Email'] in emails:
        email_score_dict[row['Email']].append((row['Total Score'] - row['2: 2 (0.0 pts)']) / 60. * 100)
        email_optional_score_dict[row['Email']].append(row['2: 2 (0.0 pts)'])

########################################  extract and calculate scores for hw6  ########################################
scores_file = '/Users/gyang/Documents/EN.601.633/hw6/Homework_6_scores.xlsx'
score_df = pd.read_excel(scores_file, sheetname='Assignment Grades')
score_df = score_df[['Email', 'Total Score']]
score_df = score_df.fillna(0)

for i, row in score_df.iterrows():
    if row['Email'] in emails:
        email_score_dict[row['Email']].append(row['Total Score'] / 120. * 100)

########################################  extract and calculate scores for hw7  ########################################
scores_file = '/Users/gyang/Documents/EN.601.633/hw7/Homework_7_scores.xlsx'
score_df = pd.read_excel(scores_file, sheetname='Assignment Grades')
score_df = score_df[['Email', 'Total Score', '3: 3 (0.0 pts)']]
score_df = score_df.fillna(0)

for i, row in score_df.iterrows():
    if row['Email'] in emails:
        email_score_dict[row['Email']].append((row['Total Score'] - row['3: 3 (0.0 pts)']) / 60. * 100)
        email_optional_score_dict[row['Email']].append(row['3: 3 (0.0 pts)'])

########################################  extract and calculate scores for hw8  ########################################
scores_file = '/Users/gyang/Documents/EN.601.633/hw8/Homework_8_scores.xlsx'
score_df = pd.read_excel(scores_file, sheetname='Assignment Grades')
score_df = score_df[['Email', 'Total Score']]
score_df = score_df.fillna(0)

for i, row in score_df.iterrows():
    if row['Email'] in emails:
        email_score_dict[row['Email']].append(row['Total Score'] / 120. * 100)

########################################  extract and calculate scores for hw9  ########################################
scores_file = '/Users/gyang/Documents/EN.601.633/hw9/Homework_9_scores.xlsx'
score_df = pd.read_excel(scores_file, sheetname='Assignment Grades')
score_df = score_df[['Email', 'Total Score']]
score_df = score_df.fillna(0)

for i, row in score_df.iterrows():
    if row['Email'] in emails:
        email_score_dict[row['Email']].append(row['Total Score'] / 120. * 100)

########################################  calculate average grades for home works ########################################
email_avg_score_dict = {}
for email, scores in email_score_dict.items():
    email_avg_score_dict[email] = (sum(scores) - min(scores)) / 8.


########################################  extract and calculate scores for midterm exam ########################################
scores_file = '/Users/gyang/Documents/EN.601.633/midterm_exam/Mid-Semester_Examination_scores.xlsx'
score_df = pd.read_excel(scores_file, sheetname='Assignment Grades')
score_df = score_df[['Email', 'Total Score']]
score_df = score_df.fillna(0)

email_midterm_score_dict = {}
for i, row in score_df.iterrows():
    if row['Email'] in emails:
        email_midterm_score_dict[row['Email']] = row['Total Score'] / 75. * 100


########################################  extract and calculate scores for final exam ########################################
scores_file = '/Users/gyang/Documents/EN.601.633/final_exam/Final_Examination_scores.xlsx'
score_df = pd.read_excel(scores_file, sheetname='Assignment Grades')
score_df = score_df.fillna(0)

email_final_score_dict = {}
for i, row in score_df.iterrows():
    if row['Email'] in emails:
        q1_score = sum(row[['1.1: 1.a (10.0 pts)', '1.2: 1.b (10.0 pts)', '1.3: 1.c (10.0 pts)']].tolist())
        q2_score = sum(row[['2.1: 2.a (15.0 pts)', '2.2: 2.b (15.0 pts)']].tolist())
        q8_score = sum(row[['8.1: 8.a (6.0 pts)', '8.2: 8.b (6.0 pts)', '8.3: 8.c (6.0 pts)', '8.4: 8.d (6.0 pts)', '8.5: 8.e (6.0 pts)']].tolist())
        scores = row[['3 (30.0 pts)', '4 (30.0 pts)', '5 (30.0 pts)', '6 (30.0 pts)', '7 (30.0 pts)']].tolist()
        scores += [q1_score, q2_score, q8_score]
        score = row['Total Score'] - min(scores)
        email_final_score_dict[row['Email']] = score / 210 * 100

########################################  output results ########################################
with open('/Users/gyang/Documents/EN.601.633/final_ungrads_grades.txt', 'w') as f:
    f.write('Name\temail\tavg_hw_score\tmidterm_exam_score\tfinal_exam_score\ttotal\thw_score(optional, 60)\n')
    for email, score in email_avg_score_dict.items():
        op_score = sum(email_optional_score_dict[email])
        midterm_score = email_midterm_score_dict[email]
        final_score = email_final_score_dict[email]
        total_score = score + midterm_score + final_score
        f.write('{}\t{}\t{:.2f}\t{:.2f}\t{:.2f}\t{:.2f}\t{:.2f}\n'.format(email_name_dict[email], email,
                                                          score, midterm_score, final_score, total_score, op_score))
