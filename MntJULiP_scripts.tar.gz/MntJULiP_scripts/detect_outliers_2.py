from pathlib import Path
import argparse
import os
import glob

import numpy as np
import pandas as pd

import matplotlib.pyplot as plt


def warn(*args, **kwargs):
    pass

import warnings
warnings.warn = warn

from sklearn.preprocessing import StandardScaler
from sklearn.decomposition import PCA
from sklearn.neighbors import LocalOutlierFactor


def get_arguments():
    parser = argparse.ArgumentParser(description='details',
                                    usage='use "%(prog)s --help" for more information',
                                    formatter_class=argparse.RawTextHelpFormatter)
    parser.add_argument('--out-dir', type=str, default='.', help='Output dir for the results')
    parser.add_argument('--in-files', type=str, help='Input file(s) that contains the expressions matrices')

    return parser.parse_args()


def main():
    args = get_arguments()
    files = glob.glob(args.in_files)
    # files = glob.glob('/ccb/salz3/florea/JPaik/MOATs/*.mvg.txt')

    # out_dir = Path('/ccb/salz3/florea/JPaik/MOATs/PCA_results')
    out_dir = Path(args.out_dir)
    if not out_dir.exists():
        os.mkdir(out_dir)

    for file in files:
        prefix = file.split('/')[-1].replace('.mvg.txt', '')

        df = pd.read_csv(file, index_col=0, sep='\t')
        df = df.drop(['avg', 'stdev', 'stdev/avg'], axis=1)
        df = df.transpose()
        samples = df.index.tolist()

        # Standardizing the features
        X = StandardScaler().fit_transform(df)

        # Apply PCA
        pca = PCA(n_components=3)
        X = pca.fit_transform(X)

        # Apply Local Outlier Factor (LOF)
        # by default: n_neighbors=20, contamination=0.22
        n_neighbors = int(len(samples) * 0.2)
        if n_neighbors < 3:
            n_neighbors = 3
        elif n_neighbors > 20:
            n_neighbors = 20

        clf = LocalOutlierFactor(algorithm='auto', n_neighbors=3)
        y_pred = clf.fit_predict(X)

        # Generate predicted inliers and outliers
        Y_inliers = np.asarray([X[i, :] for i in range(X.shape[0]) if y_pred[i] == 1])
        Y_outliers = np.asarray([X[i, :] for i in range(X.shape[0]) if y_pred[i] == -1])

        # show component 1 & 2
        plt.figure(0)
        plt.title("Principal Component Analysis (PCA) + Local Outlier Factor (LOF)")
        plt.scatter(Y_inliers[:, 0], Y_inliers[:, 1], color='orange', label='Inliers')
        plt.scatter(Y_outliers[:, 0], Y_outliers[:, 1], color='blue', label='Outliers')

        plt.axis('tight')
        plt.xlabel('Principal Component 1')
        plt.ylabel('Principal Component 2')
        # plt.xlim((-10, 10))
        # plt.ylim((-10, 10))
        legend = plt.legend(loc='upper left')
        legend.legendHandles[0]._sizes = [10]
        legend.legendHandles[1]._sizes = [10]
        plt.savefig(out_dir / f'{prefix}.pca_plot_1_to_2.png')

        # show component 1 & 3
        plt.figure(1)
        plt.title("Principal Component Analysis (PCA) + Local Outlier Factor (LOF)")
        plt.scatter(Y_inliers[:, 0], Y_inliers[:, 2], color='orange', label='Inliers')
        plt.scatter(Y_outliers[:, 0], Y_outliers[:, 2], color='blue', label='Outliers')

        plt.xlabel('Principal Component 1')
        plt.ylabel('Principal Component 3')
        legend = plt.legend(loc='upper left')
        legend.legendHandles[0]._sizes = [10]
        legend.legendHandles[1]._sizes = [10]
        plt.savefig(out_dir / f'{prefix}.pca_plot_1_to_3.png')

        # show component 2 & 3
        plt.figure(2)
        plt.title("Principal Component Analysis (PCA) + Local Outlier Factor (LOF)")
        plt.scatter(Y_inliers[:, 1], Y_inliers[:, 2], color='orange', label='Inliers')
        plt.scatter(Y_outliers[:, 1], Y_outliers[:, 2], color='blue', label='Outliers')

        plt.xlabel('Principal Component 2')
        plt.ylabel('Principal Component 3')
        legend = plt.legend(loc='upper left')
        legend.legendHandles[0]._sizes = [10]
        legend.legendHandles[1]._sizes = [10]
        plt.savefig(out_dir / f'{prefix}.pca_plot_2_to_3.png')

        out_columns = ['principal_component_1', 'principal_component_2', 'principal_component_3']
        df_out = pd.DataFrame(data=X, columns=out_columns)
        df_out.insert(0, "samples", samples)
        df_out["LOF_score"] = np.abs(clf.negative_outlier_factor_)
        df_out[f"label(threshold:{abs(clf.offset_):.2f})"] = y_pred
        df_out.to_csv(out_dir / f'{prefix}.results.txt', sep='\t', index=None, header=True, float_format='%.6f')

        # Explained variance ratio
        out_file = out_dir / f'{prefix}.explained_variance_ratio.txt'
        with open(out_file, 'w') as f:
            for i, (v1, v2) in enumerate(zip(pca.explained_variance_ratio_, pca.explained_variance_)):
                f.write(f'Component {i+1}: {v1} ({v2})\n')


if __name__ == "__main__":
    main()
