
module load python
module load samtools
module load star
module load gsl/1.9
module load lapack/gcc/64/3.5.0

export LD_LIBRARY_PATH=$LD_LIBRARY_PATH:/scratch/groups/lflorea1/Guangyu/softwares/BLAS-3.8.0

RMATS='/scratch/groups/lflorea1/Guangyu/softwares/rMATS.4.0.2/rMATS-turbo-Linux-UCS2/rmats.py'
python $RMATS --nthread 10 \
              --b1 b1.txt \
              --b2 b2.txt \
              - Homo_sapiens.GRCh37.75 \
              --od bam_test \
              -t paired \
              --readLength 101 \
              --cstat 0.0001 \
              --libType fr-unstranded
