#  gffread -E sim.stmerged.modified.gtf  --keep-genes --keep-comments -o- > sim.stmerged.modified.gff3

# chr1    HAVANA  gene    11869   14409   .   +   .   ID=ENSG00000223972.5;gene_id=ENSG00000223972.5;gene_type=transcribed_unprocessed_pseudogene;gene_status=KNOWN;gene_name=DDX11L1;level=2;havana_gene=OTTHUMG00000000961.2


# chr1    HAVANA  transcript  11869   14409   .   +   .   ID=ENST00000456328.2;Parent=ENSG00000223972.5;gene_id=ENSG00000223972.5;transcript_id=ENST00000456328.2;gene_type=transcribed_unprocessed_pseudogene;gene_status=KNOWN;gene_name=DDX11L1;transcript_type=processed_transcript;transcript_status=KNOWN;transcript_name=DDX11L1-002;level=2;transcript_support_level=1;tag=basic;havana_gene=OTTHUMG00000000961.2;havana_transcript=OTTHUMT00000362751.1



# chr1    HAVANA  exon    11869   12227   .   +   .   ID=exon:ENST00000456328.2:1;Parent=ENST00000456328.2;gene_id=ENSG00000223972.5;transcript_id=ENST00000456328.2;gene_type=transcribed_unprocessed_pseudogene;gene_status=KNOWN;gene_name=DDX11L1;transcript_type=processed_transcript;transcript_status=KNOWN;transcript_name=DDX11L1-002;exon_number=1;exon_id=ENSE00002234944.1;level=2;transcript_support_level=1;havana_gene=OTTHUMG00000000961.2;havana_transcript=OTTHUMT00000362751.1;tag=basic

# chr1    HAVANA  transcript      11869   14409   .       +       .       ID=ENST00000456328.2;geneID=ENSG00000223972.5;gene_name=DDX11L1
#

# chr1    HAVANA  exon    11869   12227   .       +       .       Parent=ENST00000456328.2


file = '/ccb/salz3/gyang/simulation3/stringtie/sim.stmerged.modified.gff3'
with open(file, 'r') as f:
    lines = f.readlines()

out_buffer = ''
tran_info_dict = {}
gene_info_dict = {}
i = 1
for line in lines:
    if line.startswith('#'):
        continue
    items = line.strip().split('\t')
    if items[2] == 'gene':
        info_dict = {}
        for v in items[8].split(';'):
            a, b = v.split('=')
            info_dict[a] = b
        res = f"ID={info_dict['ID']};gene_id={info_dict['ID']}"
        gene_info_dict[info_dict['ID']] = f"gene_id={info_dict['ID']}"
        if 'Name' in info_dict:
            res += f";gene_name={info_dict['Name']}"
            gene_info_dict[info_dict['ID']] += f";gene_name={info_dict['Name']}"
        else: # assign gene id to gene name
            res += f";gene_name={info_dict['ID']}"
            gene_info_dict[info_dict['ID']] += f";gene_name={info_dict['ID']}"
        out_buffer += '\t'.join(items[:-1] + [res]) + '\n'
        i = 1

    if items[2] == 'transcript':
        info_dict = {}
        for v in items[8].split(';'):
            a, b = v.split('=')
            info_dict[a] = b
        res = f"ID={info_dict['ID']};Parent={info_dict['Parent']};transcript_id={info_dict['ID']};" + gene_info_dict[info_dict['Parent']]
        tran_info_dict[info_dict['ID']] = f"transcript_id={info_dict['ID']};" + gene_info_dict[info_dict['Parent']]
        out_buffer += '\t'.join(items[:-1] + [res]) + '\n'
        i = 1

    if items[2] == 'exon':
        _, tran_id = items[8].split('=')
        res = f"ID=exon:{tran_id}:{i};Parent={tran_id};" + tran_info_dict[tran_id]
        out_buffer += '\t'.join(items[:-1] + [res]) + '\n'
        i += 1

file = '/ccb/salz3/gyang/simulation3/stringtie/sim.stmerged.modified_2.gff3'
with open(file, 'w') as f:
    f.write(out_buffer)

