# SOFTWARE_DIR="/ccb/salz3/gyang/softwares"
# export PYTHONPATH=${SOFTWARE_DIR}/python-3.6.8
# export PATH=${SOFTWARE_DIR}/python-3.6.8/bin:$PATH

######################################################### get reference introns and genes.##########################################
from collections import defaultdict
from pathlib import Path

import numpy as np


tran_exons_dict = defaultdict(list)
gtf_file = '/ccb/salz3/gyang/simulation3/meta_info/annotation'
chr_strand_tran_exons_dict = defaultdict(lambda: defaultdict(lambda: defaultdict(list)))
gene_chr_strand_dict = {}
gene_id_name_dict = {}

with open(gtf_file, 'r') as f:
    for line in f:
        if line is not '\n':
            items = line.strip().split('\t')
            if items[2] == 'exon':
                _chr, strand = items[0], items[6]
                start, end = items[3: 5]
                _items = items[8].split('"')
                tran_id, gene_id, gene_name, = _items[3], _items[1], _items[9]
                chr_strand_tran_exons_dict[_chr][strand][tran_id].append((int(start), int(end)))
                gene_chr_strand_dict[gene_id] = (_chr, strand)
                gene_id_name_dict[gene_id] = gene_name

chrs = list(chr_strand_tran_exons_dict.keys())


def get_introns(exons):
    if len(exons) <= 1:
        return []
    else:
        introns = []
        _list = sorted(exons)
        start = _list[0][1]
        for i in range(1, len(_list)):
            end = _list[i][0]
            introns.append((start, end))
            start = _list[i][1]
        return introns


chr_strand_tran_introns_dict = defaultdict(lambda: defaultdict(lambda: defaultdict(list)))
chr_strand_introns_set = defaultdict(lambda: defaultdict(set))
trans_set = set([])
for _chr in chrs:
    for strand in ['-', '+']:
        for tran_id, exons in chr_strand_tran_exons_dict[_chr][strand].items():
            introns = get_introns(exons)
            chr_strand_tran_introns_dict[_chr][strand][tran_id] = introns
            chr_strand_introns_set[_chr][strand].update(introns)
            trans_set.add(tran_id)


count = 0
for _chr in chrs:
    for strand in ['-', '+']:
        for intron in chr_strand_introns_set[_chr][strand]:
            count += 1

print(count)  # 42496


gene_file = '/ccb/salz3/gyang/simulation3/meta_info/genes_info.txt'
de_genes = []
none_genes = []
ds_genes = []
de_ds_genes = []


with open(gene_file, 'r') as f:
    for line in f:
        items = line.strip().split('\t')
        gene_id = items[0]
        _chr, strand = gene_chr_strand_dict[gene_id]
        bool1, bool2, bool3 = [b == 'True' for b in items[3: 6]]
        if not(bool1 or bool2 or bool3):
            none_genes.append(gene_id_name_dict[gene_id])

        if bool1 and not(bool2) and not(bool3):  # only swapped the top two trans' expr
            ds_genes.append(gene_id_name_dict[gene_id])

        if not(bool1) and (bool2 or bool3):
            de_genes.append(gene_id_name_dict[gene_id])

        if bool1 and (bool2 or bool3):
            de_ds_genes.append(gene_id_name_dict[gene_id])


print(len(none_genes), len(de_genes), len(ds_genes), len(de_ds_genes))


##########################################################. rMATS  ##############################################################
results_dir = Path('/ccb/salz3/gyang/simulation3/rMATS.3.2.5/out/MATS_output')

files = []
numbers = []
files.append(results_dir / 'SE.MATS.ReadsOnTargetAndJunctionCounts.txt')
files.append(results_dir / 'MXE.MATS.ReadsOnTargetAndJunctionCounts.txt')
files.append(results_dir / 'A5SS.MATS.ReadsOnTargetAndJunctionCounts.txt')
files.append(results_dir / 'A3SS.MATS.ReadsOnTargetAndJunctionCounts.txt')
files.append(results_dir / 'RI.MATS.ReadsOnTargetAndJunctionCounts.txt')

numbers.append(18)
numbers.append(20)
numbers.append(18)
numbers.append(18)
numbers.append(18)

# numbers.append(19)
# numbers.append(21)
# numbers.append(19)
# numbers.append(19)
# numbers.append(19)

for threshold in [0.1, 0.05, 0.01]:
    gene_names = set()
    for file, num in zip(files, numbers):
        with open(file, 'r') as f:
            lines = f.readlines()

        for line in lines[1:]:
            items = line.strip().split('\t')
            gene_name, p_value = items[2][1:-1], float(items[18])
            if p_value <= threshold:
                gene_names.add(gene_name)

    print (len(gene_names.intersection(none_genes)), len(gene_names.intersection(de_genes)),
           len(gene_names.intersection(ds_genes)), len(gene_names.intersection(de_ds_genes)))


file = '/ccb/salz3/gyang/simulation3/LeafCutter/leafcutter_ds_cluster_significance.txt'
for threshold in [0.1, 0.05, 0.01]:
    gene_names = set()
    with open(file, 'r') as f:
        lines = f.readlines()

    for line in lines[1:]:
        items = line.strip().split('\t')
        status, gene_name, p_value = items[1], items[4], items[6]
        if status == 'Success':
            p_value = float(p_value)
            if p_value <= threshold:
                gene_names.add(gene_name)

    print (len(gene_names.intersection(none_genes)), len(gene_names.intersection(de_genes)),
           len(gene_names.intersection(ds_genes)), len(gene_names.intersection(de_ds_genes)))

