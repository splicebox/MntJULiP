#pip3 install --user statsmodels pandas

from pathlib import Path
from statsmodels.stats import multitest
import pandas as pd
import argparse


def get_arguments():
    parser = argparse.ArgumentParser(description='details',
                                    usage='use "%(prog)s --help" for more information',
                                    formatter_class=argparse.RawTextHelpFormatter)
    parser.add_argument('--out-file', type=str, default='results.txt', help='Output file that contains the results')
    parser.add_argument('--in-file', type=str, help='Input file that contains the p-values')
    parser.add_argument('--error-rate', type=float, default=0.05, help='family-wise error rate. (default 0.05)')
    parser.add_argument('--method', type=str, default='fdr_bh',
                        help='''
Method used for testing and adjustment of pvalues (default 'fdr_bh')
- `bonferroni` : one-step correction
- `sidak` : one-step correction
- `holm-sidak` : step down method using Sidak adjustments
- `holm` : step-down method using Bonferroni adjustments
- `simes-hochberg` : step-up method  (independent)
- `hommel` : closed method based on Simes tests (non-negative)
- `fdr_bh` : Benjamini/Hochberg  (non-negative)
- `fdr_by` : Benjamini/Yekutieli (negative)
- `fdr_tsbh` : two stage fdr correction (non-negative)
- `fdr_tsbky` : two stage fdr correction (non-negative)
        ''')

    return parser.parse_args()


def main():
    args = get_arguments()
    df = pd.read_csv(args.in_file, sep='\t')
    results = multitest.multipletests(df['p-value'], alpha=args.error_rate, method=args.method)
    q_values = results[1].tolist()
    df.insert(df.columns.get_loc("p-value") + 1, 'q-value', q_values)
    out_file = Path(args.out_file)
    df.to_csv(out_file, sep='\t', index=None, header=True, float_format='%.6f')


if __name__ == "__main__":
    main()
