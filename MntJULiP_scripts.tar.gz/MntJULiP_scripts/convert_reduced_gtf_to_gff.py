gtf_file = '/ccb/salz3/gyang/simulation3/meta_info/reduced_gencode.v22.annotation_1000_ds_genes.gtf'

isoforms = set()
with open(gtf_file, 'r') as f:
    for line in f:
        if line.startswith('#'):
            continue

        items = line.strip().split('\t')
        if items[2] == 'transcript':
            tran_id = items[8].split('; ')[1].split(' ')[1][1:-1]
            isoforms.add(tran_id)

gff_file = '/ccb/salz3/gyang/simulation3/gencode.v22.annotation.gff3'
out_buffer = ''
with open(gff_file, 'r') as f:
    for line in f:
        if line.startswith('#'):
            out_buffer += line
            continue

        items = line.strip().split('\t')
        if items[2] in {'transcript', 'exon'}:
            tran_id = items[8].split(';')[3].split('=')[1]
            if tran_id not in isoforms:
                continue

        if items[2] in {'transcript', 'exon', 'gene'}:
            out_buffer += line

new_gff_file = '/ccb/salz3/gyang/simulation3/meta_info/reduced_gencode.v22.annotation_1000_ds_genes.gff3'
with open(new_gff_file, 'w') as f:
    f.write(out_buffer)



#######################
gtf_file = '/ccb/salz3/gyang/simulation3/meta_info/reduced_gencode.v22.annotation_500_ds_genes.gtf'

isoforms = set()
with open(gtf_file, 'r') as f:
    for line in f:
        if line.startswith('#'):
            continue

        items = line.strip().split('\t')
        if items[2] == 'transcript':
            tran_id = items[8].split('; ')[1].split(' ')[1][1:-1]
            isoforms.add(tran_id)

gff_file = '/ccb/salz3/gyang/simulation3/gencode.v22.annotation.gff3'
out_buffer = ''
with open(gff_file, 'r') as f:
    for line in f:
        if line.startswith('#'):
            out_buffer += line
            continue

        items = line.strip().split('\t')
        if items[2] in {'transcript', 'exon'}:
            tran_id = items[8].split(';')[3].split('=')[1]
            if tran_id not in isoforms:
                continue

        if items[2] in {'transcript', 'exon', 'gene'}:
            out_buffer += line

new_gff_file = '/ccb/salz3/gyang/simulation3/meta_info/reduced_gencode.v22.annotation_500_ds_genes.gff3'
with open(new_gff_file, 'w') as f:
    f.write(out_buffer)
